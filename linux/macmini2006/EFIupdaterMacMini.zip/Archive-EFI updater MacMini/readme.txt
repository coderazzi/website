All right, 50BMG, I'm sorry that you are still confused, so I'll try and explain the process to upgrade the firmware as best as I can.

WARNING: I'm sure it goes without saying, but I'd strongly advise you to backup your entire system before proceeding. In case you brick the system, you can always restore with your backup and your system recovery discs. If you don't have any, ensure you have some before you begin. I'm not responsible if your Mac breaks after trying this.

First, download this zip file which contains the updated mac mini firmware files. After you extract the files, you will place them in your /System/Library/CoreServices/Firmware Updates directory. 

Once you have placed the files in that location, open up a Terminal window and type (if you prefer to practice your keyboard skills) or paste the following:
Quote:
sudo bless -mount / -firmware /System/Library/CoreServices/Firmware\ Updates/EFIUpdaterApp.efi -payload /System/Library/CoreServices/Firmware\ Updates/LOCKED_MM11_0055_08B.fd -options "-x efi-apple-payload0-data" --verbose
This will allow you to not only run the operation as root (sudo) which is necessary, as you are editing system-critical files, but it will order the Mac to bless the new firmware that you moved so that it is updated. 

Turn off your computer normally.

Press and hold your power button until you see your Mini's power light flash repeatedly, and then release. You should hear a strange boot sound from your Mac.

You may or may not see a grey screen with a progress bar loading. I did, but others report they do not, so it will vary. If you do encounter this screen, just let the progress bar complete, and don't touch anything.

You should see your Mac boot into your desktop, only it will have an incredibly strange and distorted image, so you won't be able to operate anything. This is perfectly normal. Force your Mac to power down by holding the power button until it shuts off. 

Reboot, but this time do a PRAM reset, by holding down Command+Option+P+R. Now here is the catch: if your aluminum keyboard doesn't work, you will need to have another generic USB keyboard you can use for the startup strokes, substituting the Windows key for Command and the Alt key for Option. 

Once the PRAM is complete, the Mac should reboot and launch normally.

That's it! If done correctly your firmware will be updated. You can confirm this by checking your System Info dialogue box and examining the Mac identifier and the Boot ROM version. Nothing else should be required. 

As you can see, it is a very tricky process, because you want to get the timing down just right on the reset and boot times. I'd write down these instructions so you can follow them through after your shut down your Mac. Remember, backup backup backup! If it goes haywire, restore from backup and try again.

Good luck! 