package SplitFile;

import java.io.FileInputStream;

import java.util.Observable;
import java.util.Observer;

/**
  * This class allows to read a file (or a portion of it) in a separate thread
  * It is an observable class, that launch the following events :
  * -ErrorSplittingEvent: when an error is produced. If the error is produced in the
  *	 	beginning, before opening the file to split (or opening it), this event will
  * 	be thrown without a previous StartSplittingEvent<br>
  * -ReadEvent: every n bytes read, this event is thrown. It includes the number of
  * 	bytes already read, and the read state (finished or not). This event can be 
  *		controlledEven, but even inf no ReadEvents have to be launched, when the read 
  *		finishes, it will be raised an event with the read state on finished<br>
  *
  *	It doesn't launch FinishOpEvents (it is enough with the read state on ReadEvent)
  *
  * To use this class, use just the startReading and stopReading methods, don't 
  *	create a new Thread explictly.
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
class FileRead extends Observable implements Runnable
{
	/**
	  * The constructor needs to have a FileInputStream, already initialitated,
	  * a buffer (RWMemory), and the number of bytes to read.
	  * @param fis the file input stream
	  * @param bytes the number of bytes to read (from the current fis position).
	  * 			Must be greater than 0 (otherwise it doesn't anything)
	  * @param memory the RWMemory to use as shared buffer with the FileWrite. 
	  *				It is expected that this RWMemory contains CommRWBufferMemory objects
	  */
	public FileRead(FileInputStream fis, long bytes, RWMemory memory)
	{
		this.file=fis;
		this.memory=memory;
		this.read=bytes;

		constRead=read;		
		thread=null;
	}
	
	/**
	  * This method starts (if not done before) a thread to read the file.
	  * It returns inmediatly; to know when the reading has finished, it is
	  * needed to verify the ReadEvents
	  * @param observer An observer for the operation
	  * @param sendReadEvents false to not receive ReadEvents (the last one, when the file
	  *		has been read, is always launched)
	  */
	public void startReading(Observer observer, boolean sendReadEvents)
	{
		if (thread==null)
		{
			addObserver(observer);
			this.sendReadEvents=sendReadEvents;
			thread=new Thread(this);
			thread.start();
		}	
	}
	
	/**
	  * This method stops the reading of the file
	  */
	public synchronized void stopReading()
	{
		if (thread!=null)
		{
			thread.stop();
			endAnyOp();
		}	
	}
	
	/**
	  * Destroys any resource still used
	  */
	synchronized void endAnyOp()
	{
		thread=null;
		deleteObservers();
		file=null;
		memory=null;
	}
	
	/**
	  * This method shouldn't be directly called
	  */
	public void run()
	{
		ErrorSplittingEvent ev=null;
		try
		{
			while(ev==null && read>0)
			{
				CommRWBufferMemory buffer=(CommRWBufferMemory)memory.getWriteMemory();
				
				int toRead=buffer.getMaxSize();		//bytes to read
				if (toRead>read)
					toRead=(int) read;	//safe conversion
					
				if (file.read(buffer.getBuffer(),0,toRead)!=toRead)
					ev=new ErrorSplittingEvent(ErrorSplittingEvent.SPLITFILE_SMALLER);
				else
				{
					buffer.setSize(toRead);
					read-=toRead;
					boolean finished=read==0;
					if (finished || sendReadEvents)
					{
						setChanged();
						notifyObservers(new ReadEvent(constRead-read,finished));
						if (finished)
							buffer.setEOP();
					}
					memory.releaseWriteMemory();
				}
			}
		}
		catch(InterruptedException ie)
		{
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.INTERNAL_ERROR3);
		}
		catch(java.io.IOException ioe)
		{
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.IOEXCEPTION_READING);
		}
		setChanged();
		if (ev!=null)
			notifyObservers(ev);
		endAnyOp();
	}
	
	private FileInputStream file;
	private RWMemory memory;
	private long read,constRead;
	private boolean sendReadEvents;

	private Thread thread;
}