package SplitFile;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

/**
  * This class allows to track down the created chunks
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class ListChunks implements Observer
{
	/**
	  * @param splitter the FileSplitter to keep watched
	  */
	public ListChunks(FileSplitter splitter)
	{
		this.splitter=splitter;
		chunks=new Vector(10,10);
		splitter.addObserver(this);
	}

	/**
	  * This method gives the number of chunks created
	  * @return the number of chunks created
	  */
	public int getNumberOfChunks()
	{
		return chunks.size();
	}
	
	/**
	  * This method gives an enumeration with the chunks created
	  * @return an enumeration with the chunks created
	  */
	public Enumeration getChunks()
	{
		return chunks.elements();
	}
	
	/**
	  * Observer method
	  */
	public void update(Observable obs, Object obj)
	{
		if (obj instanceof ChunkCreatedEvent)
			chunks.addElement(new String(((ChunkCreatedEvent)obj).getFileName()));
		else if (obj instanceof ErrorSplittingEvent || obj instanceof StopSplittingEvent)
		{
			splitter.deleteObserver(this);
			splitter=null;
		}
	}
	
	private Vector chunks;
	private FileSplitter splitter;
}