package SplitFile;

/**
  * Abstract Class to define the events that throw the SplitFile class
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
abstract public class SplitFileEvent
{
}