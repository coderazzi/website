package SplitFile.Prg;

import java.io.File;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;

import SplitFile.*;

/**
  * Splitter class, does the splitting of a file using the SplitFile.SplitFile class
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

class Splitter implements Observer, Runnable
{
	/**
	  * The constructor needs a Splitting Display to show its progress, and all the
	  * information needed to start the splitting. When it had finished, it will call the
	  * method splittingFinished on the SplitterDisplay interface
	  * @param display the SplitterDisplay to show any information
	  * @param splitFile name of the file to split
	  * @param targetPath path for the chunk files
	  * @param chunkSize the max size for each chunk
	  * @param bat true to create a bat file (false to create a script)
	  */
	Splitter(SplitterDisplay display, String fileName, String targetPath, long chunkSize, 
								boolean bat)
	{
		this.display=display;
		this.bat=bat;
		this.targetPath=new String(targetPath);
		this.fileName=new String(fileName);
		this.chunkSize=chunkSize;
		splitter=null;
		chunks=null;
		thread=new Thread(this);
		thread.start();
	}
	
	/**
	  * Stops the current splitting
	  */
	public void stopSplitting()
	{
		if (thread!=null)
			splitter.stopSplitting();
	}
	
	public void run()
	{
		splitter=new FileSplitter();
		chunks=new ListChunks(splitter);
		splitter.addObserver(this);
		splitter.split(fileName,chunkSize,new NAAddChunk(targetPath),true);
	}
	
	public void update(Observable obs, Object obj)
	{
		if (obj instanceof ErrorSplittingEvent)
		{
			display.showError("Error splitting ["+((ErrorSplittingEvent)obj).toString()+"]");
			removeChunks();
			finish(true);
		}
		else 	if (obj instanceof StartSplittingEvent)
		{
			StartSplittingEvent ev=(StartSplittingEvent)obj;
			display.showMessage("Splitting "+ev.getFileName()+" ["+ev.getFileSize()+"] on "+ev.getNumberOfChunks()+" chunks");
			fileSize=ev.getFileSize();
		}
		else if (obj instanceof StopSplittingEvent)
		{
			String file=null;
			BatchGlue glue=null;
			if (bat)
			{
				file=new String(targetPath+".bat");
				glue=new PCGlue();
			}
			else
			{
				file=new String(targetPath+".merger");
				glue=new ScriptGlue();
			}
			finish(createMerger(file,glue));//finish with the condition error of createMerger
		}
		else if (obj instanceof ChunkCreatedEvent)
		{
			ChunkCreatedEvent ev=(ChunkCreatedEvent)obj;
			display.showMessage("Creating "+ev.getFileName()+" ["+ev.getFileSize()+"] ");
			chunkSize=ev.getFileSize();
			display.setWriteProgress(0);
		}
		else if (obj instanceof WriteEvent)
			display.setWriteProgress((int)(100*((WriteEvent)obj).getBytesWritten()/chunkSize));
		else if (obj instanceof ReadEvent)
			display.setReadProgress((int)(100*((ReadEvent)obj).getBytesRead()/fileSize));
	}
		
	/**
	  * Removes any created chunk
	  */
	void removeChunks()
	{
		Enumeration chunksEnum=chunks.getChunks();
		while(chunksEnum.hasMoreElements())
			removeFile((String)chunksEnum.nextElement());
	}
	 
	 /**
	   * Removes (or tries to) the file with the name specified
	   * @param fileName the file to remove
	   */
	void removeFile(String name)
	{
		new File(name).delete();
	}
	
	/**
	  * Creates a merger file
	  * @param file the name of the file to create
	  * @param glue the creator of the file
	  * @return the error condition (true if any error has been produced)
	  */ 
	boolean createMerger(String file, BatchGlue glue)
	{
		boolean ret=false;
		try
		{
			display.showMessage("Creating merger file ["+file+"]");
			glue.createGlue(chunks,file,new File(fileName).getName());
			display.showMessage("Merger file ["+file+"] created");
		}
		catch(IOException ioex)
		{
			removeFile(file);
			display.showError("Error creating/writting the merger file");
			ret=true;
		}
		return ret;
	}
	
	/**
	  * Free any resource
	  * @param error true if there has been any error
	  */
	void finish(boolean error)
	{
		if (!error)
			display.showMessage("Splitting done");
		display.setReadProgress(0);
		display.setWriteProgress(0);
		targetPath=null;
		fileName=null;
		chunks=null;
		splitter.deleteObservers();
		splitter=null;
		thread=null;
		display.splittingFinished(error);
	}
	
	private SplitterDisplay display;
	private boolean bat;
	private String targetPath,fileName;
	private long chunkSize;
	
	private FileSplitter splitter;
	private ListChunks chunks;
	private Thread thread;

	private long fileSize;
}