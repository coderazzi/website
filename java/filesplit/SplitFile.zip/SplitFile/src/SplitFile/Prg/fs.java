package SplitFile.Prg;

/**
  * Standalone program to split a file<br>
  * With no parameters, a window interface is displayed to get the information.
  * With arguments, this is it syntax:<br>
  * [options] File_to_split [Target_path=File_to_split]<br>
  * Where options:<br>
  * -noecho: no information will be displayed<br>
  * -script: a script file (and not a bat file) is created<br>
  * -size=xxx: defines de max size of each chunk (by default is a 3"1/2 floppy size)<br>
  * This creates a number of chunk files, that have as name: Target_path+"."+chunk number<br>
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class fs
{
	static public void main(String args[])
	{
		if (args.length==0)
			new SplitterFrm();
		else
		{
			long length=1457664;
			boolean noecho=false;
			boolean bat=true;
			boolean size=false;
			boolean options=true;
			
			int argc=args.length;
			int argcError=-1;
			int arg=0;
			
			while(options && argcError==-1 && arg<argc)
				if (args[arg].charAt(0)!='-')
					options=false;
				else if (args[arg].compareTo("-noecho")==0)
					if (noecho)
						argcError=arg;
					else
					{
						noecho=true;
						arg++;
					}
				else if (args[arg].compareTo("-script")==0)
					if (!bat)
						argcError=arg;
					else
					{
						bat=false;
						arg++;
					}
				else if (args[arg].startsWith("-size="))
					if (size)
						argcError=arg;
					else
						try
						{
							length=Long.parseLong(args[arg].substring(6));
							if (length<=0)
								argcError=arg;
							else
							{
								size=true;
								arg++;
							}
						}
						catch(Exception ex)
						{
							argcError=arg;
						}
				else
					argcError=arg;
	
			int leftArgs=argc-arg;
			if ((argcError!=-1)	|| (leftArgs<1) || (leftArgs>2))
			{
				present(true);
				if (argcError==-1)
					System.err.println("Wrong number of arguments");
				else
					System.err.println("Error on argument: "+args[argcError]);
			}
			else
			{
				if(!noecho)
					present(false);
				new Splitter(new SplitterEcho(!noecho), args[arg],args[arg+leftArgs-1],length,bat);
			}
		}	
	}

	static void present(boolean error)
	{
		System.out.println(SplitFileInfo.getInfo());
		if (error)
		{
			System.out.println();
			System.out.println("Withouts arguments, a window interface is displayed to get the information");
			System.out.println();
			System.out.println("With arguments, this is it syntax: [options] File [Target_path=File]");
			System.out.println("-noecho: no information will be displayed");
  		System.out.println("-script: a script file (and not a bat file) is created");
  		System.out.println("-size=xxx: defines de max size of each chunk (by default is a 3\"1/2 floppy size)");
  		System.out.println("It will split up the file, creating chunks with the name Target_path.X");
			System.out.println();
		}
	}
}