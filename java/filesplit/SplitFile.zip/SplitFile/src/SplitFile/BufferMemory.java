package SplitFile;

/**
  * The RWMemory gets and releases BufferMemory instances
  * The class that implements it can in this way amkes its own communication
  * channel for the read and write operations
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
interface BufferMemory
{
}