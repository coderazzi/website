import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Class to verify whether the created files and the expected dependencies
 *   match
 */
public final class MappingChecker {

   /**
    * @param dependenciesFile: if null, it does nothing
    * @param outputDir
    */
   public MappingChecker(File dependenciesFile, String outputDir) {
      if (dependenciesFile != null) {
         File output = new File(outputDir);
         if (output.isDirectory()) {
            try {
               reportDifferences(getExpectedFiles(dependenciesFile),
                     getAllFiles(output));
            } catch (IOException ex) {
               System.out.println("Error reading files under " + outputDir);
            }
         } else {
            System.out.println("Directory " + outputDir + " does not exist.");
         }
      }
   }

   /**
    * Reports any differences between both sets
    * @param expected
    * @param found
    */
   private void reportDifferences(Set expected, Set found) {
      boolean error = false;
      Iterator it = expected.iterator();
      while (it.hasNext()) {
         String expectedFile = (String) (it.next());
         if (!found.remove(expectedFile)) {
            System.out.println("Expected but not found: " + expectedFile);
            error = true;
         }
      }
      it = found.iterator();
      while (it.hasNext()) {
         System.out.println("Generated, but not expected: " + it.next());
         error = true;
      }
      if (!error) {
         System.out.println("Ok: generation matches expectations");
      }
   }

   /**
    * Returns a set with the names of the output files found in the dependency
    * file
    */
   private Set getExpectedFiles(File dependsFile) throws IOException {
      HashSet ret = new HashSet();
      FileReader input = new FileReader(dependsFile);
      BufferedReader bufRead = new BufferedReader(input);
      String line = bufRead.readLine();
      while (line != null) {
         if (line.startsWith(">")) {
            ret.add(line.substring(1));
         }
         line = bufRead.readLine();
      }
      bufRead.close();
      return ret;
   }

   /**
    * Returns a set with the names of all the files found under the given
    * directory
    */
   private Set getAllFiles(File directory) {
      HashSet ret = new HashSet();
      File childs[] = directory.listFiles();
      if (childs != null) {
         int index = childs.length;
         while (index-- > 0) {
            if (childs[index].isFile()) {
               ret.add(childs[index].getAbsolutePath());
            } else {
               ret.addAll(getAllFiles(childs[index]));
            }
         }
      }
      return ret;
   }

   /**
    * Finds the dependencies file for mapping.idl.
    * It reports an error if it finds more than one (or none)
    * @return null if no valid dependency file found
    */
   private static File findDependencyFile() {
      final File dir = new File("dependencies");
      File childs[] = dir.listFiles(new FilenameFilter() {
         public boolean accept(File fdir, String name) {
            return dir.equals(fdir) && name.startsWith("mapping.idl.")
                  && name.endsWith(".depends");
         }
      });
      if (childs == null || childs.length == 0) {
         System.out.println("Sorry, I cannot find a valid dependency file");
      } else if (childs.length > 1) {
         System.out.println("Sorry, there are too many valid dependency files");
      } else {
         return childs[0];
      }
      return null;
   }

   /**
    * @param args
    */
   public static void main(String[] args) {
      //If any argument is provided, it must be two at once:
      // the dependencies file and the output directory
      if (args.length == 2) {
         new MappingChecker(new File(args[0]), args[1]);
      } else if (args.length == 0) {
         new MappingChecker(findDependencyFile(), "output");
      } else {
         System.out.println("Utility to check the generated files versus"
               + " the expected dependencies.");
         System.out
               .println("It requires the dependencies file and the"
                     + " output directory. If not present, itr is taken the last"
                     + " dependency file for mapping.idl in the dependencies directory"
                     + " and the directory output as output directory");
      }
   }

}
