package com.byteslooser.cmdlinker;

public class ScriptCommandException extends Exception {
    public ScriptCommandException(String s) {
        super(s);
    }
}