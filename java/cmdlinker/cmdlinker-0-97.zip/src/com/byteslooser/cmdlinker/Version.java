package com.byteslooser.cmdlinker;

public abstract class Version {
    public static String getVersion() {
        return "CmdLinker v0.9.7\n(c) Luis M Pena, July 2007\nwww.byteslooser.com/cmdlinker";
    }
}
