using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;

using XmlObjectsDocGui.Generation;

namespace XmlObjectsDocGui
{
  /// <summary>
  /// Class to invoke the XmlObjects dynamic generation
  /// It is created on a different AppDomain, to be able to unload the assemblies later,
  /// so it must extend MarshalByRefObject, as it will be handled as a remote object
  /// </summary>
  public class DynamicGeneratorLoader : MarshalByRefObject
  {

    /// <summary>
    /// Construcotr
    /// </summary>
    /// <param name="createdLib">The full name of the created library. This is the temporary library
    ///  containing the compiled c# sources</param>
    /// <param name="referencedLibs">List of libraries that are referenced by the temporary library</param>
    /// <param name="forceNamespaces">If false, namespaces are only generated if the library defines
    ///  more than one namespace</param>
    public DynamicGeneratorLoader(string createdLib, string[] referencedLibs)
    {
      this.forceNamespaces = forceNamespaces;
      createdAssembly = AddAssembly(createdLib);
      foreach (string r in referencedLibs)
      {
        AddAssembly(r);
      }
      AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(AssemblyResolve);
    }

    /// <summary>
    /// Triggers the generation of the documentation, on a separate thread
    /// </summary>
    /// <param name="typeInCreatedAssembly">Fully specified type name in the created assembly</param>
    /// <param name="xmlFile">Xml file with the generated documentation</param>
    /// <param name="targetDir">Directory to store the generated documentation</param>
    /// <param name="forceNamespaces">If false, namespaces are only generated if the library defines
    ///  more than one namespace</param>
    /// <param name="infoDelegate">Delegate to provide progress information</param>
    /// <param name="callback">Delegate to report that the generated ended</param>
    public void StartDocGeneration(string typeInCreatedAssembly, string xmlFile, string targetDir, bool forceNamespaces,
      InfoDelegate infoDelegate, InfoDelegate callback)
    {
      docGenerator = new DocGenerator(createdAssembly.GetType(typeInCreatedAssembly), infoDelegate, xmlFile);
      this.targetDir = targetDir;
      this.callback = callback;
      this.forceNamespaces = forceNamespaces;
      Thread thread = new Thread(new ThreadStart(ThreadedTriggerGeneration));
      thread.IsBackground = true;
      thread.Start();
    }

    /// <summary>
    /// Releases the created domain
    /// </summary>
    public void Destroy()
    {
      AppDomain.CurrentDomain.AssemblyResolve -= new ResolveEventHandler(AssemblyResolve);
    }

    /// <summary>
    /// Returns all the types in the created temporary library that matches the parameters
    /// </summary>
    /// <param name="lowerName">the name of the type to find, provided in lower case</param>
    /// <param name="fullMatch">if true, the given type is fully specified. Otherwise, any
    ///  type whose name matches is returned (even on different folders)</param>
    /// <returns></returns>
    public string[] GetLibTypes(string lowerCaseName, bool fullMatch)
    {
      List<string> types = new List<string>();
      foreach (Type t in createdAssembly.GetTypes())
      {
        if (lowerCaseName == null || lowerCaseName.Length==0)
        {
          types.Add(t.FullName);
        }
        else if (fullMatch)
        {
          if (t.Name.ToLower().Equals(lowerCaseName) || t.FullName.ToLower().Equals(lowerCaseName))
          {
            types.Add(t.FullName);
          }
        }
        else
        {
          if (t.Name.ToLower().StartsWith(lowerCaseName) || t.FullName.ToLower().StartsWith(lowerCaseName))
          {
            types.Add(t.FullName);
          }
        }
      }
      return types.ToArray();
    }

    /// <summary>
    /// Method to provide assemblies on demand to the AppDomain
    /// </summary>
    Assembly AssemblyResolve(object sender, ResolveEventArgs args)
    {
      Assembly ret;
      assemblies.TryGetValue(args.Name, out ret);
      return ret;
    }

    /// <summary>
    /// Adds the assembly to the app domain
    /// </summary>
    private Assembly AddAssembly(string name)
    {
      Assembly assembly = Assembly.LoadFile(name);
      assemblies.Add(assembly.GetName().FullName, assembly);
      assemblies.Add(assembly.GetName().Name, assembly); //we add as well the basic name, to be able to load 'XmlObjects'
      return assembly;
    }

    /// <summary>
    /// This is the method that generates the documentation on a separate thread
    /// </summary>
    private void ThreadedTriggerGeneration()
    {
      try
      {
        if (forceNamespaces)
          docGenerator.GenerateDocumentationWithNamespaces(targetDir); 
        else
          docGenerator.GenerateDocumentation(targetDir); 
        callback(null);
      }
      catch(Exception ex)
      {
        callback(ex.Message);
      }
    }

    private const string XMLOBJECTS_GENERATOR_METHOD = "GenerateDocumentation";
    private Dictionary<string, Assembly> assemblies = new Dictionary<string, Assembly>();
    private Assembly createdAssembly;
    private DocGenerator docGenerator;
    private InfoDelegate callback;
    private string targetDir;
    private bool forceNamespaces;
  }

}
