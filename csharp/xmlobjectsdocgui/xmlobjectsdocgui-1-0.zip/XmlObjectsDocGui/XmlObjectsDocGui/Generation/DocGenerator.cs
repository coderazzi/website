using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using System.IO;

using XmlObjectsDocGui.Proxies;

namespace XmlObjectsDocGui.Generation
{
  public class DocGenerator
  {
    private TypeHelperHandler handler;
    private TypeHelper typeHelper;
    private Type rootType;
    private DocInfoExtractor xmlDoc;
    private StreamWriter writer;
    private bool namespacedWriter, mentionNamespaces;
    private Dictionary<TypeHelper, List<TypeHelper>> usedBy;
    private Dictionary<TypeHelper, List<TypeHelper>> childs;
    private InfoDelegate infoDelegate;

    private const string CSS_FILE = "xmldoc.css";

    /// <summary>
    /// Constructor, requires the root type, and the files containing the XML documentation,
    /// as generated with /doc argument in the csc compiler
    /// </summary>
    /// <param name="rootType"></param>
    /// <param name="xlmFiles"></param>
    public DocGenerator(Type rootType, InfoDelegate infoDelegate, params string[] xlmFiles)
    {
      this.rootType = rootType;
      this.infoDelegate = infoDelegate;
      handler = new ProxyFactory().CreateTypeHelperHandler();
      typeHelper = handler.CreateInstance(rootType);
      usedBy = discoverUsedByRelationships();
      childs = discoverChildRelationships();
      xmlDoc = new DocInfoExtractor();
      foreach (string s in xlmFiles)
      {
        xmlDoc.Handle(s);
      }
    }

    /// <summary>
    /// Generates the documentation in the given path. Namespace information will be generated if it is
    ///  considered needed
    /// </summary>
    /// <param name="where">Path where the documentation is generated</param>
    public void GenerateDocumentation(String where)
    {
      GenerateDocumentation(where, false);
    }

    /// <summary>
    /// Generates the documentation, including namespace information even if it is not needed
    /// </summary>
    /// <param name="where">Path where the documentation is generated</param>
    public void GenerateDocumentationWithNamespaces(String where)
    {
      GenerateDocumentation(where, true);
    }

    /// <summary>
    /// Main generation method
    /// </summary>
    /// <param name="where">Path where the documentation is generated</param>
    /// <param name="forceNamespaces">If true, namespace information will be generated even if not needed</param>
    private void GenerateDocumentation(String where, bool forceNamespaces)
    {
      mentionNamespaces = forceNamespaces || areThereMultipleNamespaces();
      generateCssFile(where);
      foreach (TypeHelper th in handler.GetAllTypeHelpers())
      {
        generateType(where, th);
      }
    }

    /// <summary>
    /// Generates a file for the given typeHelper, in the given location
    /// </summary>
    private void generateType(String where, TypeHelper typeHelper)
    {
      if (requiresGeneration(typeHelper))
      {
        String name = getTypeNameToDisplay(typeHelper.XmlType);
        startGeneration(where, name, typeHelper);
        List<String> attributes = typeHelper.AttributeNames;
        attributes.Sort();
        List<String> elements = typeHelper.ElementNames;
        elements.Sort();
        generateSchemaInfo(name, typeHelper, attributes, elements);
        if (attributes.Count > 0)
        {
          generateAttributesInfo(typeHelper, attributes);
        }
        if (elements.Count > 0)
        {
          generateElementsInfo(typeHelper, elements);
        }
        completeGeneration();
      }
    }


    /// <summary>
    /// Generates the HTML area concerning the attributes for the given typeHelper
    /// </summary>
    private void generateAttributesInfo(TypeHelper typeHelper, List<String> attributes)
    {
      writer.WriteLine("<h2>Attributes</h2><div id='attributes'>");
      foreach (String s in attributes)
      {
        writer.WriteLine("<div class='anatt'><a name='{0}'><span class='attname'>{0}</span></a> : {1}</div>", s, getReferencedTypeString(typeHelper.GetAttributeHandler(s)));
        writer.WriteLine("<div class='anattmean'>{0}</div>", xmlDoc.GetFieldInfo(typeHelper.GetAttributeHandler(s).FieldInfo));
      }
      writer.WriteLine("</div>");
    }


    /// <summary>
    /// Generates the HTML area concerning the elements for the given typeHelper
    /// </summary>
    private void generateElementsInfo(TypeHelper typeHelper, List<String> elements)
    {
      writer.WriteLine("<h2>Elements</h2><div id='elements'>");
      foreach (String s in elements)
      {
        writer.WriteLine("<div class='anelem'><a name='{0}'><span class='elemname'>{0}</span></a> : {1}</div>", s,
          getReferencedTypeString(typeHelper.GetElementHandler(s)));
        writer.WriteLine("<div class='anelemmean'>{0}</div>", xmlDoc.GetFieldInfo(typeHelper.GetElementHandler(s).FieldInfo));
      }
      writer.WriteLine("</div>");
    }

    /// <summary>
    /// Generates the schema information
    /// </summary>
    private void generateSchemaInfo(String name, TypeHelper typeHelper, List<String> attributes, List<String> elements)
    {
      writer.Write("<h2>Schema</h2><pre id='schema'>&lt; {0} ", name);
      foreach (String s in attributes)
      {
        writer.Write("\n        <a href='#{0}'><span class='attname'>{0}</span></a> : {1}", s, getReferencedTypeString(typeHelper.GetAttributeHandler(s)));
      }
      if (elements.Count > 0)
      {
        if (attributes.Count > 0)
        {
          writer.WriteLine();
        }
        writer.WriteLine("&gt;");
        foreach (String s in elements)
        {
          writer.WriteLine("    &lt; <a href='#{0}'><span class='elemname'>{0}</span></a> : {1} /&gt;", s, getReferencedTypeString(typeHelper.GetElementHandler(s)));
        }
        writer.Write("&lt;/ {0} ", name);
      }
      else
      {
        FieldHandler inner = typeHelper.InnerTextField;
        if (inner == null)
        {
          writer.Write(" /");
        }
        else
        {
          writer.Write("&gt; {0} &lt; {1} /", getReferencedTypeString(inner), name);
        }
      }
      writer.WriteLine("&gt;</pre>");
    }


    /// <summary>
    /// Opens the writer
    /// and writes the top summary area
    /// </summary>
    private void startGeneration(String where, String name, TypeHelper typeHelper)
    {
      namespacedWriter = typeHelper.XmlType.Namespace != null;
      String baseDir = namespacedWriter ? Path.Combine(where, typeHelper.XmlType.Namespace) : where;
      if (!Directory.Exists(baseDir)) Directory.CreateDirectory(baseDir);
      writer = createWriter(Path.Combine(baseDir, getHtmlFilename(name)));
      writer.WriteLine("<html><head><Title>{0} - Xmlobjects documentation</Title>", name);
      writer.WriteLine("<link rel='stylesheet' type='text/css' href='{0}'></head>\n<body><h1>{1}</h1>", getCssFileReference(), name);
      writer.WriteLine("<div id='typeInfo'>");
      writer.WriteLine("<div id='summary'>{0}</div>", xmlDoc.GetTypeInfo(typeHelper.XmlType));
      generateUsedByInformation(typeHelper);
      generateInheritanceInformation(typeHelper);
      generateNamespaceInformation(typeHelper.XmlType);
      writer.WriteLine("</div>");
    }

    /// <summary>
    /// Responsible to define, if needed, the 'namespace' information
    /// </summary>
    private void generateNamespaceInformation(Type t)
    {
      if (mentionNamespaces)
      {
        writer.WriteLine("<div id='namespace'><span class='label'>Namespace: </span>{0}</div>",
          (t.Namespace == null ? "{ none }" : t.Namespace));
      }
    }

    /// <summary>
    /// Responsible to define, if needed, the 'childs' & 'inherits' information
    /// </summary>
    private void generateInheritanceInformation(TypeHelper typeHelper)
    {
      TypeHelper parent = typeHelper.ParentTypeHelper;
      if (parent != null & requiresGeneration(parent))
      {
        writer.WriteLine("<div id='inherits'><span class='label'>Inherits: </span>{0}</div>", getRelativeReferenceLink(parent.XmlType));
      }
      List<TypeHelper> rels;
      if (childs.TryGetValue(typeHelper, out rels))
      {
        writer.Write("<div id='childs'><span class='label'>Childs: </span>{0}</div>", convertListToString(getTypeHelperNames(rels)));
      }
    }

    /// <summary>
    /// Responsible to define, if needed, the 'used by' information
    /// </summary>
    private void generateUsedByInformation(TypeHelper typeHelper)
    {
      List<TypeHelper> rels;
      if (usedBy.TryGetValue(typeHelper, out rels))
      {
        writer.WriteLine("<div id='usedby'><span class='label'>Used by: </span>{0}</div>", convertListToString(getTypeHelperNames(rels)));
      }
    }

    /// <summary>
    /// End step on the generation
    /// </summary>
    private void completeGeneration()
    {
      writer.WriteLine("</body></html>");
      writer.Close();
    }

    /// <summary>
    /// Helper method to detect when all the required types belong to the same namespace
    /// </summary>
    private bool areThereMultipleNamespaces()
    {
      foreach (TypeHelper th in handler.GetAllTypeHelpers())
      {
        if (th.XmlType.Namespace != rootType.Namespace && requiresGeneration(th))
          return true;
      }
      return false;
    }

    /// <summary>
    /// Returns a reference to the css file.
    /// </summary>
    /// <returns></returns>
    private String getCssFileReference()
    {
      return namespacedWriter ? "../" + CSS_FILE : CSS_FILE; //html, no need to use Path.Combine
    }


    /// <summary>
    /// Converts typeHelpers to strings, as relative reference links
    /// </summary>
    private IEnumerable<String> getTypeHelperNames(List<TypeHelper> lth)
    {
      foreach (TypeHelper th in lth)
        yield return getRelativeReferenceLink(th.XmlType);
    }

    /// <summary>
    /// Whether to generate a file for the given type.
    /// It is only generated if if contains attributes or elements or include a text value
    /// </summary>
    private bool requiresGeneration(TypeHelper helper)
    {
      return !helper.SimpleType && (helper.DefineInnerTextField || helper.DefineFields);
    }

    /// <summary>
    /// Returns a string representing a field handler type
    /// This includes, in most cases, a HTML link to the file for that type
    /// </summary>
    private string getReferencedTypeString(FieldHandler fh)
    {
      Type type = fh.FieldInfo.FieldType;
      if (type.IsEnum)
      {
        return getEnumReference(type);
      }
      string app;
      if (type.IsArray)
      {
        app = " *";
        type = type.GetElementType();
      }
      else
      {
        app = "";
      }
      if (requiresGeneration(fh.TypeHelper))
      {
        return getRelativeReferenceLink(type) + app;
      }
      return String.Format("{0}{1}", getTypeNameToDisplay(type), app);
    }

    /// <summary>
    /// Creates the HTML href required to point to the given type
    /// </summary>
    private string getRelativeReferenceLink(Type t)
    {
      string typeName = getTypeNameToDisplay(t);
      StringBuilder sb = new StringBuilder("<a href='");
      if (namespacedWriter) sb.Append("../");
      if (t.Namespace != null) sb.Append(t.Namespace).Append('/');
      sb.Append(getHtmlFilename(typeName)).Append("'>").Append(typeName).Append("</a>");
      return sb.ToString();
    }

    /// <summary>
    /// Enum references are handled specifically: just provide the list of enumeration values
    /// </summary>
    private string getEnumReference(Type enumType)
    {
      return String.Format("{{ {0} }}", convertListToString(Enum.GetNames(enumType)));
    }

    /// <summary>
    /// Helper method to convert a list of strings into a string, with elements separated by commas
    /// </summary>
    private string convertListToString(IEnumerable<String> st)
    {
      bool first = true;
      StringBuilder sb = new StringBuilder();
      foreach (string s in st)
      {
        if (first)
        {
          first = false;
        }
        else
        {
          sb.Append(", ");
        }
        sb.Append(s);
      }
      return sb.ToString();
    }


    /// <summary>
    /// Returns the html file name associated to a given type
    /// </summary>
    private String getHtmlFilename(String name)
    {
      return name + ".html";
    }

    /// <summary>
    /// Returns the normalized name to display for a type.
    /// Basically, is the type name without namespace (but includes declaring types)
    /// </summary>
    private String getTypeNameToDisplay(Type type)
    {
      String ret = type.Name;
      if (type.DeclaringType != null)
      {
        return getTypeNameToDisplay(type.DeclaringType) + "." + ret;
      }
      return ret;
    }

    /// <summary>
    /// Creates a dictionary with all 'child' relationships
    /// </summary>
    /// <returns></returns>
    private Dictionary<TypeHelper, List<TypeHelper>> discoverChildRelationships()
    {
      Dictionary<TypeHelper, List<TypeHelper>> ret = new Dictionary<TypeHelper, List<TypeHelper>>();
      foreach (TypeHelper th in handler.GetAllTypeHelpers())
      {
        if (th.ParentTypeHelper != null)
        {
          List<TypeHelper> l;
          if (!ret.TryGetValue(th.ParentTypeHelper, out l))
          {
            l = new List<TypeHelper>();
            ret[th.ParentTypeHelper] = l;
          }
          l.Add(th);
        }
      }
      return ret;
    }

    /// <summary>
    /// Creates a dictionary with all 'used by' relationships
    /// </summary>
    /// <returns></returns>
    private Dictionary<TypeHelper, List<TypeHelper>> discoverUsedByRelationships()
    {
      Dictionary<TypeHelper, List<TypeHelper>> ret = new Dictionary<TypeHelper, List<TypeHelper>>();
      foreach (TypeHelper th in handler.GetAllTypeHelpers())
      {
        enterUsedByRelationship(ret, th, th.InnerTextField);
        foreach (String att in th.AttributeNames)
        {
          enterUsedByRelationship(ret, th, th.GetAttributeHandler(att));
        }
        foreach (String ele in th.ElementNames)
        {
          enterUsedByRelationship(ret, th, th.GetElementHandler(ele));
        }
      }
      foreach (List<TypeHelper> lth in ret.Values)
      {
        lth.Sort(new Comparison<TypeHelper>(compareTypeHelpers));
      }
      return ret;
    }

    /// <summary>
    /// Helper method to discoverUsedByRelationships
    /// </summary>
    /// <param name="where"></param>
    /// <param name="helper"></param>
    /// <param name="fh"></param>
    private void enterUsedByRelationship(Dictionary<TypeHelper, List<TypeHelper>> where, TypeHelper helper, FieldHandler fh)
    {
      if (fh != null && requiresGeneration(fh.TypeHelper))
      {
        List<TypeHelper> l;
        if (!where.TryGetValue(fh.TypeHelper, out l))
        {
          l = new List<TypeHelper>();
          where[fh.TypeHelper] = l;
        }
        l.Add(helper);
      }
    }

    /// <summary>
    /// method to compare two type helpers, just by using their names
    /// </summary>
    private int compareTypeHelpers(TypeHelper l, TypeHelper r)
    {
      return l.Name.CompareTo(r.Name);
    }


    /// <summary>
    /// Generates the css file
    /// </summary>
    private void generateCssFile(String where)
    {
      if (!Directory.Exists(where)) Directory.CreateDirectory(where);
      writer = createWriter(Path.Combine(where, CSS_FILE));
      writer.WriteLine("#typeinfo,#schema,#attributes,#elements{border:1px solid gray;padding:1em;margin-left:2em;background:#eeeeee;}");
      writer.WriteLine("#summary{background:#dddddd;padding:.25em;}");
      writer.WriteLine("#schema{font-family:monospace,courier;}");
      writer.WriteLine("#usedby,#childs,#inherits,#namespace {margin:1em 0em 0em 2em;}");
      writer.WriteLine("#attributes .attname,#elements .elemname,.label {font-weight:700;}");
      writer.WriteLine(".anatt,.anelem{font-size:125%;padding:1em;}");
      writer.WriteLine(".anattmean,.anelemmean{padding:0em 1em;margin-left:2em;border:1px solid #e2e2e2;background:#dddddd;}");
      writer.WriteLine("#schema a:link,#schema a:visited,#typeynfo a:link,#typeinfo a:visited,.anatt a:link,.anatt a:visited,.anelem a:link,.anelem a:visited{color: #007;});");
      writer.Close();
    }

    private StreamWriter createWriter(String path)
    {
      infoDelegate(String.Format(Properties.Resources.GeneratingFile, path));
      return new StreamWriter(path);
    }

  }
}

