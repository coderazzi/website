using System;
using System.Collections.Generic;
using System.Text;

namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// Proxy for the TypeHelperHandler instance in the XmlObjects library
  /// </summary>
  class TypeHelperHandlerProxy : Proxy, TypeHelperHandler
  {
    const string PROXY_CLASS = "XmlObjects.TypeHelperHandler";

    internal TypeHelperHandlerProxy(object instance, ProxyFactory proxyFactory)
      : base(instance, proxyFactory)
    {
    }

    public TypeHelper CreateInstance(Type xmlType)
    {
      return proxyFactory.GetTypeHelper(InvokeMethod(PROXY_CLASS, "CreateInstance", xmlType));
    }

    public List<TypeHelper> GetAllTypeHelpers()
    {
      List<TypeHelper> ret = new List<TypeHelper>();
      foreach (object o in (System.Collections.IList)InvokeMethod(PROXY_CLASS, "GetAllTypeHelpers"))
        ret.Add(proxyFactory.GetTypeHelper(o));
      return ret;
    }

  }
}
