using System;

using System.Reflection;

namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// Proxy for the FieldHandler instance in the XmlObjects library
  /// </summary>
  public class FieldHandlerProxy : Proxy, FieldHandler
  {
    const string PROXY_CLASS = "XmlObjects.FieldHandler";

    private FieldInfo fieldInfo;
    private TypeHelper typeHelper;

    internal FieldHandlerProxy(object instance, ProxyFactory proxyFactory)
      : base(instance, proxyFactory)
    {
      fieldInfo = (FieldInfo) GetProperty(PROXY_CLASS, "FieldInfo");
      typeHelper = proxyFactory.GetTypeHelper(GetProperty(PROXY_CLASS, "TypeHelper"));
    }
    public FieldInfo FieldInfo { get { return fieldInfo; } }
    public TypeHelper TypeHelper { get { return typeHelper; } }
  }
}
