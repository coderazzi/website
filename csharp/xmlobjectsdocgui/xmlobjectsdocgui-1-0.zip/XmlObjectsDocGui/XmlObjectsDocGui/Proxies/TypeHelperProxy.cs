using System;
using System.Collections.Generic;
using System.Text;

namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// Proxy for the TypeHelper instance in the XmlObjects library
  /// </summary>
  class TypeHelperProxy : Proxy, TypeHelper
  {
    const string PROXY_CLASS = "XmlObjects.TypeHelper";

    private List<String> attributeNames;
    private bool defineFields;
    private bool defineInnerTextField;
    private List<String> elementNames;
    private FieldHandler innerTextField;
    private string name;
    private TypeHelper parentTypeHelper;
    private bool simpleType;
    private Type xmlType;

    internal TypeHelperProxy(object instance, ProxyFactory proxyFactory)
      : base(instance, proxyFactory)
    {
      attributeNames = (List<String>) GetProperty(PROXY_CLASS,"AttributeNames");
      defineFields = (bool) GetProperty(PROXY_CLASS, "DefineFields");
      defineInnerTextField = (bool) GetProperty(PROXY_CLASS, "DefineInnerTextField");
      elementNames = (List<String>) GetProperty(PROXY_CLASS, "ElementNames");
      innerTextField = proxyFactory.GetFieldHandler(GetProperty(PROXY_CLASS, "InnerTextField"));
      name = (string) GetProperty(PROXY_CLASS, "Name");
      parentTypeHelper = proxyFactory.GetTypeHelper(GetProperty(PROXY_CLASS, "ParentTypeHelper"));
      simpleType = (bool) GetProperty(PROXY_CLASS, "SimpleType");
      xmlType = (Type)GetProperty(PROXY_CLASS, "XmlType");
    }

    public List<String> AttributeNames { get { return attributeNames; } }
    public bool DefineFields { get { return defineFields; } }
    public bool DefineInnerTextField { get { return defineInnerTextField; } }
    public List<String> ElementNames { get { return elementNames; } }
    public FieldHandler InnerTextField { get { return innerTextField; } }
    public string Name { get { return name; } }
    public TypeHelper ParentTypeHelper { get { return parentTypeHelper; } }
    public bool SimpleType { get { return simpleType; } }
    public Type XmlType { get { return xmlType; } }

    public FieldHandler GetAttributeHandler(string name) 
    {
      return proxyFactory.GetFieldHandler(InvokeMethod(PROXY_CLASS, "GetAttributeHandler", name)); 
    }
    public FieldHandler GetElementHandler(string name)
    {
      return proxyFactory.GetFieldHandler(InvokeMethod(PROXY_CLASS, "GetElementHandler", name));
    }

  }
}
