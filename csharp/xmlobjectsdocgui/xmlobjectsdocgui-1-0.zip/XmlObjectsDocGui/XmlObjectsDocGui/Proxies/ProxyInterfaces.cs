using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using System.IO;


namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// TypeHelperHandler is the interface for the TypeHelperHandler in the XmlObjects library.
  /// This interface is not implemented by the TypeHelperHandler, it represents the methods than
  /// can be called in the TypeHelperHandler using a specific proxy.
  /// </summary>
  public interface TypeHelperHandler {
    TypeHelper CreateInstance(Type xmlType);
    List<TypeHelper> GetAllTypeHelpers();
  }
  /// <summary>
  /// TypeHelper is the interface for the TypeHelper in the XmlObjects library.
  /// This interface is not implemented by the TypeHelper, it represents the methods than
  /// can be called in the TypeHelper using a specific proxy.
  /// </summary>
  public interface TypeHelper
  {
    List<String> AttributeNames { get; }
    bool DefineFields { get; }
    bool DefineInnerTextField { get; }
    List<String> ElementNames { get; }
    FieldHandler InnerTextField { get; }
    string Name { get; }
    TypeHelper ParentTypeHelper { get; }
    bool SimpleType { get; }
    Type XmlType { get; }

    FieldHandler GetAttributeHandler(string name);
    FieldHandler GetElementHandler(string name);
  }
  /// <summary>
  /// TypeHelper is the interface for the FieldHandler in the XmlObjects library.
  /// This interface is not implemented by the FieldHandler, it represents the methods than
  /// can be called in the FieldHandler using a specific proxy.
  /// </summary>
  public interface FieldHandler
  {
    FieldInfo FieldInfo { get;}
    TypeHelper TypeHelper { get;}
  }
}

