using System;
using System.Reflection;

namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// Parent class to all the Proxy clsses
  /// A proxy is used to load a class from a DLL, and interact with it.
  /// It needs to know its interface, but allows being independent of
  /// the implementation. It does not need to have a reference to the
  /// implementing DLL, which can be loaded at runtime.
  /// These classes are not generic proxies, are quite limited to the XmlObjects
  /// library.
  /// </summary>
  public class Proxy
  {
    private static Assembly xmlObjects;
    private static object[] emptyParameterList = new object[0];
    private static object[] oneParameterList = new object[1];
    private static Type[] oneParameterTypeList = new Type[1];

    protected ProxyFactory proxyFactory;
    protected object instance;

    /// <summary>
    /// Builds a root instance of the given type
    /// </summary>
    static public object BuildRootInstance(string typeName)
    {
      return new Proxy(null, null).GetAssembly().CreateInstance(typeName);
    }

    /// <summary>
    /// Creates a new proxy for a remote instance, using for any manipulation the 
    /// given proxy factory
    /// </summary>
    protected Proxy(object instance, ProxyFactory proxyFactory)
    {
      this.proxyFactory = proxyFactory;
      this.instance = instance;
    }

    /// <summary>
    /// Returns the given property on the remote instance, which must have the specified type
    /// </summary>
    protected object GetProperty(String type, String propertyName)
    {
      try
      {
        return GetAssembly().GetType(type).GetProperty(propertyName).GetGetMethod().Invoke(instance, emptyParameterList);
      }
      catch (Exception)
      {
        throw new Exception(String.Format(Properties.Resources.ErrorXmlObjectsLibrary, type));
      }
    }

    /// <summary>
    /// Invokes a method on the remote instance, with one single argument, and then returns the specified type
    /// </summary>
    protected object InvokeMethod(String type, String methodName, object argument)
    {
      oneParameterList[0] = argument;
      oneParameterTypeList[0] = argument.GetType();
      try
      {
        return GetAssembly().GetType(type).GetMethod(methodName, oneParameterTypeList).Invoke(instance, oneParameterList);
      }
      catch (Exception)
      {
        throw new Exception(String.Format(Properties.Resources.ErrorXmlObjectsLibrary, type));
      }
    }

    /// <summary>
    /// Invokes a method on the remote instance, without arguments, and then returns the specified type
    /// </summary>
    protected object InvokeMethod(String type, String methodName)
    {
      try
      {
        return GetAssembly().GetType(type).GetMethod(methodName).Invoke(instance, emptyParameterList);
      }
      catch (Exception)
      {
        throw new Exception(String.Format(Properties.Resources.ErrorXmlObjectsLibrary, type));
      }
    }

    /// <summary>
    /// Internal method, returns the XmlObjects assembly
    /// </summary>
    /// <returns></returns>
    private Assembly GetAssembly()
    {
      if (xmlObjects == null)
      {
        xmlObjects = Assembly.Load("XmlObjects");
      }
      return xmlObjects;
    }
  }
}
