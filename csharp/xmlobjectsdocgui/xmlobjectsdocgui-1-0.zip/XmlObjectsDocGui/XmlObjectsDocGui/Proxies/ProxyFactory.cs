using System;
using System.Collections.Generic;
using System.Reflection;

namespace XmlObjectsDocGui.Proxies
{
  /// <summary>
  /// Factory to build all the proxies.
  /// It creates proxies in demand, associating always the same proxy instance for a given remote instance.
  /// That is, a remote instance is handled by just one proxy, even if that instance appears repeatedly in the execution
  /// </summary>
  public class ProxyFactory
  {
    private Dictionary<object, FieldHandler> fieldHandlers = new Dictionary<object, FieldHandler>();
    private Dictionary<object, TypeHelper> typeHelpers = new Dictionary<object, TypeHelper>();

    /// <summary>
    /// Creates the TypeHelperHandler proxy, used to access afterwards all the remote instances
    /// (TypeHelperHandler is the main helper object in the XmlObjects library)
    /// </summary>
    public TypeHelperHandler CreateTypeHelperHandler()
    {
      return new TypeHelperHandlerProxy(Proxy.BuildRootInstance("XmlObjects.TypeHelperHandler"), this); ;
    }

    /// <summary>
    /// Returns a proxy for a given FieldHandler remote instance
    /// </summary>
    public FieldHandler GetFieldHandler(object fieldHandler)
    {
      FieldHandler ret=null;
      if (fieldHandler!=null && !fieldHandlers.TryGetValue(fieldHandler, out ret))
      {
        ret = new FieldHandlerProxy(fieldHandler, this);
        fieldHandlers.Add(fieldHandler, ret);
      }
      return ret;
    }

    /// <summary>
    /// Returns a proxy for a given TypeHelper remote instance
    /// </summary>
    public TypeHelper GetTypeHelper(object typeHelper)
    {
      TypeHelper ret = null;
      if (typeHelper != null && !typeHelpers.TryGetValue(typeHelper, out ret))
      {
        ret = new TypeHelperProxy(typeHelper, this);
        typeHelpers.Add(typeHelper, ret);
      }
      return ret;
    }
  }
}
