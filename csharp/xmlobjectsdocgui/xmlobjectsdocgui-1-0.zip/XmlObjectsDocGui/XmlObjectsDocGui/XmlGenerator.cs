using System.Threading;

namespace XmlObjectsDocGui
{
  /// <summary>
  /// Class to generate the XML files, by invoking the csc compiler
  /// </summary>
  class XmlGenerator
  {

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="csc">the compiler to use</param>
    /// <param name="output">the delegate to report the compilation progress</param>
    /// <param name="csFiles">files to pass to the compiler</param>
    /// <param name="references">any library referenced by those csFiles, needed to complete the compilation</param>
    public XmlGenerator(string csc, InfoDelegate output, string[] csFiles, string[] references)
    {
      this.csc = csc;
      this.output = output;
      this.csFiles = csFiles;
      this.references = references;
    }

    /// <summary>
    /// Generates the documentation, using a separate thread
    /// </summary>
    /// <param name="callback">the delegate to report that the generation has ended</param>
    public void GenerateOnSeparateThread(ResultDelegate callback)
    {
      this.callback = callback;
      Thread thread = new Thread(new ThreadStart(GenerateInThread));
      thread.IsBackground = true;
      thread.Start();
    }

    /// <summary>
    /// GUI method, to remove any temporary files, on a separate thread
    /// </summary>
    public void CleanUpOnSeparateThread()
    {
      Thread thread = new Thread(new ThreadStart(CleanUpInThread));
      thread.IsBackground = true;
      thread.Start();
    }

    /// <summary>
    /// Internal method, to remove the temporary files.
    /// </summary>
    private void CleanUpInThread()
    {
      try
      {
        if (xmlFile != null)
          System.IO.File.Delete(xmlFile);
        //libFile cannot be removed (on use, was loaded)
      }
      catch (System.Exception)
      {
      }
    }

    /// <summary>
    /// Internal method, to perform the required compilation
    /// </summary>
    private void GenerateInThread()
    {
      xmlFile = System.IO.Path.GetTempFileName();
      libFile = System.IO.Path.GetTempFileName();
      System.Text.StringBuilder sb = new System.Text.StringBuilder();
      sb.Append("/doc:\"").Append(xmlFile).Append("\" /t:library /out:\"").Append(libFile).Append('"');
      foreach (string s in references)
        sb.Append(" /r:\"").Append(s).Append('"');
      foreach (string s in csFiles)
        sb.Append(" \"").Append(s).Append('"');

      System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo();
      info.FileName = csc;
      info.Arguments = sb.ToString();
      info.CreateNoWindow = true;
      info.UseShellExecute = false;
      info.RedirectStandardError = true;
      info.RedirectStandardOutput = true;

      System.Diagnostics.Process process = new System.Diagnostics.Process();
      process.ErrorDataReceived += new System.Diagnostics.DataReceivedEventHandler(CmdErrorsReceived);
      process.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler(CmdOutputReceived);
      process.StartInfo = info;
      bool b = process.Start();
      if (b) process.BeginErrorReadLine();
      if (b) process.BeginOutputReadLine();
      process.WaitForExit();
      callback(process.ExitCode);
    }

    /// <summary>
    /// Called during the compilation, if there is any error output. It just redirects the output to the 
    /// progress delegate.
    /// </summary>
    private void CmdErrorsReceived(object o, System.Diagnostics.DataReceivedEventArgs a)
    {
      if (a.Data != null)
      {
        output(a.Data);
      }
    }

    /// <summary>
    /// Called during the compilation, if there is any normal output. It just redirects the output to the 
    /// progress delegate.
    /// </summary>
    private void CmdOutputReceived(object o, System.Diagnostics.DataReceivedEventArgs a)
    {
      if (a.Data != null)
      {
        output(a.Data);
      }
    }

    /// <summary>
    /// Returns the created lib file
    /// </summary>
    public string LibFile
    {
      get
      {
        return libFile;
      }
    }

    /// <summary>
    /// Returns the created documentation file
    /// </summary>
    public string XmlFile
    {
      get
      {
        return xmlFile;
      }
    }

    /// <summary>
    /// Returns the list of references passed on the constructor
    /// </summary>
    public string[] AssemblyReferences
    {
      get
      {
        return references;
      }
    }

    private InfoDelegate output;
    private string xmlFile, libFile, csc;
    private string []csFiles;
    private string[] references;
    private ResultDelegate callback;
  }
}
