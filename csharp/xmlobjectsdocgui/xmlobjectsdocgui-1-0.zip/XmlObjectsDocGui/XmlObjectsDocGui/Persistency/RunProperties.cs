using System;
using System.Collections.Generic;
using System.Text;

namespace XmlObjectsDocGui.Persistency
{
  /// <summary>
  /// Information stored in the properties file.
  /// For simplicity when editing the file, all fields are stored as elements, none as attributes
  /// </summary>
  [XmlObjects.XmlType(AttributeFields=false)]
  public class RunProperties
  {
    public string cscCompiler;
    public bool forceNamespaceGeneration;
    public bool promptDialog;
    public string rootType;
    public string targetDir;
    public string[] csharpFiles;
    public string[] references;
    public string defaultCsharpDir;
    public string defaultReferencesDir;
  }
}
