using System;
using System.IO;
using System.Xml;

namespace XmlObjectsDocGui.Persistency
{
  /// <summary>
  /// Class to provide persistency between runs.
  /// This is the only element in the project that requires XmlObjects
  /// </summary>
  public class PersistencyHandler
  {
    private XmlObjects.XmlObjectsManager manager;
    private string dirName;
    public PersistencyHandler()
    {
      manager = new XmlObjects.XmlObjectsManager();
      dirName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XmlObjectsDocGui");
    }
    /// <summary>
    /// Saves the properties in the application directory (in Documents..../AppData by default)
    /// It never exposes any problem. If cannot be saved, the error is silently ignored
    /// </summary>
    public void Save(RunProperties props)
    {
      try
      {
        if (!Directory.Exists(dirName))
        {
          Directory.CreateDirectory(dirName);
        }
        XmlTextWriter writer = new XmlTextWriter(FileName, null);
        writer.Formatting=Formatting.Indented;
        manager.Save(props, writer);
      }
      catch (Exception) {}
    }

    /// <summary>
    /// Loads the properties from the application directory (in Documents..../AppData by default)
    /// It never exposes any problem. If cannot be loaded, default values are returned.
    /// </summary>
    public RunProperties Load()
    {
      try
      {
        return (RunProperties) manager.Load(typeof(RunProperties), new StreamReader(FileName));
      }
      catch (Exception)
      {
        RunProperties ret = new RunProperties();
        ret.csharpFiles   = new string[0];
        ret.promptDialog  = true;
        ret.references    = new string[0];
        return ret;
      }
    }
    private string FileName
    {
      get 
      {
        return Path.Combine(dirName, "lastRunInfo.xml");
      }
    }
  }
}
