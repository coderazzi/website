using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace XmlObjectsDocGui
{
  /// <summary>
  /// Form to select the base type. It is used if the user selects the Promp dialog
  /// option in the main form, or the given root type is invalid
  /// </summary>
  public partial class TypeSelector : Form
  {
    /// <summary>
    /// Constructor, requires the dynamic generator loader, to get the existing types,
    /// and the root type, which can be partially specified
    /// </summary>
    public TypeSelector(DynamicGeneratorLoader loader, string rootType)
    {
      this.loader = loader;
      InitializeComponent();
      UpdateListTypes();
    }

    /// <summary>
    /// Updates the shown types, using the root type as non full specifiction
    /// (that is, the rootType does not fully specify the type, can be only
    /// the initial letters of the name or full name)
    /// </summary>
    private void UpdateListTypes()
    {
      object selected = listTypes.SelectedItem;
      listTypes.Items.Clear();
      listTypes.Items.AddRange(loader.GetLibTypes(textType.Text.Trim().ToLower(), false));
      if (listTypes.Items.Count == 1)
      {
        listTypes.SelectedItem = listTypes.Items[0];
        this.selected = (string) listTypes.SelectedItem;
      }
      else
      {
        listTypes.SelectedItem = selected;
      }
      buttonSelect.Enabled = listTypes.SelectedItem != null;
    }

    /// <summary>
    /// Returns the selected type
    /// </summary>
    public string SelectedType
    {
      get
      {
        return selected;
      }
    }

    /// <summary>
    /// GUI event, called when the user selects a type in the list box
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TypeSelectedEvent(object sender, EventArgs e)
    {
      selected = (string)listTypes.SelectedItem;
      buttonSelect.Enabled = listTypes.SelectedItem != null;
    }

    /// <summary>
    /// GUI event, called when the user updates the text in the roo type textbox
    /// </summary>
    private void RootTypeChangedEvent(object sender, EventArgs e)
    {
      UpdateListTypes();
    }

    private DynamicGeneratorLoader loader;
    private string selected;

  }
}