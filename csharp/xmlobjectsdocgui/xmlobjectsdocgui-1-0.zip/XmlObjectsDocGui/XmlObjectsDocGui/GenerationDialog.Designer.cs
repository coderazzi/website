
namespace XmlObjectsDocGui
{
  partial class GenerationDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.buttonExit = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.textStatus = new System.Windows.Forms.TextBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.panel2 = new System.Windows.Forms.Panel();
      this.groupBox1.SuspendLayout();
      this.panel1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // buttonExit
      // 
      this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.buttonExit.Enabled = false;
      this.buttonExit.Location = new System.Drawing.Point(12, 9);
      this.buttonExit.Name = "buttonExit";
      this.buttonExit.Size = new System.Drawing.Size(107, 23);
      this.buttonExit.TabIndex = 2;
      this.buttonExit.Text = "Exit";
      this.buttonExit.UseVisualStyleBackColor = true;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.textStatus);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(791, 248);
      this.groupBox1.TabIndex = 6;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Progress";
      // 
      // textStatus
      // 
      this.textStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.textStatus.Location = new System.Drawing.Point(13, 20);
      this.textStatus.Multiline = true;
      this.textStatus.Name = "textStatus";
      this.textStatus.ReadOnly = true;
      this.textStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.textStatus.Size = new System.Drawing.Size(766, 222);
      this.textStatus.TabIndex = 0;
      this.textStatus.WordWrap = false;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.buttonExit);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel1.Location = new System.Drawing.Point(0, 248);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(791, 44);
      this.panel1.TabIndex = 7;
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.groupBox1);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(0, 0);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(791, 248);
      this.panel2.TabIndex = 8;
      // 
      // GenerationDialog
      // 
      this.AcceptButton = this.buttonExit;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(791, 292);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.panel1);
      this.Name = "GenerationDialog";
      this.Text = "Generating documentation";
      this.Shown += new System.EventHandler(this.FormLoadedEvent);
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormClosingEvent);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button buttonExit;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.TextBox textStatus;
    private System.Windows.Forms.Panel panel2;
  }
}