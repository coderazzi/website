using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace XmlObjectsDocGui
{
  using Persistency;

  /// <summary>
  /// Main form
  /// </summary>
  public partial class MainForm : Form
  {

    private PersistencyHandler persistencyHandler;
    private RunProperties properties;

    public MainForm()
    {
      InitializeComponent();
    }

    /// <summary>
    /// Opens the passed dialog, and, if the user presses Ok, adds the selected files to the
    /// passed list; it returns the directory selected by the user, or, if the user cancelled,
    /// the initial directory
    /// </summary>    
    private string AddToList(OpenFileDialog dialog, ListBox list)
    {
      string ret = dialog.InitialDirectory;
      if (DialogResult.OK == dialog.ShowDialog())
      {
        ret = Path.GetDirectoryName(dialog.FileName);
        AddToList(list, dialog.FileNames);
      }
      return ret;
    }

    /// <summary>
    /// Adds to the passed listbox all the passed items, which must be valid files. It discards any repetitions
    /// </summary>
    private void AddToList(ListBox list, string[] what)
    {
      list.SelectedItems.Clear();
      foreach (string s in what)
      {
        if (!list.Items.Contains(s))
        {
          list.Items.Add(s);
          list.SelectedItems.Add(s);
        }
      }
      if (list==listFiles)CheckGenerateButton();
    }

    /// <summary>
    /// Removes from the passed listbox all the selected elements
    /// </summary>
    private void RemoveSelectedElementsFromListbox(ListBox list)
    {
      while (true)
      {
        int s = list.SelectedIndex;
        if (s >= 0)
        {
          list.Items.RemoveAt(s);
        }
        else
        {
          break;
        }
      }
    }

    /// <summary>
    /// Method to determine whether to enable ot not the Generate Button
    /// It requires all the information to be present: csc compiler, cs files, target directory
    /// </summary>
    private void CheckGenerateButton()
    {
      buttonGenerate.Enabled = editTarget.Text.Trim().Length > 0 && cscCompilerText.Text.Trim().Length > 0 && listFiles.Items.Count > 0;
    }

    /// <summary>
    /// Internal method, returns as a list of strings the content of a listbox
    /// </summary>
    private string[] GetItems(ListBox list)
    {
      string[] ret = new string[list.Items.Count];
      list.Items.CopyTo(ret, 0);
      return ret;
    }

    /// <summary>
    /// Method to load the properties. It is not a GUI method
    /// </summary>
    private void LoadProperties()
    {
      persistencyHandler = new PersistencyHandler();
      properties = persistencyHandler.Load();
      dialogTarget.SelectedPath = properties.targetDir;
      if (properties.cscCompiler != null && File.Exists(properties.cscCompiler))
      {
        dialogCompiler.InitialDirectory = Path.GetDirectoryName(properties.cscCompiler);
        dialogCompiler.FileName = Path.GetFileName(properties.cscCompiler);
      }
      if (properties.defaultReferencesDir != null && properties.defaultReferencesDir.Trim().Length>0)
      {
        dialogReference.InitialDirectory = properties.defaultReferencesDir;
      }
      if (properties.defaultCsharpDir != null && properties.defaultCsharpDir.Trim().Length > 0)
      {
        dialogFile.InitialDirectory = properties.defaultCsharpDir;
      }
      Invoke(new MethodInvoker(DisplayInitialProperties));
    }

    /// <summary>
    /// Internal GUI method, called to display the initial properties
    /// </summary>
    private void DisplayInitialProperties()
    {
      foreach (string lr in properties.references) listReferences.Items.Add(lr);
      foreach (string lr in properties.csharpFiles) listFiles.Items.Add(lr);
      editTarget.Text = properties.targetDir;
      cscCompilerText.Text = properties.cscCompiler;
      textType.Text = properties.rootType;
      checkPrompt.Checked = properties.promptDialog;
      namespaceCheckBox.Checked = properties.forceNamespaceGeneration;

      Cursor = Cursors.Default;
      mainPanel.Enabled = true;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //////  G U I   E V E N T S
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////


    /// <summary>
    /// Initial loaded form event. It spawns a thread to load the properties
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void FormLoadedEvent(object sender, EventArgs e)
    {
      mainPanel.Enabled = false;
      Cursor = Cursors.AppStarting;

      Thread thread = new Thread(new ThreadStart(LoadProperties));
      thread.Start();
    }

    /// <summary>
    /// Invoked when the user clicks the button to browse for the compiler
    /// </summary>
    private void SelectCompilerEvent(object sender, MouseEventArgs e)
    {
      if (DialogResult.OK == dialogCompiler.ShowDialog())
        cscCompilerText.Text = dialogCompiler.FileName;
    }

    /// <summary>
    /// Invoked when the user clicks the button to browse for the target directory
    /// </summary>
    private void SelectTargetEvent(object sender, MouseEventArgs e)
    {
      if (DialogResult.OK == dialogTarget.ShowDialog())
        editTarget.Text = dialogTarget.SelectedPath;
    }

    /// <summary>
    /// Method called by GUI when user presses the ADD... button on C# files
    /// </summary>
    private void AddFileEvent(object sender, MouseEventArgs e)
    {
      properties.defaultCsharpDir = AddToList(dialogFile, listFiles);
    }

    /// <summary>
    /// Method called by GUI when user presses the ADD... button on the references
    /// </summary>
    private void AddReferenceEvent(object sender, MouseEventArgs e)
    {
      properties.defaultReferencesDir = AddToList(dialogReference, listReferences);
    }

    /// <summary>
    /// Invoked when the user presses the Remove button on the c# files
    /// </summary>
    private void RemoveFileEvent(object sender, MouseEventArgs e)
    {
      RemoveSelectedElementsFromListbox(listFiles);
      CheckGenerateButton();
    }

    /// <summary>
    /// Invoked when the user presses the Remove button on the references
    /// </summary>
    private void RemoveReferenceEvent(object sender, MouseEventArgs e)
    {
      RemoveSelectedElementsFromListbox(listReferences);
    }

    /// <summary>
    /// Invoked when the user changes the selected files in the C# files listbox
    /// It is used to enable/disable the remove button
    /// </summary>
    private void ChangedFileSelectionEvent(object sender, EventArgs e)
    {
      buttonRemoveFile.Enabled = listFiles.SelectedIndex >= 0;
    }

    /// <summary>
    /// Invoked when the user changes the selected files in the references listbox
    /// It is used to enable/disable the remove button
    /// </summary>
    private void ChangedReferenceSelectionEvent(object sender, EventArgs e)
    {
      buttonRemoveReference.Enabled = listReferences.SelectedIndex >= 0;
    }

    /// <summary>
    /// Event called by the Gui when the user modifies the target directory or the compiler, to
    /// verify then if the generate button must be enabled or not
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void CheckGenerateButtonEvent(object sender, EventArgs e)
    {
      CheckGenerateButton();
    }


    /// <summary>
    /// User changes the 'promp dialog' checkbox
    /// </summary>
    private void PromptCheckChangedEvent(object sender, EventArgs e)
    {
      textType.Enabled = !checkPrompt.Checked;
    }

    /// <summary>
    /// Event supporting dragging events. It is called when the user dropts a directory
    /// on any of the listboxes (files or references)
    /// </summary>
    private void DropFileInListboxEvent(object sender, DragEventArgs e)
    {
      AddToList((ListBox)sender, (string[])e.Data.GetData(DataFormats.FileDrop));
    }


    /// <summary>
    /// Event supporting dragging events. It is called when the user drops a file/directory
    /// on a textbox (csc compiler or target directory)
    /// </summary>
    private void DropFileInTextboxEvent(object sender, DragEventArgs e)
    {
      ((TextBox)sender).Text = ((string[])(e.Data.GetData(DataFormats.FileDrop)))[0];
    }

    /// <summary>
    /// Event supporting dragging events. It supports dragging existing directories
    /// It is called when the user enters a drag action on the tareget dir text box
    /// </summary>
    private void DraggedDirectoryEnterEvent(object sender, DragEventArgs e)
    {
      e.Effect = DragDropEffects.None;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        string[] all = (string[])e.Data.GetData(DataFormats.FileDrop);
        if (all.Length == 1 && !File.Exists(all[0]))
        {
          e.Effect = DragDropEffects.Copy;
        }
      }
    }

    /// <summary>
    /// Event supporting dragging events. It supports dragging existing files
    /// It is called when the user enters a drag action on the files/references list boxes,
    /// or in the compiler textbox (the check is different for the target directory)
    /// </summary>
    private void DraggedFileEnterEvent(object sender, DragEventArgs e)
    {
      e.Effect = DragDropEffects.None;
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        foreach (string s in (string[])e.Data.GetData(DataFormats.FileDrop))
        {
          if (File.Exists(s))
          {
            e.Effect = DragDropEffects.Copy;
            return;
          }
        }
      }
    }

    /// <summary>
    /// Called when the user chooses About... in the menu
    /// </summary>
    private void MenuAboutEvent(object sender, EventArgs e)
    {
      MessageBox.Show(this, "XmlObjectsDocGui v1.0\n(c)2008, LuisM Pena\nhttp://www.byteslooser.com/csharp/XmlObjectsDocGui   ",
        "About...", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    /// <summary>
    /// Called by Gui when the application exits
    /// </summary>
    private void QuittingAppEvent(object sender, FormClosingEventArgs e)
    {
      if (properties!=null)
        persistencyHandler.Save(properties);
    }

    /// <summary>
    /// Method called when the user selects Exit in the menu
    /// </summary>
    private void MenuExitEvent(object sender, EventArgs e)
    {
      Application.Exit();
    }

    /// <summary>
    /// Method called when the user presses the Generate Documentation button
    /// </summary>
    private void GeneratedDocumentationEvent(object sender, MouseEventArgs e)
    {
      string givenType = textType.Enabled ? textType.Text.Trim().ToLower() : null;
      properties.forceNamespaceGeneration = namespaceCheckBox.Checked;
      properties.promptDialog = checkPrompt.Checked;
      properties.rootType = textType.Text.Trim().ToLower();
      properties.csharpFiles = GetItems(listFiles);
      properties.references = GetItems(listReferences);
      properties.targetDir = editTarget.Text;
      properties.cscCompiler = cscCompilerText.Text;
      new GenerationDialog(properties).ShowDialog();
    }

  }
}