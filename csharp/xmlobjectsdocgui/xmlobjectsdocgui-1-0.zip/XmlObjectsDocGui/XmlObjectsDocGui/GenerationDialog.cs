using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using System.Threading;

namespace XmlObjectsDocGui
{
  using Persistency;

  /// <summary>
  /// Dialog used during the generation. It just exposes the flow of events, as user can only
  /// press Exit when finished
  /// </summary>
  public partial class GenerationDialog : Form
  {

    public GenerationDialog(RunProperties runProperties)
    {
      this.guiDisplayOutputDelegate = new InfoDelegate(GuiDisplayOutput);
      this.guiDisplayDelegate = new InfoDelegate(GuiDisplayProgress);

      this.forceNamespaces = runProperties.forceNamespaceGeneration;
      this.rootType = runProperties.promptDialog? null : runProperties.rootType;
      this.targetDir = runProperties.targetDir;
      this.xmlGenerator = new XmlGenerator(runProperties.cscCompiler, new InfoDelegate(ThreadDisplayOutput), 
        runProperties.csharpFiles, runProperties.references);

      InitializeComponent();
      textStatus.Font = new Font(FontFamily.GenericMonospace, 9);
    }

    /// <summary>
    /// Called just when the dialog is shown. It automatically starts the doc generation
    /// on a new thread
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void FormLoadedEvent(object sender, EventArgs e)
    {
      GuiDisplayProgress(Properties.Resources.GenerationStep1);
      xmlGenerator.GenerateOnSeparateThread(new ResultDelegate(ThreadXmlGenerationCompleted));
    }

    /// <summary>
    /// Event if the user tries to close the form by any means.
    /// It only allows it if the exit button is already enabled
    /// </summary>
    private void FormClosingEvent(object sender, FormClosingEventArgs e)
    {
      e.Cancel = !buttonExit.Enabled;
    }

    /// <summary>
    /// called indirectly by the xmlGenerator when the generation completes
    /// This call is done in the gui thread
    /// </summary>
    /// <param name="errorCode"></param>
    private void GuiXmlGenerationCompleted(int errorCode)
    {
      if (errorCode != 0)
      {
        CompletedGeneration(Properties.Resources.ErrorStep1);
      }
      else
      {
        GuiDisplayProgress(Properties.Resources.GenerationStep2);
        //we load the DocGenerator in a new domain, to be able to unload all the associated assemblies
        if (newDomain != null)
          AppDomain.Unload(newDomain);
        newDomain = AppDomain.CreateDomain("loadingDomain", null, null);
        try
        {

          GuiGenerateDocumentation((DynamicGeneratorLoader)newDomain.CreateInstanceAndUnwrap(
            GetType().Assembly.FullName,
            "XmlObjectsDocGui.DynamicGeneratorLoader", 
            false, 
            0, 
            null,
            new object[] { xmlGenerator.LibFile, xmlGenerator.AssemblyReferences},
            null, 
            null, 
            null));
        }
        catch (Exception ex)
        {
          CompletedGeneration(ex.Message);
          AppDomain.Unload(newDomain);
          newDomain = null;
        }
      }
    }


    /// <summary>
    /// Method invoked in the Gui thread to initiate the documentation generation
    /// </summary>
    /// <param name="loader"></param>
    private void GuiGenerateDocumentation(DynamicGeneratorLoader loader)
    {
      string[] validTypes=loader.GetLibTypes(rootType, true);
      string selected;
      if (validTypes.Length == 1)
      {
        selected = validTypes[0];
      }
      else
      {
        TypeSelector ts = new TypeSelector(loader, rootType);
        if (DialogResult.Cancel == ts.ShowDialog())
        {
          //if the user cancels the type selector, just cancel the whole generation
          xmlGenerator.CleanUpOnSeparateThread();
          buttonExit.Enabled = true;
          buttonExit.PerformClick();
          return;
        }
        else
        {
          selected = ts.SelectedType;
        }
      }
      loader.StartDocGeneration(selected, xmlGenerator.XmlFile, targetDir, forceNamespaces,
        new InfoDelegate(ThreadDisplayProgress), new InfoDelegate(ThreadedCompletedGeneration));
    }

    /// <summary>
    /// Called when the generation is completed. This is a GUI method
    /// </summary>
    /// <param name="errorMessage">null if there is not error</param>
    private void CompletedGeneration(string errorMessage)
    {
      buttonExit.Enabled = true;
      buttonExit.Focus();
      if (errorMessage==null)
      {
        GuiDisplayProgress(Properties.Resources.GenerationDone);
      }
      else
      {
        MessageBox.Show(this, errorMessage,
          Properties.Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
        GuiDisplayProgress(Properties.Resources.ErrorTitle);
      }
      xmlGenerator.CleanUpOnSeparateThread();
    }

    /// <summary>
    /// Gui-Called to display the progress. It is analogous to GuiDisplayOutput, but formats the information
    /// in a different way
    /// </summary>
    /// <param name="step"></param>
    void GuiDisplayProgress(string step)
    {
      textStatus.Text += step;
      textStatus.Text += "\r\n";
      textStatus.SelectionStart = textStatus.Text.Length;
      textStatus.ScrollToCaret();
    }

    /// <summary>
    /// Method equivalent to GuiDisplayProgress, called on a non Gui thread
    /// </summary>
    /// <param name="info"></param>
    private void ThreadDisplayProgress(string info)
    {
      Invoke(guiDisplayDelegate, info);
    }

    /// <summary>
    /// Called to display the output by the generator. This method partners with ThreadDisplayOutput,
    /// which is called on a non gui thread, and then invokes this method on the Gui thread
    /// </summary>
    /// <param name="output"></param>
    void GuiDisplayOutput(string output)
    {
      foreach (string l in output.Split('\n'))
      {
        textStatus.Text += "  > " + l + "\r\n";
      }
      textStatus.SelectionStart = textStatus.Text.Length;
      textStatus.ScrollToCaret();
    }

    /// <summary>
    /// Method called by the XmlGenerator to show the compiler's output
    /// </summary>
    private void ThreadDisplayOutput(string output)
    {
      Invoke(guiDisplayOutputDelegate, output);
    }

    /// <summary>
    /// Method called when the whole generation finishes.
    /// This call is done on a non-gui thread
    /// </summary>
    private void ThreadedCompletedGeneration(string errorMessage)
    {
      Invoke(new InfoDelegate(CompletedGeneration), errorMessage);
    }

    /// <summary>
    /// The xmlGenerator invokes this method when the generation completes.
    /// This call is done on a non-gui thread
    /// </summary>
    private void ThreadXmlGenerationCompleted(int errorCode)
    {
      Invoke(new ResultDelegate(GuiXmlGenerationCompleted), errorCode);
    }


    private InfoDelegate guiDisplayOutputDelegate, guiDisplayDelegate;
    private string rootType;
    private string targetDir;
    private bool forceNamespaces;
    private XmlGenerator xmlGenerator;
    private AppDomain newDomain;

  }
}