namespace XmlObjectsDocGui
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.dialogTarget = new System.Windows.Forms.FolderBrowserDialog();
      this.dialogFile = new System.Windows.Forms.OpenFileDialog();
      this.dialogReference = new System.Windows.Forms.OpenFileDialog();
      this.gbox2 = new System.Windows.Forms.GroupBox();
      this.namespaceCheckBox = new System.Windows.Forms.CheckBox();
      this.textType = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.checkPrompt = new System.Windows.Forms.CheckBox();
      this.mainPanel = new System.Windows.Forms.Panel();
      this.panel2 = new System.Windows.Forms.Panel();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.listFilesBox = new System.Windows.Forms.GroupBox();
      this.listFiles = new System.Windows.Forms.ListBox();
      this.buttonRemoveFile = new System.Windows.Forms.Button();
      this.buttonAddFile = new System.Windows.Forms.Button();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.listReferences = new System.Windows.Forms.ListBox();
      this.buttonRemoveReference = new System.Windows.Forms.Button();
      this.buttonAddReference = new System.Windows.Forms.Button();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.buttonCscCompiler = new System.Windows.Forms.Button();
      this.cscCompilerText = new System.Windows.Forms.TextBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.buttonTarget = new System.Windows.Forms.Button();
      this.editTarget = new System.Windows.Forms.TextBox();
      this.panel3 = new System.Windows.Forms.Panel();
      this.buttonGenerate = new System.Windows.Forms.Button();
      this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.dialogCompiler = new System.Windows.Forms.OpenFileDialog();
      this.menuStrip1.SuspendLayout();
      this.gbox2.SuspendLayout();
      this.mainPanel.SuspendLayout();
      this.panel2.SuspendLayout();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.listFilesBox.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.panel3.SuspendLayout();
      this.SuspendLayout();
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(763, 24);
      this.menuStrip1.TabIndex = 0;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
      this.fileToolStripMenuItem.Text = "File";
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
      this.exitToolStripMenuItem.Text = "Exit";
      this.exitToolStripMenuItem.Click += new System.EventHandler(this.MenuExitEvent);
      // 
      // helpToolStripMenuItem
      // 
      this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
      this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
      this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
      this.helpToolStripMenuItem.Text = "Help";
      // 
      // aboutToolStripMenuItem
      // 
      this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
      this.aboutToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
      this.aboutToolStripMenuItem.Text = "About ...";
      this.aboutToolStripMenuItem.Click += new System.EventHandler(this.MenuAboutEvent);
      // 
      // dialogTarget
      // 
      this.dialogTarget.Description = "Select the directory to place the generated documentation";
      // 
      // dialogFile
      // 
      this.dialogFile.DefaultExt = "cs";
      this.dialogFile.Filter = "C# files|*.cs";
      this.dialogFile.Multiselect = true;
      this.dialogFile.Title = "Select C# file with XmlObjects documentation";
      // 
      // dialogReference
      // 
      this.dialogReference.DefaultExt = "dll";
      this.dialogReference.Filter = "PE file|*.dll;*.exe;*.mod;*.mdl";
      // 
      // gbox2
      // 
      this.gbox2.Controls.Add(this.namespaceCheckBox);
      this.gbox2.Controls.Add(this.textType);
      this.gbox2.Controls.Add(this.label1);
      this.gbox2.Controls.Add(this.checkPrompt);
      this.gbox2.Dock = System.Windows.Forms.DockStyle.Top;
      this.gbox2.Location = new System.Drawing.Point(0, 0);
      this.gbox2.Name = "gbox2";
      this.gbox2.Size = new System.Drawing.Size(763, 49);
      this.gbox2.TabIndex = 0;
      this.gbox2.TabStop = false;
      this.gbox2.Text = "Schema info";
      // 
      // namespaceCheckBox
      // 
      this.namespaceCheckBox.AutoSize = true;
      this.namespaceCheckBox.Location = new System.Drawing.Point(13, 19);
      this.namespaceCheckBox.Name = "namespaceCheckBox";
      this.namespaceCheckBox.Size = new System.Drawing.Size(164, 17);
      this.namespaceCheckBox.TabIndex = 1;
      this.namespaceCheckBox.Text = "Force namespace generation";
      this.namespaceCheckBox.UseVisualStyleBackColor = true;
      // 
      // textType
      // 
      this.textType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.textType.Enabled = false;
      this.textType.Location = new System.Drawing.Point(630, 17);
      this.textType.Name = "textType";
      this.textType.Size = new System.Drawing.Size(121, 20);
      this.textType.TabIndex = 2;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(437, 20);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(187, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Root type (can be partially  specified) :";
      // 
      // checkPrompt
      // 
      this.checkPrompt.AutoSize = true;
      this.checkPrompt.Checked = true;
      this.checkPrompt.CheckState = System.Windows.Forms.CheckState.Checked;
      this.checkPrompt.Location = new System.Drawing.Point(239, 19);
      this.checkPrompt.Name = "checkPrompt";
      this.checkPrompt.Size = new System.Drawing.Size(177, 17);
      this.checkPrompt.TabIndex = 0;
      this.checkPrompt.Text = "Prompt dialog to select root type";
      this.checkPrompt.UseVisualStyleBackColor = true;
      this.checkPrompt.CheckedChanged += new System.EventHandler(this.PromptCheckChangedEvent);
      // 
      // mainPanel
      // 
      this.mainPanel.Controls.Add(this.panel2);
      this.mainPanel.Controls.Add(this.gbox2);
      this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.mainPanel.Location = new System.Drawing.Point(0, 24);
      this.mainPanel.Name = "mainPanel";
      this.mainPanel.Size = new System.Drawing.Size(763, 453);
      this.mainPanel.TabIndex = 3;
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.splitContainer1);
      this.panel2.Controls.Add(this.groupBox2);
      this.panel2.Controls.Add(this.groupBox1);
      this.panel2.Controls.Add(this.panel3);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(0, 49);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(763, 404);
      this.panel2.TabIndex = 1;
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 98);
      this.splitContainer1.Name = "splitContainer1";
      this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.listFilesBox);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.groupBox3);
      this.splitContainer1.Size = new System.Drawing.Size(763, 256);
      this.splitContainer1.SplitterDistance = 122;
      this.splitContainer1.TabIndex = 1;
      // 
      // listFilesBox
      // 
      this.listFilesBox.Controls.Add(this.listFiles);
      this.listFilesBox.Controls.Add(this.buttonRemoveFile);
      this.listFilesBox.Controls.Add(this.buttonAddFile);
      this.listFilesBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listFilesBox.Location = new System.Drawing.Point(0, 0);
      this.listFilesBox.Name = "listFilesBox";
      this.listFilesBox.Size = new System.Drawing.Size(763, 122);
      this.listFilesBox.TabIndex = 0;
      this.listFilesBox.TabStop = false;
      this.listFilesBox.Text = "C# files";
      // 
      // listFiles
      // 
      this.listFiles.AllowDrop = true;
      this.listFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.listFiles.FormattingEnabled = true;
      this.listFiles.IntegralHeight = false;
      this.listFiles.Location = new System.Drawing.Point(13, 20);
      this.listFiles.Name = "listFiles";
      this.listFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
      this.listFiles.Size = new System.Drawing.Size(611, 94);
      this.listFiles.Sorted = true;
      this.listFiles.TabIndex = 0;
      this.listFiles.DragDrop += new System.Windows.Forms.DragEventHandler(this.DropFileInListboxEvent);
      this.listFiles.DragEnter += new System.Windows.Forms.DragEventHandler(this.DraggedFileEnterEvent);
      this.listFiles.SelectedValueChanged += new System.EventHandler(this.ChangedFileSelectionEvent);
      // 
      // buttonRemoveFile
      // 
      this.buttonRemoveFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonRemoveFile.Enabled = false;
      this.buttonRemoveFile.Location = new System.Drawing.Point(630, 48);
      this.buttonRemoveFile.Name = "buttonRemoveFile";
      this.buttonRemoveFile.Size = new System.Drawing.Size(121, 23);
      this.buttonRemoveFile.TabIndex = 2;
      this.buttonRemoveFile.Text = "Remove";
      this.buttonRemoveFile.UseVisualStyleBackColor = true;
      this.buttonRemoveFile.MouseClick += new System.Windows.Forms.MouseEventHandler(this.RemoveFileEvent);
      // 
      // buttonAddFile
      // 
      this.buttonAddFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonAddFile.Location = new System.Drawing.Point(630, 19);
      this.buttonAddFile.Name = "buttonAddFile";
      this.buttonAddFile.Size = new System.Drawing.Size(121, 23);
      this.buttonAddFile.TabIndex = 1;
      this.buttonAddFile.Text = "Add ...";
      this.buttonAddFile.UseVisualStyleBackColor = true;
      this.buttonAddFile.MouseClick += new System.Windows.Forms.MouseEventHandler(this.AddFileEvent);
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.listReferences);
      this.groupBox3.Controls.Add(this.buttonRemoveReference);
      this.groupBox3.Controls.Add(this.buttonAddReference);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Location = new System.Drawing.Point(0, 0);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(763, 130);
      this.groupBox3.TabIndex = 0;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "References";
      // 
      // listReferences
      // 
      this.listReferences.AllowDrop = true;
      this.listReferences.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.listReferences.FormattingEnabled = true;
      this.listReferences.IntegralHeight = false;
      this.listReferences.Location = new System.Drawing.Point(13, 19);
      this.listReferences.Name = "listReferences";
      this.listReferences.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
      this.listReferences.Size = new System.Drawing.Size(611, 98);
      this.listReferences.Sorted = true;
      this.listReferences.TabIndex = 0;
      this.listReferences.DragDrop += new System.Windows.Forms.DragEventHandler(this.DropFileInListboxEvent);
      this.listReferences.DragEnter += new System.Windows.Forms.DragEventHandler(this.DraggedFileEnterEvent);
      this.listReferences.SelectedValueChanged += new System.EventHandler(this.ChangedReferenceSelectionEvent);
      // 
      // buttonRemoveReference
      // 
      this.buttonRemoveReference.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonRemoveReference.Enabled = false;
      this.buttonRemoveReference.Location = new System.Drawing.Point(630, 48);
      this.buttonRemoveReference.Name = "buttonRemoveReference";
      this.buttonRemoveReference.Size = new System.Drawing.Size(121, 23);
      this.buttonRemoveReference.TabIndex = 2;
      this.buttonRemoveReference.Text = "Remove";
      this.buttonRemoveReference.UseVisualStyleBackColor = true;
      this.buttonRemoveReference.MouseClick += new System.Windows.Forms.MouseEventHandler(this.RemoveReferenceEvent);
      // 
      // buttonAddReference
      // 
      this.buttonAddReference.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonAddReference.Location = new System.Drawing.Point(630, 19);
      this.buttonAddReference.Name = "buttonAddReference";
      this.buttonAddReference.Size = new System.Drawing.Size(121, 23);
      this.buttonAddReference.TabIndex = 1;
      this.buttonAddReference.Text = "Add ...";
      this.buttonAddReference.UseVisualStyleBackColor = true;
      this.buttonAddReference.MouseClick += new System.Windows.Forms.MouseEventHandler(this.AddReferenceEvent);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.buttonCscCompiler);
      this.groupBox2.Controls.Add(this.cscCompilerText);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox2.Location = new System.Drawing.Point(0, 57);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(763, 41);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "C# compiler";
      // 
      // buttonCscCompiler
      // 
      this.buttonCscCompiler.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonCscCompiler.Location = new System.Drawing.Point(629, 14);
      this.buttonCscCompiler.Name = "buttonCscCompiler";
      this.buttonCscCompiler.Size = new System.Drawing.Size(121, 23);
      this.buttonCscCompiler.TabIndex = 3;
      this.buttonCscCompiler.Text = ". . .";
      this.buttonCscCompiler.UseVisualStyleBackColor = true;
      this.buttonCscCompiler.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectCompilerEvent);
      // 
      // cscCompilerText
      // 
      this.cscCompilerText.AllowDrop = true;
      this.cscCompilerText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.cscCompilerText.Location = new System.Drawing.Point(12, 15);
      this.cscCompilerText.Name = "cscCompilerText";
      this.cscCompilerText.Size = new System.Drawing.Size(611, 20);
      this.cscCompilerText.TabIndex = 2;
      this.cscCompilerText.TextChanged += new System.EventHandler(this.CheckGenerateButtonEvent);
      this.cscCompilerText.DragDrop += new System.Windows.Forms.DragEventHandler(this.DropFileInTextboxEvent);
      this.cscCompilerText.DragEnter += new System.Windows.Forms.DragEventHandler(this.DraggedFileEnterEvent);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.buttonTarget);
      this.groupBox1.Controls.Add(this.editTarget);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(763, 57);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Target directory";
      // 
      // buttonTarget
      // 
      this.buttonTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonTarget.Location = new System.Drawing.Point(630, 18);
      this.buttonTarget.Name = "buttonTarget";
      this.buttonTarget.Size = new System.Drawing.Size(121, 23);
      this.buttonTarget.TabIndex = 1;
      this.buttonTarget.Text = ". . .";
      this.buttonTarget.UseVisualStyleBackColor = true;
      this.buttonTarget.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SelectTargetEvent);
      // 
      // editTarget
      // 
      this.editTarget.AllowDrop = true;
      this.editTarget.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.editTarget.Location = new System.Drawing.Point(13, 19);
      this.editTarget.Name = "editTarget";
      this.editTarget.Size = new System.Drawing.Size(611, 20);
      this.editTarget.TabIndex = 0;
      this.editTarget.TextChanged += new System.EventHandler(this.CheckGenerateButtonEvent);
      this.editTarget.DragDrop += new System.Windows.Forms.DragEventHandler(this.DropFileInTextboxEvent);
      this.editTarget.DragEnter += new System.Windows.Forms.DragEventHandler(this.DraggedDirectoryEnterEvent);
      // 
      // panel3
      // 
      this.panel3.Controls.Add(this.buttonGenerate);
      this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel3.Location = new System.Drawing.Point(0, 354);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(763, 50);
      this.panel3.TabIndex = 2;
      // 
      // buttonGenerate
      // 
      this.buttonGenerate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.buttonGenerate.Enabled = false;
      this.buttonGenerate.Location = new System.Drawing.Point(440, 15);
      this.buttonGenerate.Name = "buttonGenerate";
      this.buttonGenerate.Size = new System.Drawing.Size(311, 23);
      this.buttonGenerate.TabIndex = 0;
      this.buttonGenerate.Text = "Generate the documentation";
      this.buttonGenerate.UseVisualStyleBackColor = true;
      this.buttonGenerate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.GeneratedDocumentationEvent);
      // 
      // contextMenuStrip1
      // 
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
      // 
      // dialogCompiler
      // 
      this.dialogCompiler.DefaultExt = "exe";
      this.dialogCompiler.FileName = "csc.exe";
      this.dialogCompiler.Filter = "Executables | *.exe";
      this.dialogCompiler.InitialDirectory = "C:\\WINDOWS\\Microsoft.NET\\Framework";
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(763, 477);
      this.Controls.Add(this.mainPanel);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "MainForm";
      this.Text = "XmlObjects Documentation Generator";
      this.Load += new System.EventHandler(this.FormLoadedEvent);
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QuittingAppEvent);
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.gbox2.ResumeLayout(false);
      this.gbox2.PerformLayout();
      this.mainPanel.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.ResumeLayout(false);
      this.listFilesBox.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.panel3.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    private System.Windows.Forms.FolderBrowserDialog dialogTarget;
    private System.Windows.Forms.OpenFileDialog dialogFile;
    private System.Windows.Forms.OpenFileDialog dialogReference;
    private System.Windows.Forms.GroupBox gbox2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.CheckBox checkPrompt;
    private System.Windows.Forms.TextBox textType;
    private System.Windows.Forms.Panel mainPanel;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.GroupBox listFilesBox;
    private System.Windows.Forms.ListBox listFiles;
    private System.Windows.Forms.Button buttonRemoveFile;
    private System.Windows.Forms.Button buttonAddFile;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.ListBox listReferences;
    private System.Windows.Forms.Button buttonRemoveReference;
    private System.Windows.Forms.Button buttonAddReference;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Button buttonTarget;
    private System.Windows.Forms.TextBox editTarget;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Button buttonGenerate;
    private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    private System.Windows.Forms.CheckBox namespaceCheckBox;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Button buttonCscCompiler;
    private System.Windows.Forms.TextBox cscCompilerText;
    private System.Windows.Forms.OpenFileDialog dialogCompiler;
  }
}

