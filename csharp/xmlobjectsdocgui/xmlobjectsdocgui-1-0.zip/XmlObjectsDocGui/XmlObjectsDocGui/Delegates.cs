using System;
using System.Collections.Generic;
using System.Text;

namespace XmlObjectsDocGui
{
  public delegate void InfoDelegate(string s);
  public delegate void ResultDelegate(int errorCode);
}
