using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Default parent and child fields
  /// </summary>
  [TestFixture]
  public class Test72DefaultHierarchy : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder loc='1'>
                    <file loc='2'></file>
                    <file loc='3'></file>
                </folder>
                <file loc='4'></file>
            </wsm>
            ";

    public class Storage
    {
      public object parent;
      public int loc;
    };

    public class Wsm
    {
      public Storage[] childs;
      public Folder[] folder;
      public File[] file;
    }

    public class Folder : Storage
    {
      public Storage[] childs;
      public File[] file;
    }

    public class File : Storage { }

    [SetUp]
    public void setup()
    {
      parameters = new XmlTypeAttribute();
      parameters.ParentField = "parent";
      parameters.ChildsField = "childs";
      wsm = (Wsm)LoadXml(typeof(Wsm), xml, parameters);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm, parameters));
    }
    private Wsm wsm;
    private XmlTypeAttribute parameters;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 1);
      Assert.AreEqual(wsm.file.Length, 1);
      Assert.AreEqual(wsm.childs.Length, 2);
      Assert.AreEqual(wsm.folder[0].file.Length, 2);
      Assert.AreEqual(wsm.folder[0].childs.Length, 2);
      Assert.AreEqual(wsm.childs[0], wsm.folder[0]);
      Assert.AreEqual(wsm.childs[1], wsm.file[0]);
      Assert.AreEqual(wsm.folder[0].parent, wsm);
      Assert.AreEqual(wsm.file[0].parent, wsm);
      Assert.AreEqual(wsm.folder[0].file[0].parent, wsm.folder[0]);
      Assert.AreEqual(wsm.folder[0].file[1].parent, wsm.folder[0]);
    }
  }
}
