using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the WriteStarted/WriteCompleted
  /// </summary>
  [TestFixture]
  public class TestA0WriteMethods : CommonTest
  {

    [XmlType(XmlWritePrepareMethod="XmlWriteStarted", XmlWriteCompletedMethod="XmlWriteCompleted")]
    public class Wsm 
    {
      public void XmlWriteStarted()
      {
        startedCalled=true;
      }
      public void XmlWriteCompleted()
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled, startedCalled;
    }

    [Test]
    public void test()
    {
      Wsm wsm = new Wsm();
      Save(wsm);
      Assert.IsTrue(wsm.completedCalled);
      Assert.IsTrue(wsm.startedCalled);
    }
  }
}
