using System;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verifies that the class cannot define an attribute with the given
  ///   type attribute name, even if the case differs
  /// </summary>
  [TestFixture]
  public class TestTA01AttributeName2 : CommonTest
  {

    static string xml = @"
            <wsm></wsm>
            ";

    [XmlType(TypeAttribute="typeName")]
    public class Wsm
    {
      public string typename;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.FieldWithTypeAttributeName, typeof(Wsm), xml);
    }
  }
}
