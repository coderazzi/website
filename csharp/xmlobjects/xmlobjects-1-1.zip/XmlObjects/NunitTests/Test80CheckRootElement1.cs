using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// The root name is checked
  /// </summary>
  [TestFixture]
  public class Test80CheckRootElement1 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Wsm { }

    [Test]
    public void test()
    {
      LoadXml(typeof(Wsm), xml, "wsm");
    }
  }
}
