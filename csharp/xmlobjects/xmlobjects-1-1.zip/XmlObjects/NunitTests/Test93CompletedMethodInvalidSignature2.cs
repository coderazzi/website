using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, but setting it to an incorrect signature
  /// </summary>
  [TestFixture]
  public class Test93CompletedMethodInvalidSignature2 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod="XmlParsed")]
    public class Wsm 
    {
      public static void XmlParsed(){}
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.MethodDoesNotExist, typeof(Wsm), xml);
    }
  }
}
