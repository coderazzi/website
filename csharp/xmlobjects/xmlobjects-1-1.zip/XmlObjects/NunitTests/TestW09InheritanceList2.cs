using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using inheritance on a List field
  /// </summary>
  [TestFixture]
  public class TestW09InheritanceList2 : CommonTest
  {

    public class Wsm
    {
      public List<object> file;
    };
    public class File
    {
      public string name;
    }
    public class Folder : File
    {
      public List<object> file;
    }
    [Test]
    public void test()
    {
      XmlTypeAttribute pars = new XmlTypeAttribute();
      pars.TypeAttribute = "type";
      Wsm wsm = new Wsm();
      wsm.file = new List<object>();
      Folder fa = new Folder(); fa.name = "folderA"; fa.file = new List<object>();
      Folder fb = new Folder(); fb.name = "folderB"; fb.file = new List<object>();
      File a = new File(); a.name = "fileA";
      File b = new File(); b.name = "fileB";
      wsm.file.Add(fa);
      wsm.file.Add(a);
      wsm.file.Add("SpecialRootValue");
      fa.file.Add(b);
      fa.file.Add(fb);
      check((Wsm)SaveAndLoad(wsm, pars));
    }
    private void check(Wsm wsm)
    {
    }
  }
}
