using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// All elements are initialized to empty arrays if not read from xml
  /// </summary>
  [TestFixture]
  public class Test06InitializeElements : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Wsm
    {
      public Folder[] folder;
      public Folder folder2;
    };

    public class Folder
    {
      public string location;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 0);
      Assert.AreEqual(wsm.folder2, null);
    }
  }
}
