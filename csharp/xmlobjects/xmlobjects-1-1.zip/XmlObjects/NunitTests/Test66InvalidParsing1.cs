using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Checking errors while invoking the parse method
  /// </summary>
  [TestFixture]
  public class Test66InvalidParsing1 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
        ";

    public class Wsm
    {
      private int value;
      public static Wsm Parse(string s) 
      { 
        Wsm wsm = new Wsm();
        wsm.value = int.Parse(s);
        return wsm;
      }
    };

    public class Folder { };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.InvalidParsingString, typeof(Wsm), xml);
    }
  }
}
