using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, but setting it to an incorrect name
  /// </summary>
  [TestFixture]
  public class Test91CompletedMethodInvalid : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod="xmlParsed")]
    public class Wsm 
    {
      public void XmlParsed()
      {
        completedCalled=true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.MethodDoesNotExist, typeof(Wsm), xml);
    }
  }
}
