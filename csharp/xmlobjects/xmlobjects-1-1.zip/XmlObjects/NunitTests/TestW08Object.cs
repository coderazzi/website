using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Writing a simple object
  /// </summary>
  [TestFixture]
  public class TestW08Object : CommonTest
  {

    public class Wsm
    {
      public object content;
    };
    public class File
    {
      public string name;
    }
    [Test]
    public void test()
    {
      XmlTypeAttribute pars = new XmlTypeAttribute();
      pars.TypeAttribute = "type";
      Wsm wsm = new Wsm();
      wsm.content = "content";
      check((Wsm)SaveAndLoad(wsm, pars));
    }
    private void check(Wsm wsm)
    {
    }
  }
}
