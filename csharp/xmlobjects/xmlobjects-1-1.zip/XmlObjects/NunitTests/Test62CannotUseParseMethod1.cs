using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// The parse method is not invoked if a class already defines attributes and/or elements
  /// </summary>
  [TestFixture]
  public class Test62CannotUseParseMethod1 : CommonTest
  {

    static string xml = @"
            <wsm att='any'>InvalidParseMethod</wsm>
        ";

    public class Wsm
    {
      public string att;
      public static Wsm Parse(string s) { return new Wsm(); }
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.NoInnerText, typeof(Wsm), xml);
    }
  }
}
