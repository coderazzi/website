using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the parent field, but the field does not exist
  /// </summary>
  [TestFixture]
  public class Test34XmlTypeParentInvalid : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder></folder>
            </wsm>
            ";

    public class Wsm
    {
      public Folder folder;
    };

    [XmlType(ParentField = "parent")]
    public class Folder
    {
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.FieldDoesNotExist, typeof(Wsm), xml);
    }
  }
}
