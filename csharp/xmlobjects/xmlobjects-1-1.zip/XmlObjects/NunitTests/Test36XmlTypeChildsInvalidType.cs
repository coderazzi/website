using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the childs field, but the field is of invalid type
  /// </summary>
  [TestFixture]
  public class Test36XmlTypeChildsInvalidType : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder></folder>
            </wsm>
            ";

    [XmlType(ChildsField = "childs")]
    public class Wsm
    {
      public Folder folder;
      public bool childs;
    };

    public class Folder
    {
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.InvalidFieldType, typeof(Wsm), xml);
    }
  }
}
