using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the ProvidedFieldsSupport functionality
  /// </summary>
  [TestFixture]
  public class TestC01ProvidedFields : CommonTest
  {
    static string xmlToFormat = @"
      <Wsm/>
    ";


    public class Wsm
    {
      public int times;
      public bool timesAttributeProvided;
    };

    [Test]
    public void test()
    {
      check((Wsm)LoadXml(typeof(Wsm),xmlToFormat));
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(LoadXml(typeof(Wsm), xmlToFormat)));
    }
    private void check(Wsm wsm)
    {
      Assert.IsFalse(wsm.timesAttributeProvided);
      Assert.AreEqual(wsm.times, 0);
    }
  }
}
