using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Default parent, explictly removed in one child in the hierarchy
  /// </summary>
  [TestFixture]
  public class Test74DefaultUnset2 : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder></folder>
            </wsm>
            ";


    public class Wsm
    {
      public Folder folder;
      public object parent;
      public Wsm()
      {
        parent = this; //avoid null default value
      }
    }

    [XmlType(ParentField = null)]
    public class FolderType
    {
      public object parent;
      public FolderType()
      {
        parent = this; //avoid null default value
      }
    }

    public class Folder : FolderType
    {
    }

    [SetUp]
    public void setup()
    {
      parameters = new XmlTypeAttribute();
      parameters.ParentField = "parent";
      wsm = (Wsm)LoadXml(typeof(Wsm), xml, parameters);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    private Wsm wsm;
    private XmlTypeAttribute parameters;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.parent, null);
      Assert.AreEqual(wsm.folder.parent, wsm.folder);
    }
  }
}
