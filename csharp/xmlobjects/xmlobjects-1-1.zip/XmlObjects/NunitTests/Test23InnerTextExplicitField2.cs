using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text. 
  /// There can be a different field with the same name, different case
  /// </summary>
  [TestFixture]
  public class Test23InnerTextExplicitField2 : CommonTest
  {

    static string xml = @"
            <wsm text='whatever'>Parsed content</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public string Text;
      public string text; //inner text field
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.Text, "whatever");
      Assert.AreEqual(wsm.text, "Parsed content");
    }
  }
}
