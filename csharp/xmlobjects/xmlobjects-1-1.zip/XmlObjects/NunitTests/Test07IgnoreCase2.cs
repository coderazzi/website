using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlObjects is case unsensitive, already checked on previous tests. 
  /// This shows that two fields cannot have the same assigned name (ignoring case)
  /// </summary>
  [TestFixture]
  public class Test07IgnoreCase2 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Wsm
    {
      public Folder folder;
      [XmlField("FOLDER")]
      public Folder other;
    };

    public class Folder
    {
      public string location;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.MultipleFieldsWithSameName, typeof(Wsm), xml);
    }
  }
}
