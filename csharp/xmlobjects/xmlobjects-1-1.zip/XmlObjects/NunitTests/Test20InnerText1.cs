using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text
  /// </summary>
  [TestFixture]
  public class Test20InnerText1 : CommonTest
  {

    static string xml = @"
            <wsm>
                Parsed content
            </wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public string text;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.text.Trim(), "Parsed content");
    }
  }
}
