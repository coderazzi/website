using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using a type in the xml definition that is invalid
  /// </summary>
  [TestFixture]
  public class TestB03Invalid : CommonTest
  {
    static string xmlToFormat = @"
      <Wsm>
        <file name='aname' type='{0}'/>
      </Wsm>
    ";


    public class Wsm
    {
      public File file;
    };

    public class File { }

    public class NewFile : File
    {
      public string name;
    }

    [Test]
    public void test()
    {
      XmlTypeAttribute pars = new XmlTypeAttribute();
      pars.TypeAttribute = "type";
      string xml = String.Format(xmlToFormat, typeof(NewFile).FullName+"_");
      Console.WriteLine("Xml:{0}", xml);
      CheckFailedLoad(XmlObjectsError.InvalidTypeDefinition, typeof(Wsm), null, xml, pars);
    }
  }
}
