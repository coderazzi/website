using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Cannot set inner text if no parsing method or inner text property is defined
  /// </summary>
  [TestFixture]
  public class Test64MissingInnerText : CommonTest
  {

    static string xml = @"
            <wsm>InvalidParseMethod</wsm>
        ";

    public class Wsm
    {
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.NoInnerText, typeof(Wsm), xml);
    }
  }
}
