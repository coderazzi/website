using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verify that the childs field can be set multiple times in the hierarchy
  /// </summary>
  [TestFixture]
  public class Test38XmlTypeInherited6 : CommonTest
  {

    static string xml = @"
            <wsm>
              <wsm></wsm>
            </wsm>
            ";

    [XmlType(ChildsField = "childs")]
    public class Basic
    {
      public Basic[] childs;
    }
    [XmlType(ChildsField = "subs")]
    public class Wsm : Basic 
    {
      public Wsm[] subs;
      public Wsm[] wsm;
    }


    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.childs.Length, 1);
      Assert.AreEqual(wsm.subs.Length, 1);
      Assert.AreEqual(wsm.wsm.Length, 1);
      Assert.AreEqual(wsm.childs[0], wsm.wsm[0]);
      Assert.AreEqual(wsm.childs[0], wsm.subs[0]);
      Assert.AreEqual(wsm.childs[0].childs.Length, 0);
    }
  }
}
