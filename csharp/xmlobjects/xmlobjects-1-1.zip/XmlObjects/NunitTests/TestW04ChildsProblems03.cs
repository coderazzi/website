using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Test31XmlTypeChilds already ensures that the elements are saved in the proper order.
  /// This test verifies what happen if the childs field includes more elements than the
  ///    elements found in the type
  /// </summary>
  [TestFixture]
  public class TestW04ChildsProblems03 : CommonTest
  {

    [XmlType(ChildsField="childs")]
    public class Wsm
    {
      public Folder[] childs;
      public Folder folder;
    }

    public class Folder{}

    [Test]
    public void testWrite()
    {
      Wsm wsm = new Wsm();
      wsm.folder = new Folder();
      wsm.childs = new Folder[2];
      wsm.childs[0] = wsm.folder;
      wsm.childs[1] = new Folder();
      CheckFailedSaveAndLoad(XmlObjectsError.UnmatchingChildsField, wsm);
    }
  }
}
