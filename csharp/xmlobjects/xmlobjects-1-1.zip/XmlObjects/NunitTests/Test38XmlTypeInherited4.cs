using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verify that the XmlType attribute can be set on multiple classes in
  ///   the hierarchy
  /// </summary>
  [TestFixture]
  public class Test38XmlTypeInherited4 : CommonTest
  {

    static string xml = @"
            <wsm>text</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Basic
    {
      public string text;
    }
    [XmlType(InnerTextField = "innerText")]
    public class Wsm : Basic 
    {
      public string innerText;
    }


    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.text, "text");
      Assert.AreEqual(wsm.innerText, "text");
    }
  }
}
