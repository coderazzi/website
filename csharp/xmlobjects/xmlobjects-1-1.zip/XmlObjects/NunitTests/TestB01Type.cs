using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using a type in the xml definition without the assembly
  /// </summary>
  [TestFixture]
  public class TestB01Type : CommonTest
  {
    static string xmlToFormat = @"
      <Wsm>
        <file name='aname' type='{0}'/>
      </Wsm>
    ";


    public class Wsm
    {
      public File file;
    };

    public class File{}

    public class NewFile : File
    {
      public string name;
    }

    [SetUp]
    public void setup()
    {
      pars = new XmlTypeAttribute();
      pars.TypeAttribute = "type";
      xml = String.Format(xmlToFormat, typeof(NewFile).FullName);
      Console.WriteLine("Xml:{0}", xml);
    }
    [Test]
    public void test()
    {
      check((Wsm)LoadXml(typeof(Wsm),xml, pars));
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(LoadXml(typeof(Wsm), xml, pars), pars));
    }
    XmlTypeAttribute pars;
    string xml;
    private void check(Wsm wsm)
    {
      Assert.IsTrue(wsm.file is NewFile);
      Assert.AreEqual(((NewFile)wsm.file).name, "aname");
    }
  }
}
