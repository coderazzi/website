using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, playing with a NEW method
  /// </summary>
  [TestFixture]
  public class Test97CompletedMethodOverride5 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Base
    {
      public virtual void XmlParsed()
      {
        completedCalledInBase = true;
      }
      [XmlNoField]
      public bool completedCalledInBase;
    }
    [XmlType(XmlReadCompletedMethod = "XmlParsed")]
    public class Wsm : Base
    {
      public new void XmlParsed()
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.IsFalse(wsm.completedCalledInBase);
      Assert.IsTrue(wsm.completedCalled);
    }
  }
}
