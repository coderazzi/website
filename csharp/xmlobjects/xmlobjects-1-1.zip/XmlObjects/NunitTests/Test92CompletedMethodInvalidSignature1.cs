using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, but setting it to an incorrect signature
  /// </summary>
  [TestFixture]
  public class Test92CompletedMethodInvalidSignature1 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod="XmlParsed")]
    public class Wsm 
    {
      public void XmlParsed(bool called)
      {
        completedCalled = called;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.MethodDoesNotExist, typeof(Wsm), xml);
    }
  }
}
