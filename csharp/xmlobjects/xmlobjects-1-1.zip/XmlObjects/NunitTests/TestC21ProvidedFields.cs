using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the ProvidedFieldsSupport functionality, with elements instead of attributes
  /// A provided support variable is not associated to arrays
  /// </summary>
  [TestFixture]
  public class TestC21ProvidedFields : CommonTest
  {
    static string xmlToFormat = @"
      <wsm>
        <times>0</times>
        <times>1</times>
      </wsm>
    ";


    public class Wsm
    {
      [XmlField(AsElement=true)]
      public int[] times;
      public bool timesElementProvided;
    };

    [Test]
    public void test()
    {
      check((Wsm)LoadXml(typeof(Wsm), xmlToFormat));
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(LoadXml(typeof(Wsm), xmlToFormat)));
    }
    private void check(Wsm wsm)
    {
      Assert.IsFalse(wsm.timesElementProvided);
      Assert.AreEqual(wsm.times.Length, 2);
    }
  }
}
