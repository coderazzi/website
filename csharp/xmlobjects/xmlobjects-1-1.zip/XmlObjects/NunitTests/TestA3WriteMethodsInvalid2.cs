using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the WriteStarted/WriteCompleted
  /// </summary>
  [TestFixture]
  public class TestA2WriteMethodsInvalid1 : CommonTest
  {

    [XmlType(XmlWritePrepareMethod="XmlWriteStarted", XmlWriteCompletedMethod="XmlWriteCompleted")]
    public class Wsm 
    {
      public void XmlWriteStarted()
      {
        startedCalled=true;
      }
      [XmlNoField]
      public bool startedCalled;
    }

    [Test]
    public void test()
    {
      CheckFailedSave(XmlObjectsError.MethodDoesNotExist, new Wsm());
    }
  }
}
