using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// The parse method is not invoked if a class already defines attributes and/or elements
  /// </summary>
  [TestFixture]
  public class Test63CannotUseParseMethod2 : CommonTest
  {

    static string xml = @"
            <wsm>
                InvalidParseMethod
                <Folder></Folder>
            </wsm>
        ";

    public class Wsm
    {
      public Folder folder;
      public static Wsm Parse(string s) { return new Wsm(); }
    };

    public class Folder { };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.NoInnerText, typeof(Wsm), xml);
    }
  }
}
