using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic elements are left untouched if not specified in the xml file
  /// </summary>
  [TestFixture]
  public class Test50InitializeBasicElements : CommonTest
  {

    static string xml = @"
            <wsm>
                <subwsm att1='false'>
                    <att3>false</att3>
                </subwsm>
                <subwsm>
                </subwsm>
            </wsm>
            ";

    public class Wsm
    {
      public SubWsm[] subwsm;
    };

    public class SubWsm
    {
      public bool att1;
      [XmlField(AsElement = true)]
      public bool att3;
      public SubWsm()
      {
        att1 = att3 = true;
      }
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.subwsm.Length, 2);
      Assert.AreEqual(wsm.subwsm[0].att1, false);
      Assert.AreEqual(wsm.subwsm[0].att3, false);
      Assert.AreEqual(wsm.subwsm[1].att1, true);
      Assert.AreEqual(wsm.subwsm[1].att3, true);
    }
  }
}
