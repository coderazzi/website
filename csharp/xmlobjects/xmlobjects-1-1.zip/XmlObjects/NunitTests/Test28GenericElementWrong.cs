using System.Collections.Generic;
using NUnit.Framework;
using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Setting an invalid wrong generic element
  /// </summary>
  [TestFixture]
  public class Test28GenericElementWrong : CommonTest
  {

    [XmlType(GenericElementField="generic")]
    public class Wsm
    {
      public int generic;
      public string [] hierarchy;
    };
    [Test]
    public void test1()
    {
      string xml = @"
            <wsm>
                <hierarchy>ValueH</hierarchy>
                <what>Value</what>
            </wsm>
            ";

      //InvalidParsingString: trying to put 'Value' in a generic
      CheckFailedLoad(XmlObjectsError.InvalidParsingString,typeof(Wsm), xml);
    }
    [Test]
    public void test2()
    {
      string xml = @"
            <wsm>
                <hierarchy>ValueH</hierarchy>
                <what>12</what>
                <what>34</what>
            </wsm>
            ";

      //InvalidParsingString: trying to put [12,34] in a simple field
      CheckFailedLoad(XmlObjectsError.ArrayOnSimpleField, typeof(Wsm), xml);
    }
  }
}
