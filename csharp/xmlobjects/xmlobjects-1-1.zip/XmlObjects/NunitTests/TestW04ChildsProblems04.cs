using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// It is also an error to include multiple times the same child
  /// </summary>
  [TestFixture]
  public class TestW04ChildsProblems04 : CommonTest
  {

    [XmlType(ChildsField="childs")]
    public class Wsm
    {
      public Folder[] childs;
      public Folder folder;
    }

    public class Folder{}

    [Test]
    public void testWrite()
    {
      Wsm wsm = new Wsm();
      wsm.folder = new Folder();
      wsm.childs = new Folder[2];
      wsm.childs[0] = wsm.folder;
      wsm.childs[1] = wsm.folder;
      CheckFailedSaveAndLoad(XmlObjectsError.UnmatchingChildsField, wsm);
    }
  }
}
