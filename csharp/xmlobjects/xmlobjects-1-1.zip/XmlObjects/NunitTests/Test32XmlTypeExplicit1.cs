using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, all fields must be explictly set
  /// </summary>
  [TestFixture]
  public class Test32XmlTypeExplicit1 : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder>
                </folder>
            </wsm>
            ";

    [XmlType(ExplicitFields = true)]
    public class Wsm
    {
      public string[] locations;
      [XmlField]
      public Folder[] folder;
    };

    public class Folder { }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 1);
      Assert.AreEqual(wsm.locations, null);
    }
  }
}
