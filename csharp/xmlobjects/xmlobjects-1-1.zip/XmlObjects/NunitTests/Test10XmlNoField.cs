using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Specifying XmlNoField
  /// </summary>
  [TestFixture]
  public class Test10XmlNoField : CommonTest
  {

    static string xml = @"
            <wsm att1='hello' att2='true'>
                <hierarchy>Value</hierarchy>
                <hierarchy>19:12 18/12/2006</hierarchy>
            </wsm>
            ";

    public class Wsm
    {
      public string[] hierarchy;

      public string att1;

      [XmlNoField]
      public bool att2;
    };

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.AttributeDoesNotExist, typeof(Wsm), xml);
    }
  }
}
