using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the WriteStarted/WriteCompleted on a generic way
  /// </summary>
  [TestFixture]
  public class TestA1WriteMethodsGeneric : CommonTest
  {

    public class Wsm 
    {
      public void XmlWriteStarted()
      {
        startedCalled=true;
      }
      public void XmlWriteCompleted()
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled, startedCalled;
    }

    [Test]
    public void test()
    {
      XmlTypeAttribute att = new XmlTypeAttribute();
      att.XmlWritePrepareMethod = "XmlWriteStarted";
      att.XmlWriteCompletedMethod = "XmlWriteCompleted";
      Wsm wsm = new Wsm();
      Save(wsm, att);
      Assert.IsTrue(wsm.completedCalled);
      Assert.IsTrue(wsm.startedCalled);
    }
  }
}
