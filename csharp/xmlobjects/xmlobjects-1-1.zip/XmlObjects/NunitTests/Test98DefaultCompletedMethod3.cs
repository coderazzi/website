using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod by default, plus additional explicit definitions
  /// </summary>
  [TestFixture]
  public class Test98DefaultCompletedMethod3 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod = "XmlParsedBase")]
    public class BaseA
    {
      public void XmlParsedBase()
      {
        completedCalledInBaseA = true;
      }
      [XmlNoField]
      public bool completedCalledInBaseA;
    }
    public class BaseB : BaseA
    {
      public void XmlParsedDefault()
      {
        completedCalledInBaseB = true;
      }
      [XmlNoField]
      public bool completedCalledInBaseB;
    }
    [XmlType(XmlReadCompletedMethod = null)]
    public class Wsm : BaseB
    {
      public new void XmlParsedDefault()
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [SetUp]
    public void setup()
    {
      parameters = new XmlTypeAttribute();
      parameters.XmlReadCompletedMethod = "XmlParsedDefault";
      wsm = (Wsm)LoadXml(typeof(Wsm), xml, parameters);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm, parameters));
    }
    private Wsm wsm;
    private XmlTypeAttribute parameters;
    private void checkLoaded(Wsm wsm)
    {
      Assert.IsTrue(wsm.completedCalledInBaseA);
      Assert.IsTrue(wsm.completedCalledInBaseB);
      Assert.IsFalse(wsm.completedCalled);
    }
  }
}
