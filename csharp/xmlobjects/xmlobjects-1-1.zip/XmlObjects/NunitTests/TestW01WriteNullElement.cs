using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Saving objects with null elements
  /// </summary>
  [TestFixture]
  public class TestW01WriteNullElement : CommonTest
  {

    public class Wsm
    {
      public string attribute1;
      public string attribute2;
      public Folder[] folder;
      public Folder[] nullFolder;
      public File file;
    }

    public class Folder {}
    public class File {}

    [SetUp]
    public void setup()
    {
      //attribute1 (attribute) set to null,  and attribute2 (attribute) set to empty string
      //folder (element) will contain null elements
      //nullFolder (element) will be null
      //file (element) will be null
      wsm = new Wsm();
      wsm.folder = new Folder[2];
      wsm.folder[1] = new Folder();
      wsm.attribute2 = "";
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 1);
      //Assert.AreNotSame(wsm.folder[0], null);
      Assert.AreEqual(wsm.nullFolder.Length, 0);
      Assert.AreEqual(wsm.file, null);
      Assert.AreEqual(wsm.attribute1, null);
      Assert.AreEqual(wsm.attribute2, "");
    }
  }
}
