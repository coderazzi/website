using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlObjects forces explicit usage of attributes or elements. 
  /// If a field is defined as attribute, cannot come as element
  /// </summary>
  [TestFixture]
  public class Test51AttributesAndElements1 : CommonTest
  {

    static string xml = @"
            <wsm att1='false'>
            </wsm>
            ";

    public class Wsm
    {
      [XmlField(AsElement = true)]
      public bool att1;
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.AttributeDoesNotExist, typeof(Wsm), xml);
    }
  }
}
