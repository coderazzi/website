using System.Collections.Generic;
using NUnit.Framework;
using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic test, should work fine
  /// </summary>
  [TestFixture]
  public class Test75DefaultGenericElement : CommonTest
  {

    static string xml = @"
            <wsm>
                <hierarchy>ValueH</hierarchy>
                <what>Value</what>
            </wsm>
            ";

    public class Wsm
    {
      public string [] generic;
      public string [] hierarchy;
    };
    [SetUp]
    public void setup()
    {
      att = new XmlTypeAttribute();
      att.GenericElementField = "generic";
      wsm=(Wsm)LoadXml(typeof(Wsm), xml, att);
    }
    [Test]
    public void test()
    {
      check(wsm);
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(wsm, att));
    }
    private Wsm wsm;
    private XmlTypeAttribute att;
    private void check(Wsm wsm)
    {
      Assert.AreEqual(wsm.hierarchy.Length, 1);
      Assert.AreEqual(wsm.hierarchy[0], "ValueH");
      Assert.AreEqual(wsm.generic.Length, 1);
      Assert.AreEqual(wsm.generic[0], "Value");
    }
  }
}
