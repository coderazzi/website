using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// This text is based on the way XmlObjects is implemented.
  /// It is needed to verify what happens in two elements have the same hashcode/equal values
  ///   when childs are used;
  /// In this test, using two elements pointing to the same reference
  /// </summary>
  [TestFixture]
  public class TestW06EqualElementsChilds01 : CommonTest
  {

    static string xml = @"
            <wsm>
                <a>12</a>
                <b>12</b>
            </wsm>
            ";

    [XmlType(ChildsField = "childs", AttributeFields=false)]
    public class Wsm
    {
      public int a, b;
      public int[] childs;
    };

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.a, 12);
      Assert.AreEqual(wsm.b, 12);
      Assert.AreEqual(wsm.childs.Length, 2);
      Assert.AreEqual(wsm.childs[0], 12);
      Assert.AreEqual(wsm.childs[1], 12);
    }
  }
}
