using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Checking errors while invoking the parse method
  /// </summary>
  [TestFixture]
  public class Test66InvalidParsing2 : CommonTest
  {

    static string xml = @"
            <wsm att='' />
        ";

    public class Wsm
    {
      public bool att;
    }

    public class Folder { };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.InvalidParsingString, typeof(Wsm), xml);
    }
  }
}
