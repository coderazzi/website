using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the parent field associated to the hierarchy, not to itself,
  ///   is an error
  /// </summary>
  [TestFixture]
  public class Test37XmlTypeParentInherited : CommonTest
  {

    static string xml = @"
            <wsm></wsm>
            ";

    public class Basic
    {
      public object parent;
      public Basic()
      {
        parent = this; //to ensure that it is not initialized to null
      }
    }
    [XmlType(ParentField = "parent")]
    public class Wsm : Basic { }


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.FieldDoesNotExist, typeof(Wsm), xml);
    }
  }
}
