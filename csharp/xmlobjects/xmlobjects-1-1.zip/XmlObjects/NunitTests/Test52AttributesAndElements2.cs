using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlObjects forces explicit usage of attributes or elements. If a field is defined as attribute, cannot come as element
  /// </summary>
  [TestFixture]
  public class Test52AttributesAndElements2 : CommonTest
  {

    static string xml = @"
            <wsm>
                <att1>false</att1>
            </wsm>
            ";

    public class Wsm
    {
      public bool att1;
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.ElementDoesNotExist, typeof(Wsm), xml);
    }
  }
}
