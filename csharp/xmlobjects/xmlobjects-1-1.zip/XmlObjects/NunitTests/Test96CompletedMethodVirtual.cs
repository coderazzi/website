using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod
  /// </summary>
  [TestFixture]
  public class Test96CompletedMethodVirtual : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod="XmlParsed")]
    public class Wsm 
    {
      public virtual void XmlParsed()
      {
        completedCalled=true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.IsTrue(wsm.completedCalled);
    }
  }
}
