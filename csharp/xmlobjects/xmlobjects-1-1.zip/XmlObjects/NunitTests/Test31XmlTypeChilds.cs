using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the childs field
  /// </summary>
  [TestFixture]
  public class Test31XmlTypeChilds : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder loc='programs'>
                    <file loc='wsm1'></file>
                    <file loc='wsm2'></file>
                </folder>
                <file loc='wsm3'></file>
                <folder loc='next'></folder>
            </wsm>
            ";

    public class Storage
    {
      public string loc;
    };

    [XmlType(ChildsField = "childs")]
    public class Wsm
    {
      public Folder[] folder;
      public File[] file;
      public Storage[] childs;
    };

    public class Folder : Storage
    {
      public File[] file;
    }

    public class File : Storage { }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 2);
      Assert.AreEqual(wsm.folder[0].file.Length, 2);
      Assert.AreEqual(wsm.folder[0].file[0].loc, "wsm1");
      Assert.AreEqual(wsm.folder[0].file[1].loc, "wsm2");
      Assert.AreEqual(wsm.folder[1].file.Length, 0);
      Assert.AreEqual(wsm.file.Length, 1);
      Assert.AreEqual(wsm.file[0].loc, "wsm3");
      Assert.AreEqual(wsm.childs.Length, 3);
      Assert.AreEqual(wsm.childs[0], wsm.folder[0]);
      Assert.AreEqual(wsm.childs[1], wsm.file[0]);
      Assert.AreEqual(wsm.childs[2], wsm.folder[1]);
    }
  }
}
