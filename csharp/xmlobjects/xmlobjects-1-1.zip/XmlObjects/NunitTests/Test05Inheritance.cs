using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Handling inheritance
  /// </summary>
  [TestFixture]
  public class Test05Inheritance : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder loc='programs'>
                    <file loc='wsm'></file>
                </folder>
            </wsm>
            ";

    public class Storage
    {
      public string loc;
    };

    public class Wsm
    {
      public Folder folder;
    };

    public class Folder : Storage
    {
      public File file;
    }

    public class File : Storage
    {
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.loc, "programs");
      Assert.AreEqual(wsm.folder.file.loc, "wsm");
    }
  }
}
