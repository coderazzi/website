using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the ProvidedFieldsSupport functionality. 
  ///  The provided support field cannot be used as normal attribute
  /// </summary>
  [TestFixture]
  public class TestC03ProvidedFields : CommonTest
  {
    static string xmlToFormat = @"
      <Wsm times='0' timesElementProvided='true'/>
    ";


    public class Wsm
    {
      public int times;
      public bool timesAttributeProvided;
    };

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.AttributeDoesNotExist, typeof(Wsm),xmlToFormat);
    }
  }
}
