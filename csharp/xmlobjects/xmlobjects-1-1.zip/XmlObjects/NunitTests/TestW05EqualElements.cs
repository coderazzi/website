using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// This text is based on the way XmlObjects is implemented.
  /// It is needed to verify what happens in two elements have the same hashcode/equal values
  /// In this test, using two basic types with same value
  /// </summary>
  [TestFixture]
  public class TestW05EqualElements01 : CommonTest
  {

    [XmlType(AttributeFields=false)]
    public class Wsm
    {
      public int a;
      public int b;
    }


    [SetUp]
    public void setup()
    {
      //attribute1 (attribute) set to null,  and attribute2 (attribute) set to empty string
      //folder (element) will contain null elements
      //nullFolder (element) will be null
      //file (element) will be null
      wsm = new Wsm();
      wsm.a = wsm.b = 1212;
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.a, 1212);
      Assert.AreEqual(wsm.a, wsm.b);
    }
  }
}
