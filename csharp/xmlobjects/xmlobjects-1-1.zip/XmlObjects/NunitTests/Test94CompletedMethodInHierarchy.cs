using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, in several points in the hierarchy
  /// </summary>
  [TestFixture]
  public class Test94CompletedMethodInHierarchy : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod = "XmlParsedBase")]
    public class Base
    {
      public void XmlParsedBase()
      {
        completedCalledInBase = true;
      }
      [XmlNoField]
      public bool completedCalledInBase;
    }
    [XmlType(XmlReadCompletedMethod = "XmlParsed")]
    public class Wsm : Base
    {
      public void XmlParsed()
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.IsTrue(wsm.completedCalled);
      Assert.IsTrue(wsm.completedCalledInBase);
    }
  }
}
