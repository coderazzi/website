using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod, but setting it to a method above in the hierarchy
  /// </summary>
  [TestFixture]
  public class Test95CompletedMethodInvalidClass : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Base
    {
      public void XmlParsed(){}
    }

    [XmlType(XmlReadCompletedMethod = "XmlParsed")]
    public class Wsm {}

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.MethodDoesNotExist, typeof(Wsm), xml);
    }
  }
}
