using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verify that the XmlType attribute affects the hierarchy
  ///   Note that the attribute itself is not inherited
  /// </summary>
  [TestFixture]
  public class Test38XmlTypeInherited : CommonTest
  {

    static string xml = @"
            <wsm></wsm>
            ";

    [XmlType(ParentField = "parent")]
    public class Basic
    {
      public object parent;
      public Basic()
      {
        parent = this; //to ensure that it is not initialized to null
      }
    }
    public class Wsm : Basic { }


    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.parent, null);
    }
  }
}
