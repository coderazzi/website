using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text. However, the same field is used by the parsing
  /// </summary>
  [TestFixture]
  public class Test22InnerTextIncorrectField : CommonTest
  {

    static string xml = @"
            <wsm text='whatever'>
                Parsed content
            </wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public string text;
    }

    [Test]
    public void test()
    {
      //text is a special field, not used as attribute, therefore an error is expected
      CheckFailedLoad(XmlObjectsError.AttributeDoesNotExist, typeof(Wsm), xml);
    }
  }
}
