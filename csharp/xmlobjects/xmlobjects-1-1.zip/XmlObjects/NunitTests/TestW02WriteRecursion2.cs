using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Saving objects with recursive references
  /// </summary>
  [TestFixture]
  public class TestW02WriteRecursion2 : CommonTest
  {

    public class Wsm
    {
      public Folder[] folder;
    }

    public class Folder : Wsm
    {
      public string name;
    };

    private Wsm prepareWsm(bool withError)
    {
      Wsm wsm = new Wsm();
      Folder folderA = new Folder();
      Folder folderB = new Folder();
      Folder folderC = new Folder();
      folderA.name = "A";
      folderB.name = "B";
      folderC.name = "C";
      wsm.folder = new Folder[3];
      wsm.folder[1] = folderA;
      wsm.folder[2] = folderB;
      folderB.folder = new Folder[2];
      folderB.folder[0] = folderC;
      folderB.folder[1] = withError ? folderB : folderA;
      return wsm;
    }
    [Test]
    public void testWrite()
    {
      CheckFailedSaveAndLoad(XmlObjectsError.RecursiveReference, prepareWsm(true));
    }
  }
}
