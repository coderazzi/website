using System.Collections;
using System.Collections.Generic;



namespace XmlObjects
{

  /// <summary>
  /// Class created to avoid checks on null parents.
  /// When a TypeHelper performs some operations, it can delegate them into the
  ///   the TypeHelper associated to the parent of the current object, and this class
  ///   avoids checks on whether the parent exists or not.
  /// </summary>
  class TypeHelperIface
  {
    /// <summary>
    /// Returns true if the object has an associated inner text.
    /// This method is called from the constructor of the TypeHelper!
    /// </summary>
    /// <returns></returns>
    public virtual bool DefineInnerTextField { get { return false; } }


    /// <summary>
    /// Returns the type attribute name, or null if it is not specified
    /// Note that a type could define more than one type attribute if
    ///   more than one element in its hierarchy defines it. In this
    ///   case, the returned value is the attribute associated to 
    ///   the more specialized class
    /// </summary>
    public virtual string GetTypeAttributeName() { return null; }


    /// <summary>
    /// Returns the childs field
    /// Note that a type could define more than one childs text if
    ///   more than one element in its hierarchy defines it. In this
    ///   case, the returned childs field is the field associated to 
    ///   the more specialized class
    /// </summary>
    public virtual FieldHandler GetXmlChildsField() { return null; }


    /// <summary>
    /// Returns the inner text's value, if the inner text is defined.
    /// Note that a type could define more than one inner text if
    ///   more than one element in its hierarchy defines it. In this
    ///   case, the inner text is associated to the more specialized
    ///   class
    /// </summary>
    /// <param name="instance"></param>
    /// <param name="text"></param>
    public virtual string GetInnerText(object instance) { return ""; }


    /// <summary>
    /// Sets the value of the childs field on the given object,
    ///   which must match the type associated to the TypeHelper
    /// If the associated type has no childs field, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy, so if there is more than one type in the hierarchy
    ///   defining this field, the information is properly populated.
    /// </summary>
    /// <param name="instance">The instance to update</param>
    /// <param name="childs">ArrayList of objects</param>
    public virtual void SetXmlChilds(object instance, ArrayList childs) { }


    /// <summary>
    /// Sets the value of the parent field on the given object,
    ///   which must match the type associated to the TypeHelper
    /// If the associated type has no parent field, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy, so if there is more than one type in the hierarchy
    ///   defining this field, the information is properly populated.
    /// </summary>
    /// <param name="instance">The instance to update</param>
    /// <param name="parent">The Xml parent of the given instance</param>
    public virtual void SetXmlParent(object instance, object parent) { }


    /// <summary>
    /// Sets the value of the inner text on the given object,
    ///   which must match the type associated to the TypeHelper
    /// If the associated type has no inner text field, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy, so if there is more than one type in the hierarchy
    ///   defining this field, the information is properly populated.
    /// </summary>
    /// <param name="instance"></param>
    /// <param name="text"></param>
    public virtual void SetInnerText(object instance, string text) { }


    /// <summary>
    /// Invokes, if any, the method specified as XmlReadCompleted
    /// If the associated type has no completed method, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy.
    /// </summary>
    /// <param name="instance"></param>
    public virtual void BuildCompleted(object instance) { }


    /// <summary>
    /// Invokes, if any, the method specified as XmlWriteStarted
    /// If the associated type has no completed method, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy.
    /// </summary>
    /// <param name="instance"></param>
    public virtual void WriteStarted(object instance) { }



    /// <summary>
    /// Invokes, if any, the method specified as XmlWriteCompleted
    /// If the associated type has no completed method, no error is raised.
    /// In any case, it is propagated to TypeHelperInterfaces in the
    ///   hierarchy.
    /// </summary>
    /// <param name="instance"></param>
    public virtual void WriteCompleted(object instance) { }



    /// <summary>
    /// Returns the FieldHandler associated to the attribute
    ///   with the given name, specified in lowercase
    /// An exception is raised if the field does not exists
    /// </summary>
    /// <param name="lowerName">name of the field, in lower case</param>
    /// <param name="typeName">name of the current type</param>
    /// <returns></returns>
    public virtual FieldHandler GetAttributeHandlerLC(string lowerName, string typeName)
    {
      throw new XmlObjectsException(XmlObjectsError.AttributeDoesNotExist, typeName, lowerName);
    }


    /// <summary>
    /// Returns the FieldHandler associated to the attribute
    ///   with the given name, specified in lowercase
    /// An exception is raised if the field does not exists
    /// </summary>
    /// <param name="lowerName">name of the field, in lower case</param>
    /// <param name="typeName">name of the current type</param>
    /// <returns></returns>
    public virtual FieldHandler GetElementHandlerLC(string lowerName, string typeName)
    {
      throw new XmlObjectsException(XmlObjectsError.ElementDoesNotExist, typeName, lowerName);
    }


    /// <summary>
    /// Returns all the FieldHandlers associated to element variables of the current
    ///   type (and parent types)
    /// </summary>
    /// <returns></returns>
    public virtual IEnumerable<FieldHandler> ElementFieldHandlers 
    { 
      get { yield break; } 
    }


    /// <summary>
    /// Returns all the attributes associated to the given instance as XmlAttributes
    ///   attribute name, attribute value.
    /// Null attributes or empty attributes (whose string representation is empty),
    ///   are not returned
    /// </summary>
    /// <param name="instance">The object to inspect</param>
    /// <returns></returns>
    public virtual IEnumerable<XmlAttribute> GetAttributes(object instance)
    {
      yield break;
    }


    /// <summary>
    /// Returns all the elements associated to the given instance, as pairs
    ///   element name, object; the values are returned in no particular order. 
    /// Null objects are never returned
    /// </summary>
    /// <param name="instance">The object to inspect</param>
    /// <returns></returns>
    public virtual IEnumerable<XmlElement> BaseGetElements(object instance)
    {
      yield break;
    }


    /// <summary>
    /// Property to determine if the type defines any field
    /// </summary>
    /// <returns></returns>
    public virtual bool DefineFields { get { return false; } }


    /// <summary>
    /// The NullParent is the default TypeHelperIface, representing a null parent type
    /// </summary>
    static protected TypeHelperIface NullParent = new TypeHelperIface();
  }


}
