using System;

namespace XmlObjects
{
  class XmlElement
  {
    public XmlElement(string name, object value, Type declaredType)
    {
      this.name = name;
      this.value = value;
      this.declaredType = declaredType;
    }
    public string Name { get { return name; } }
    public object Value { get { return value; } }
    public Type DeclaredType { get { return declaredType; } }

    string name;
    object value;
    Type declaredType;
  }
}
