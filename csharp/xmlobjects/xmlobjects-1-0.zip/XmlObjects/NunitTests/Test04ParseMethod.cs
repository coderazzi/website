using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic test, accessing the Parse method of a class
  /// </summary>
  [TestFixture]
  public class Test04ParseMethod : CommonTest
  {

    static string xml = @"
            <wsm>
                Parsed content
            </wsm>
            ";

    public class Wsm
    {
      private string s;

      public string Text
      {
        get { return s; }
      }

      public static Wsm Parse(string s)
      {
        Wsm ret = new Wsm();
        ret.s = s;
        return ret;
      }
      public override string ToString()
      {
        return s;
      }
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.Text.Trim(), "Parsed content");
    }
  }
}
