using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the childs and parent as object
  /// </summary>
  [TestFixture]
  public class Test39XmlTypeSameExplicitFields : CommonTest
  {

    static string xml = @"
            <wsm></wsm>
            ";

    [XmlType(ChildsField="childs")]
    public class Wsm
    {
      public object childs;
    };

    [Test]
    public void test()
    {
      LoadXml(typeof(Wsm), xml);
    }
  }
}
