using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text. 
  /// There can be a different field associated to the same attribute name
  /// </summary>
  [TestFixture]
  public class Test23InnerTextExplicitField3 : CommonTest
  {

    static string xml = @"
            <wsm text='whatever'>Parsed content</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      [XmlField("text")]
      public string whatever;
      public string text; //inner text field
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.whatever, "whatever");
      Assert.AreEqual(wsm.text, "Parsed content");
    }
  }
}
