using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Defining a complex type as attribute
  /// </summary>
  [TestFixture]
  public class Test44ComplexAttributes : CommonTest
  {

    static string xml = @"
            <wsm att='12:35:00 PM'>
            </wsm>
            ";

    public class Wsm
    {
      [XmlField(AsElement = false)]
      public DateTime att;
    };
    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.att.Minute, 35);
    }
  }
}
