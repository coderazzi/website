using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlObjects does not allow setting asElement=false on arrays
  /// </summary>
  [TestFixture]
  public class Test60ArraysCannotBeAttributes : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
        ";

    public class Wsm
    {
      [XmlField(AsElement = false)]
      public bool[] att1;
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.AsElementUnsetOnArray, typeof(Wsm), xml);
    }
  }
}
