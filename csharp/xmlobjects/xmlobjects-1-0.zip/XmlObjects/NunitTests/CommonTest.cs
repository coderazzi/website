using System;
using System.IO;
using System.Text;
using System.Xml;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  abstract public class CommonTest
  {
    protected object SaveAndLoad(object obj)
    {
      return SaveAndLoad(obj, null, null);
    }
    protected object SaveAndLoad(object obj, XmlTypeAttribute parameters)
    {
      return SaveAndLoad(obj, parameters, null);
    }
    protected object SaveAndLoad(object obj, XmlTypeAttribute parameters, string rootName)
    {
      StringBuilder sb = new StringBuilder();
      XmlObjectsManager manager = getManager(parameters);
      manager.Save(obj, rootName, XmlWriter.Create(sb));
      Console.WriteLine(sb.ToString());
      return manager.Load(obj.GetType(), new StringReader(sb.ToString()), rootName);
    }

    protected void Save(object obj)
    {
      Save(obj, null, null);
    }
    protected void Save(object obj, XmlTypeAttribute parameters)
    {
      Save(obj, parameters, null);
    }
    protected void Save(object obj, XmlTypeAttribute parameters, string rootName)
    {
      StringBuilder sb = new StringBuilder();
      XmlObjectsManager manager = getManager(parameters);
      manager.Save(obj, rootName, XmlWriter.Create(sb));
      Console.WriteLine(sb.ToString());
    }

    protected object LoadXml(Type rootType, string xml)
    {
      return LoadXml(rootType, xml, null, null);
    }
    protected object LoadXml(Type rootType, string xml, string rootName)
    {
      return LoadXml(rootType, xml, rootName, null);
    }
    protected object LoadXml(Type rootType, string xml, XmlTypeAttribute parameters)
    {
      return LoadXml(rootType, xml, null, parameters);
    }
    protected object LoadXml(Type rootType, string xml, string rootName, XmlTypeAttribute parameters)
    {
      return getManager(parameters).Load(rootType, new StringReader(xml), rootName);
    }

    protected XmlObjectsManager getManager(XmlTypeAttribute parameters)
    {
      if (parameters == null) return new XmlObjectsManager();
      XmlObjectsManager ret = new XmlObjectsManager(parameters);
      return ret;
    }

    protected void CheckFailedLoad(XmlObjectsError expectedError, Type rootType, string xml)
    {
      CheckFailedLoad(expectedError, rootType, null, xml, null);
    }

    protected void CheckFailedLoad(XmlObjectsError expectedError, Type rootType, string xml, XmlTypeAttribute pars)
    {
      CheckFailedLoad(expectedError, rootType, null, xml, pars);
    }

    protected void CheckFailedLoad(XmlObjectsError expectedError, Type rootType, string rootName, string xml)
    {
      CheckFailedLoad(expectedError, rootType, rootName, xml, null);
    }
    protected void CheckFailedLoad(XmlObjectsError expectedError, Type rootType, string rootName, string xml, XmlTypeAttribute pars)
    {
      try
      {
        LoadXml(rootType, xml, rootName, pars);
        Assert.Fail("Expected exception no raised");
      }
      catch (XmlObjectsException xoe)
      {
        Console.WriteLine("Exception raised: " + xoe.ToString());
        Assert.AreEqual(expectedError, xoe.Error);
      }
    }
    protected void CheckFailedSaveAndLoad(XmlObjectsError expectedError, object obj)
    {
      CheckFailedSaveAndLoad(expectedError, obj, null);
    }
    protected void CheckFailedSaveAndLoad(XmlObjectsError expectedError, object obj, XmlTypeAttribute parameters)
    {
      try
      {
        SaveAndLoad(obj, parameters); ;
        Assert.Fail("Expected exception no raised");
      }
      catch (XmlObjectsException xoe)
      {
        Console.WriteLine("Exception raised: " + xoe.ToString());
        Assert.AreEqual(expectedError, xoe.Error);
      }
    }

    protected void CheckFailedSave(XmlObjectsError expectedError, object obj)
    {
      CheckFailedSave(expectedError, obj, null, null);
    }
    protected void CheckFailedSave(XmlObjectsError expectedError, object obj, XmlTypeAttribute parameters)
    {
      CheckFailedSave(expectedError, obj, parameters, null);
    }
    protected void CheckFailedSave(XmlObjectsError expectedError, object obj, XmlTypeAttribute parameters, string rootName)
    {
      try
      {
        Save(obj, parameters, rootName);
        Assert.Fail("Expected exception no raised");
      }
      catch (XmlObjectsException xoe)
      {
        Console.WriteLine("Exception raised: " + xoe.ToString());
        Assert.AreEqual(expectedError, xoe.Error);
      }
    }

  }
}
