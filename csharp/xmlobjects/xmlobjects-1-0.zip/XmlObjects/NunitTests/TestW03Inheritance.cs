using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Saving objects where the real type is a subclass of the specified one
  /// </summary>
  [TestFixture]
  public class TestW03Inheritance : CommonTest
  {

    public class Wsm
    {
      public Folder folder;
    }

    [XmlType(TypeAttribute = "type")]
    public class Folder
    {
      public string name;
    }

    public class DistributedFolder : Folder
    {
      public string machine;
    }

    [Test]
    public void testWrite()
    {
      Wsm wsm = new Wsm();
      DistributedFolder folder = new DistributedFolder();
      wsm.folder = folder;
      folder.machine = "machine";
      folder.name = "name";
      wsm = (Wsm)SaveAndLoad(wsm);
      Assert.AreEqual(wsm.folder.GetType(), typeof(DistributedFolder));
      Assert.AreEqual(((DistributedFolder)(wsm.folder)).machine, "machine");
    }
  }
}
