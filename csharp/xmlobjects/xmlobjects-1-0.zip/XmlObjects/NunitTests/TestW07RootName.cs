using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Saving objects with specific root name
  /// </summary>
  [TestFixture]
  public class TestW07RootName : CommonTest
  {

    public class Wsm { }


    [Test]
    public void testWrite()
    {
      SaveAndLoad(new Wsm(), null, "RootName");
    }
  }
}
