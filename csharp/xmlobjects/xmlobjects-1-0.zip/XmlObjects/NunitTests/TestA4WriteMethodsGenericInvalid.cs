using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the WriteStarted/WriteCompleted on a generic way, with some invalid method
  /// </summary>
  [TestFixture]
  public class TestA4WriteMethodsGenericInvalid : CommonTest
  {

    public class Wsm 
    {
      public void XmlWriteStarted()
      {
        startedCalled=true;
      }
      public void XmlWriteCompleted(int t)
      {
        completedCalled = true;
      }
      [XmlNoField]
      public bool completedCalled, startedCalled;
    }

    [Test]
    public void test()
    {
      XmlTypeAttribute att = new XmlTypeAttribute();
      att.XmlWritePrepareMethod = "XmlWriteStarted";
      att.XmlWriteCompletedMethod = "XmlWriteCompleted";
      Wsm wsm = new Wsm();
      Save(wsm, att);
      Assert.IsFalse(wsm.completedCalled);
      Assert.IsTrue(wsm.startedCalled);
    }
  }
}
