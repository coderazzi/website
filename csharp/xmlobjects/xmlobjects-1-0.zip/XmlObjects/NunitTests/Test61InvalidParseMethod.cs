using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// The parse method must return an instance of the definer object
  /// </summary>
  [TestFixture]
  public class Test61InvalidParseMethod : CommonTest
  {

    static string xml = @"
            <wsm>InvalidParseMethod</wsm>
        ";

    public class Wsm
    {
      public static object Parse(string s) { return s; }
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.InvalidParseMethod, typeof(Wsm), xml);
    }
  }
}
