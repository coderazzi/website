using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text in a slightly more complex way than the previous example
  /// </summary>
  [TestFixture]
  public class Test21InnerText2 : CommonTest
  {

    static string xml = @"
            <wsm att='true'>
                <folder loc='programs'></folder>
                Parsed content
            </wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public string text;
      public bool att;
      public Folder folder;
    };

    public class Folder
    {
      public string loc;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.att, true);
      Assert.AreEqual(wsm.folder.loc, "programs");
      Assert.AreEqual(wsm.text.Trim(), "Parsed content");
    }
  }
}
