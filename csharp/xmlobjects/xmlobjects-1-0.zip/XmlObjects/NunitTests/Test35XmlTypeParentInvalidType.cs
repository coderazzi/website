using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the parent field, but the field is of invalid type
  /// </summary>
  [TestFixture]
  public class Test35XmlTypeParentInvalidType : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder></folder>
            </wsm>
            ";

    public class Wsm
    {
      public Folder folder;
    };

    [XmlType(ParentField = "parent")]
    public class Folder
    {
      public string parent;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.InvalidFieldType, typeof(Wsm), xml);
    }
  }
}
