using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// The root name is checked (failing test)
  /// </summary>
  [TestFixture]
  public class Test81CheckRootElement2 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Wsm { }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.UnexpectedXmlRoot, typeof(Wsm), "wrong", xml);
    }
  }
}
