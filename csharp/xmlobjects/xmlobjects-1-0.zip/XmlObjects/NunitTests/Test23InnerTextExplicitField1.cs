using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text. It is an error to force the same field as XmlField
  /// </summary>
  [TestFixture]
  public class Test23InnerTextExplicitField1 : CommonTest
  {

    static string xml = @"
            <wsm text='whatever'>
                Parsed content
            </wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      [XmlField]
      public string text;
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.ExplicitOnSpecialField, typeof(Wsm), xml);
    }
  }
}
