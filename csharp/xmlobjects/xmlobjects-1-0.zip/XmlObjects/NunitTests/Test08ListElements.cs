using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic test, should work fine
  /// </summary>
  [TestFixture]
  public class Test08ListElements : CommonTest
  {
    string xml = @"
      <wsm>
        <hierarchy>Value</hierarchy>
        <hierarchy>Mehr</hierarchy>
      </wsm>
    ";

    public class Wsm
    {
      public List<string> hierarchy;
    };
    [Test]
    public void test()
    {
      check((Wsm)LoadXml(typeof(Wsm), xml));
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(LoadXml(typeof(Wsm), xml)));
    }
    private void check(Wsm wsm)
    {
      Assert.AreEqual(wsm.hierarchy.Count, 2);
      Assert.AreEqual(wsm.hierarchy[0],"Value");
      Assert.AreEqual(wsm.hierarchy[1], "Mehr");
    }
  }
}
