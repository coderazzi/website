using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Cannot set inner text if no parsing method or inner text property is defined
  /// </summary>
  [TestFixture]
  public class Test65NoEmptyConstructor : CommonTest
  {

    static string xml = @"
            <wsm></wsm>
        ";

    public class Wsm
    {
      public Wsm(string s) { }
    };


    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.NoEmptyConstructor, typeof(Wsm), xml);
    }
  }
}
