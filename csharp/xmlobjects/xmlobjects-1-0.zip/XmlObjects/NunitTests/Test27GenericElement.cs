using System.Collections.Generic;
using NUnit.Framework;
using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic test, should work fine
  /// </summary>
  [TestFixture]
  public class Test27GenericElement : CommonTest
  {

    static string xml = @"
            <wsm>
                <hierarchy>ValueH</hierarchy>
                <what>Value</what>
            </wsm>
            ";

    [XmlType(GenericElementField="generic")]
    public class Wsm
    {
      public string [] generic;
      public string [] hierarchy;
    };
    [SetUp]
    public void setup()
    {
      wsm=(Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      check(wsm);
    }
    [Test]
    public void testWrite()
    {
      check((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;

    private void check(Wsm wsm)
    {
      Assert.AreEqual(wsm.hierarchy.Length, 1);
      Assert.AreEqual(wsm.hierarchy[0], "ValueH");
      Assert.AreEqual(wsm.generic.Length, 1);
      Assert.AreEqual(wsm.generic[0], "Value");
    }
  }
}
