using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Checking errors while invoking the parse method
  /// </summary>
  [TestFixture]
  public class Test67InvalidParse1 : CommonTest
  {

    static string xml = @"
            <wsm att='wsm' />
        ";

    public class Wsm
    {
      [XmlField(AsElement=false)]
      public Invalid att;
    }

    public class Invalid
    {
      public static Invalid Parse(int n) { return new Invalid(); }
    }



    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.NoInnerText, typeof(Wsm), xml);
    }
  }
}
