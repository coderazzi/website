using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, all fields must be explictly set. An error is raised if it is specified a not explicit field
  /// </summary>
  [TestFixture]
  public class Test33XmlTypeExplicit2 : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder>
                </folder>
            </wsm>
            ";

    [XmlType(ExplicitFields = true)]
    public class Wsm
    {
      public Folder[] folder;
    };

    public class Folder { }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.ElementDoesNotExist, typeof(Wsm), xml);
    }
  }
}
