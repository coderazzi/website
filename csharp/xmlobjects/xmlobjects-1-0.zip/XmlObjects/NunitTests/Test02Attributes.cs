using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Basic test, where a non-array complex type is automatically mapped to nested elements
  /// </summary>
  [TestFixture]
  public class Test02Attributes : CommonTest
  {

    static string xml = @"
            <wsm att1='hello' att2='true'>
                <hierarchy>Value</hierarchy>
                <hierarchy>19:12 18/12/2006</hierarchy>
                <folder>
                    <basic>true</basic>
	                <basic>false</basic>
                </folder>
            </wsm>
            ";

    public class Wsm
    {
      public string[] hierarchy;

      public string att1;

      public bool att2;

      public Folder folder;
    };

    public class Folder
    {
      public bool[] basic;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.att1, "hello");
      Assert.AreEqual(wsm.att2, true);
      Assert.AreEqual(wsm.hierarchy.Length, 2);
      Assert.AreEqual(wsm.hierarchy[0], "Value");
      Assert.AreEqual(wsm.hierarchy[1], "19:12 18/12/2006");
      Assert.AreEqual(wsm.folder.basic[0], true);
      Assert.AreEqual(wsm.folder.basic[1], false);
    }
  }
}
