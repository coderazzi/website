using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying a special field. It is an error to use a
  ///   field above in the hierarchy
  /// </summary>
  [TestFixture]
  public class Test26ExplicitFieldInHierarchy : CommonTest
  {

    static string xml = @"
            <wsm name='kk'>Text</wsm>
            ";

    public class Hierarchy
    {
      public string name;
    };

    [XmlType(InnerTextField = "name")]
    public class Wsm : Hierarchy
    {
    }

    [Test]
    public void test()
    {
      CheckFailedLoad(XmlObjectsError.FieldDoesNotExist, typeof(Wsm), xml);
    }
  }
}
