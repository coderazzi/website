using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Specifying that all fields default to elements (no attributes). Then, one element is explictly set as attribute
  /// </summary>
  [TestFixture]
  public class Test43XmlTypeElement2 : CommonTest
  {

    static string xml = @"
            <wsm att1='hello'>
                <att2>true</att2>
            </wsm>
            ";

    [XmlType(AttributeFields = false)]
    public class Wsm
    {
      [XmlField(AsElement = false)]
      public string att1;
      public bool att2;
    };

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.att1, "hello");
      Assert.AreEqual(wsm.att2, true);
    }
  }
}
