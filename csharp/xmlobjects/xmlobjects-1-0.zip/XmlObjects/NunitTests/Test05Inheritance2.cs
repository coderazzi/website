using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Handling inheritance, second scenario (using elements, not only attributes)
  /// </summary>
  [TestFixture]
  public class Test05Inheritance2 : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder>
                    <folder>
                      <file></file>
                    </folder>
                    <file></file>
                </folder>
            </wsm>
            ";

    public class Storage
    {
      public Folder[] folder;
      public File[] file;
    };

    public class Wsm : Storage { }

    public class Folder : Storage { }

    public class File { }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.Length, 1);
      Assert.AreEqual(wsm.file.Length, 0);
      Assert.AreEqual(wsm.folder[0].folder.Length, 1);
      Assert.AreEqual(wsm.folder[0].file.Length, 1);
      Assert.AreEqual(wsm.folder[0].folder[0].folder.Length, 0);
      Assert.AreEqual(wsm.folder[0].folder[0].file.Length, 1);
    }
  }
}
