using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Test31XmlTypeChilds already ensures that the elements are saved in the proper order.
  /// This test verifies what happen if the childs field is null
  /// </summary>
  [TestFixture]
  public class TestW04ChildsProblems01 : CommonTest
  {

    [XmlType(ChildsField="childs")]
    public class Wsm
    {
      public Folder[] childs;
      public Folder folder;
    }

    public class Folder{}

    [Test]
    public void testWrite()
    {
      Wsm wsm = new Wsm();
      wsm.folder = new Folder();
      CheckFailedSaveAndLoad(XmlObjectsError.UnmatchingChildsField, wsm);
    }
  }
}
