using System;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verifies that the class can define an element with the given
  ///   type attribute name
  /// </summary>
  [TestFixture]
  public class TestTA01AttributeName3 : CommonTest
  {

    static string xml = @"
            <wsm>
              <typeName>none</typeName>
            </wsm>
            ";

    [XmlType(TypeAttribute="typeName")]
    public class Wsm
    {
      [XmlField(AsElement=true)]
      public string typeName;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.typeName, "none");
    }
  }
}
