using System;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
    public class Wsm 
    {
      public File[] file;
    }

    [XmlType(TypeAttribute = "typeName")]
    public class File
    {
      public string name;
    };

    namespace kk
    { }

  /// <summary>
  /// Verifies that the typename is indeed written, if needed
  /// </summary>
  [TestFixture]
  public class TestTA02AttributeNameWrite1 : CommonTest
  {

    public class Folder : File
    {
      public File[] file;
    }


    [Test]
    public void test()
    {
      Wsm wsm = new Wsm();
      File a = new File(); a.name = "fileA";
      File b = new File(); b.name = "fileB";
      File c = new File(); c.name = "fileC";
      File d = new File(); d.name = "fileD";
      Folder fa = new Folder(); fa.name = "folderA"; fa.file = new File[4];
      Folder fb = new Folder(); fb.name = "folderB"; fb.file = new File[1];
      Folder fc = new Folder(); fc.name = "folderC"; fc.file = new File[0];
      fa.file[0] = fb;
      fa.file[1] = b;
      fa.file[2] = fc;
      fa.file[3] = d;
      fb.file[0] = c;
      wsm.file = new File[2];
      wsm.file[0] = a;
      wsm.file[1] = fa;
      SaveAndLoad(wsm);
    }
  }
}
