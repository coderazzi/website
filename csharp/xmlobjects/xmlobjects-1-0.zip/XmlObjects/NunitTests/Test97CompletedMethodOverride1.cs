using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod
  /// </summary>
  [TestFixture]
  public class Test97CompletedMethodOverride1 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    [XmlType(XmlReadCompletedMethod = "XmlParsed")]
    public class Base
    {
      public enum WhereCalled {NotCalled, BaseCalled, Called};
      public virtual void XmlParsed()
      {
        completedCalled=WhereCalled.BaseCalled;
      }
      [XmlNoField]
      public WhereCalled completedCalled;
    }

    public class Wsm : Base
    {
      public override void XmlParsed()
      {
        completedCalled = WhereCalled.Called;
      }
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.completedCalled, Base.WhereCalled.Called);
    }
  }
}
