using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text, which does not need to be a string
  /// </summary>
  [TestFixture]
  public class Test24InnerTextNoString : CommonTest
  {

    static string xml = @"
            <wsm>true</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public bool text;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.text, true);
    }
  }
}
