using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, playing with ExplicitFields defined at generic level
  /// </summary>
  [TestFixture]
  public class Test76DefaultExplicit : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder name='don'/>
            </wsm>
            ";

    public class Wsm
    {
      [XmlField]
      public Folder folder;
    };

    [XmlType]
    public class Folder 
    {
      public string name;
    }

    [Test]
    public void test()
    {
      XmlTypeAttribute att = new XmlTypeAttribute();
      att.ExplicitFields = true;
      CheckFailedLoad(XmlObjectsError.AttributeDoesNotExist, typeof(Wsm), xml, att);
    }
  }
}
