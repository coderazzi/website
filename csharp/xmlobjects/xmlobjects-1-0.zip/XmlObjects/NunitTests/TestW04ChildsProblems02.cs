using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Test31XmlTypeChilds already ensures that the elements are saved in the proper order.
  /// This test verifies what happen if the childs field does not include all the elements
  /// </summary>
  [TestFixture]
  public class TestW04ChildsProblems02 : CommonTest
  {

    [XmlType(ChildsField="childs")]
    public class Wsm
    {
      public Folder[] childs;
      public Folder folder;
    }

    public class Folder{}

    [Test]
    public void testWrite()
    {
      Wsm wsm = new Wsm();
      wsm.folder = new Folder();
      wsm.childs = new Folder[1];
      CheckFailedSaveAndLoad(XmlObjectsError.UnmatchingChildsField, wsm);
    }
  }
}
