using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

using XmlObjects;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using inheritance on a List field
  /// </summary>
  [TestFixture]
  public class TestW09InheritanceList1 : CommonTest
  {

    public class Wsm
    {
      public List<File> file;
    };
    [XmlType(TypeAttribute="type")]
    public class File
    {
      public string name;
    }
    public class Folder : File
    {
      public List<File> file;
    }
    [Test]
    public void test()
    {
      //XmlTypeAttribute pars = new XmlTypeAttribute();
      //pars.typeAttribute = "type";
      Wsm wsm = new Wsm();
      wsm.file = new List<File>();
      Folder fa = new Folder(); fa.name = "folderA"; fa.file=new List<File>();
      Folder fb = new Folder(); fb.name = "folderB"; fb.file = new List<File>();
      File a = new File(); a.name = "fileA";
      File b = new File(); b.name = "fileB";
      wsm.file.Add(fa);
      wsm.file.Add(a);
      fa.file.Add(b);
      fa.file.Add(fb);
      check((Wsm)SaveAndLoad(wsm));
    }
    private void check(Wsm wsm)
    {
    }
  }
}
