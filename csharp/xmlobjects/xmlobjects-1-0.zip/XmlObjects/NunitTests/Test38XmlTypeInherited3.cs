using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Verify that the XmlType attribute affects the hierarchy
  ///   Now, setting up the inner text
  /// </summary>
  [TestFixture]
  public class Test38XmlTypeInherited3 : CommonTest
  {

    static string xml = @"
            <wsm>text</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Basic
    {
      public string text;
    }
    public class Wsm : Basic { }


    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.text, "text");
    }
  }
}
