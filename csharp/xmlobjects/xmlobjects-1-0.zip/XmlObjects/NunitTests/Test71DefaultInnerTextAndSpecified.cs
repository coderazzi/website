using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Default inner text, to "innerText", but letting still redefine it
  /// </summary>
  [TestFixture]
  public class Test71DefaultInnerTextAndSpecified : CommonTest
  {

    static string xml = @"
            <wsm>
                <folder>folder</folder>
                <file>File</file>
            </wsm>
            ";

    public class Wsm
    {
      public Folder folder;
      public File file;
    }

    public class Folder
    {
      public string innerText;
    }

    [XmlType(InnerTextField = "text")]
    public class File
    {
      public string text;
    }

    [SetUp]
    public void setup()
    {
      parameters = new XmlTypeAttribute();
      parameters.InnerTextField = "innerText";
      wsm = (Wsm)LoadXml(typeof(Wsm), xml, parameters);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm, parameters));
    }
    private Wsm wsm;
    private XmlTypeAttribute parameters;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.folder.innerText, "folder");
      Assert.AreEqual(wsm.file.text, "File");
    }
  }
}
