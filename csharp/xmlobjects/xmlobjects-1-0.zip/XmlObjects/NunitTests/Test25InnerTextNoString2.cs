using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// XmlType attribute, specifying the inner text, which does not need to be a string
  /// </summary>
  [TestFixture]
  public class Test25InnerTextNoString2 : CommonTest
  {

    static string xml = @"
            <wsm>12:36:12 PM</wsm>
            ";

    [XmlType(InnerTextField = "text")]
    public class Wsm
    {
      public DateTime text;
    }

    [SetUp]
    public void setup()
    {
      wsm = (Wsm)LoadXml(typeof(Wsm), xml);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm));
    }
    private Wsm wsm;
    private void checkLoaded(Wsm wsm)
    {
      Assert.AreEqual(wsm.text.Minute, 36);
    }
  }
}
