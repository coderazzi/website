using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the WriteStarted/WriteCompleted
  /// </summary>
  [TestFixture]
  public class TestA3WriteMethodsInvalid2 : CommonTest
  {

    [XmlType(XmlWritePrepareMethod="XmlWriteStarted")]
    public class Wsm 
    {
      public void XmlWriteStarted(bool def)
      {
        startedCalled=def;
      }
      [XmlNoField]
      public bool startedCalled;
    }

    [Test]
    public void test()
    {
      CheckFailedSave(XmlObjectsError.MethodDoesNotExist, new Wsm());
    }
  }
}
