using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Using the CompletedMethod by default
  /// </summary>
  [TestFixture]
  public class Test98DefaultCompletedMethod1 : CommonTest
  {

    static string xml = @"
            <wsm>
            </wsm>
            ";

    public class Wsm 
    {
      public void XmlParsed()
      {
        completedCalled=true;
      }
      [XmlNoField]
      public bool completedCalled;
    }

    [SetUp]
    public void setup()
    {
      parameters = new XmlTypeAttribute();
      parameters.XmlReadCompletedMethod = "XmlParsed";
      wsm = (Wsm)LoadXml(typeof(Wsm), xml, parameters);
    }
    [Test]
    public void test()
    {
      checkLoaded(wsm);
    }
    [Test]
    public void testWrite()
    {
      checkLoaded((Wsm)SaveAndLoad(wsm, parameters));
    }
    private Wsm wsm;
    private XmlTypeAttribute parameters;
    private void checkLoaded(Wsm wsm)
    {
      Assert.IsTrue(wsm.completedCalled);
    }
  }
}
