using System;

using XmlObjects;

using NUnit.Framework;

namespace XmlObjectsTestUnits
{
  /// <summary>
  /// Saving objects with recursive references
  /// </summary>
  [TestFixture]
  public class TestW02WriteRecursion1 : CommonTest
  {

    public class Wsm
    {
      public Wsm wsm;
      public Wsm() { wsm = this; }
    }

    [Test]
    public void testWrite()
    {
      CheckFailedSaveAndLoad(XmlObjectsError.RecursiveReference, new Wsm());
    }
  }
}
