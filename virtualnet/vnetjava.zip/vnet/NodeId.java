package vnet;

/**
  * Class to represent a node identity
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see NetNode
  */
public class NodeId implements java.io.Serializable
{
	/**
	  * @param id the string representing the node. Any letter between A and P is valid
	  * @exception VNException if the string is not valid
	  */
	public NodeId(String id) throws VNException
	{
		if (id==null || id.length()==0)
			throw new VNException();
		szId=new String(id.toUpperCase());
		Id=-1;
		for (int i=0;i<szId.length();i++)
		{
			char cId=szId.charAt(i);
			if (cId<'A' || cId>'P')
				throw new VNException(cId);
			else
				Id=(Id+1)*16 + cId-'A';
		}
	}

	/**
	  * @param element other NodeId to be compared to
	  * @return true if bot have the same identity
	  */
	public boolean equals(Object element)
	{
		boolean ret=false;
		if (element instanceof NodeId)
			ret=Id==((NodeId)element).Id;
		return ret;
	}
	
	/**
	  * @return a valid hash code
	  */
	public int hashCode()
	{
		return Id;
	}

	/**
	  * @return a printable form of the NodeId
	  */
	public String toString()
	{
		return szId;
	}
	
	/**
	  * @return the identity
	  */
	public int getId()
	{
		return Id;
	}

	private int Id;
	private String szId;
}