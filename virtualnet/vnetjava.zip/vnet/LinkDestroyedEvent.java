package vnet;

/**
  * Event Class to notify the destruction of a NetLink
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see LinkEvent
  * @see NetLink
  */
public class LinkDestroyedEvent extends LinkEvent
{
}