package vnet;

import java.util.Observable;

/**
  * Event produced by the NetLayout to notify about a new observable item.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VNetEvent
  */
public class VirtualNetEvent extends VNetEvent
{
/**
  * @param Item: the new item that can be observed in the NetLayout. It is going
  * to be a NetNode or a NetLink object.
  * @see NetNode
  * @see NetLink
  */
	public VirtualNetEvent(Observable Item)
	{
		observable=Item;
	}
/**
  *	@return The new item that can be observed
  */
	public Observable getObservable()
	{
		return observable;
	}
	private final Observable observable;
}