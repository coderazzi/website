package vnet;

/**
  *
  * Abstract parent class for all the VirtualNet events
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
abstract public class VNetEvent
{
}