package vnet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;
import java.util.Vector;


/**
  * Class to represent a node in the net. 
  * It is a node simulation of a machine (PC, Workstation), where any server
  * and clients can be running. In this simulation, a program can start (a
  * server is binded to the node, of a client uses the node), and the node can
  * fail down (the machine switch off or it just fails).
  * It implements the Observable function of the observer pattern.
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class NetNode extends Observable 
{

	/**
	  * @param id the identity of the node
	  * @param delay the delay involving any operation on this node
	  */	
	public NetNode(final NodeId id, long delay)
	{
		Id=id;
		Delay=delay;
	}
	
	/**
	  * Returns the identity of the Node
	  * @return The identity of the node
	  */	
	public NodeId getId()
	{
		return Id;
	}
	
	/**
	  * Gets the Links associated to the node (its communicationc channels)
	  * @return The links associated to the node
	  */	
	public Enumeration getLinks()
	{
		return links.elements();
	}
	
	/**
	  * Associates a new link
	  * @exception VNException if the node already includes that link
	  */	
	public void addLink(NetLink link) throws VNException
	{
		if (links.contains(link))
			throw new VNException(false,link.getId().toString(),true);
		else
			links.addElement(link);	
		nextLink=0;
	}
	
	/**
	  * Removes a link
	  * @exception VNException if the node doesn't have that link
	  */	
	public void removeLink(NetLink link) throws VNException
	{
		if (!links.contains(link))
			throw new VNException(false,link.getId().toString(),false);
		else
			links.removeElement(link);	
		nextLink=0;
	}
	
	/**
	  * Destructor of the node: clears the associated links
	  * The observers of the node will receive a NodeDestroyedEvent notification
	  * The list of observers is cleared
	  * @exception VNException if the links fail to be cleared
	  * @see NetLink#destroy
	  * @see NodeDestroyedEvent
	  */	
	public void destroy() throws VNException
	{
		//When a node is deleted, its links have to be destroyed
		while(!links.isEmpty())
				((NetLink)links.firstElement()).destroy();
				//this removeLink will eventually call to this.removeLink, removing
				//it from the Vector
		servers.clear();
		setChanged();
		notifyObservers(new NodeDestroyedEvent());
		deleteObservers();
	}

	/**
	  * Binds a server with a server name to this node
	  * The observers of the node will receive a BindEvent notification
	  * @param serverName the name of the server
	  * @param server the server being binded
	  * @param hostNode the NetNode where this server is hosted (it can be
	  * different from the node where it is going to be binded)
	  * @exception AlreadyBoundException if the serverName is already in use in this node
	  * @exception CommException if the hostNode can not be reached from this node
	  * @see BindEvent
	  */	
	public void bind(String serverName, Object server, NetNode hostNode) throws AlreadyBoundException, CommException
	{
		if (this!=hostNode)
			hostNode.checkWay(this);
		if (servers.containsKey(serverName))
			throw new AlreadyBoundException(serverName);
		else
			servers.put(serverName,new BindedServer(server,hostNode));	
		setChanged();
		notifyObservers(new BindEvent(serverName,true));
	}
	
	/**
	  * Bind a server with a server name to this node, no matter if the serverName
	  * is already used.
	  * This operation is done in two steps; first, the server is unbinded if it was
	  * already binded, and, second, the new server is binded.
	  * The observers of the node will see both notifications, the bind and the unbind.
	  * @param serverName the name of the server
	  * @param server the server being binded
	  * @param hostNode the NetNode where this server is hosted (it can be
	  * different from the node where it is going to be binded)
	  * @exception CommException if the hostNode can not be reached from this node
	  * @see BindEvent
	  * @see NetNode#unbind
	  * @see NetNode#bind
	  */	
	public void rebind(String serverName, Object server, NetNode hostNode) throws CommException
	{
		try{unbind(serverName);}catch(NotBoundException e){}
		try{bind(serverName,server,hostNode);}catch(AlreadyBoundException e){}
	}
	
	/**
	  * Unbinds the server with the server name specified, raising an exception if
	  * such a server doesn't exist in the node
	  * The observers of the node will receive a BindEvent notification
	  * @param serverName the name of the server
	  * @exception NotBoundException if the serverName is not known in this node
	  * @see BindEvent
	  */	
	public void unbind(String serverName) throws NotBoundException
	{
		if (!servers.containsKey(serverName))
			throw new NotBoundException(serverName);
		servers.remove(serverName);
		setChanged();
		notifyObservers(new BindEvent(serverName,false));
	}
	
	/**
	  * Gets the servers binded to the node
	  * @return the name of the servers binded to this node
	  */	
	public Enumeration getServers()
	{
		return servers.keys();
	}
	
	/**
	  * Starts the searching of a server in the net, returning a virtual path
	  * to that server, or null if it is not found.
	  * When the server is not found in the node, the links are used to propagate
	  * the lookup; the algorythm to select a link to propagate the link will always
	  * select the link that has been longer inactive.
	  * The observers of nodes and links that are visited during the lookup will send a
	  * LookupOnNodeEvent and LookupOnLinkEvent notification
	  * @param server the name of the server
	  * @see NetLink
	  * @see LookupOnNodeEvent
	  * @see LookupOnLinkEvent
	  */	
	public VirtualPath lookup(String server)
	{
		VirtualPath ret=lookup(server, new MessageChain());
		if (ret!=null)
			ret.nodeInitial=this;
		return ret;
	}
	
	VirtualPath lookup(String server, MessageChain way)
	{
		setChanged();
		notifyObservers(new LookupOnNodeEvent());
		doDelay();
		way.addNode(Id);
		VirtualPath ret=null;
		Object Server=servers.get(server);
		if (Server!=null)
			ret=new VirtualPath(this,(BindedServer) Server);
		if (ret==null)
		{
			int nLinks=links.size();
			if (nLinks>0)
			{
				CycleInt cycle=new CycleInt(nextLink,nLinks-1);
				while(ret==null && !cycle.completedCycle())
				{
					nextLink=cycle.getNext();
					NetLink link=(NetLink) (links.elementAt(nextLink));
					if (!way.isLinkPresent(link.getId()))
						ret=link.lookup(server,way);
				}
				nextLink=cycle.getNext();
			}
		}
		return ret;
	}
	
	/**
	  * Starts the searching of a server on an specified node in the net, returning a 
	  * virtual path to that server, or null if it is not found.
	  * When the server is not found in the node, the links are used to propagate
	  * the lookup; the algorythm to select a link to propagate the link will always
	  * select the link that has been longer inactive.
	  * The observers of nodes and links that are visited during the lookup will send a
	  * LookupOnNodeEvent and LookupOnLinkEvent notification
	  * @param server the name of the server
	  * @param host the node where the server is binded, or null if any node is valid
	  * @see NetLink
	  * @exception CommException if the node final can not be reached
	  * @see LookupOnNodeEvent
	  * @see LookupOnLinkEvent
	  */	
	public VirtualPath lookup(String server, NetNode host) throws CommException
	{
		checkWay(host);
		VirtualPath ret=null;
		Object Server=host.servers.get(server);
		if (Server!=null)
			ret=new VirtualPath(this,host,(BindedServer) Server);
		return ret;
	}
	
	/**
	  * Checks that there is a way to the final node, and that in the final node
	  * the server is alive.
	  * The observers of nodes and links that are visited during this check will send a
	  * LookupOnNodeEvent and LookupOnLinkEvent notification
	  * @param Final the final node to reache
	  * @param Server the server to reache
	  * @exception CommException if the node final can not be reached or if the 
	  * server is not binded to that node
	  * @see LookupOnNodeEvent
	  * @see LookupOnLinkEvent
	  */	
	public void checkWay(NetNode Final, BindedServer Server) throws CommException
	{
		if (!checkWay(Final, new MessageChain()))
			throw new CommException();
		if (!Final.servers.contains(Server))
			throw new CommException(Server);
		if (Server.hostNode!=Final)
			if (!Final.checkWay(Server.hostNode, new MessageChain()))
				throw new CommException();
	}
	
	/**
	  * Checks that there is a way to the final node
	  * The observers of nodes and links that are visited during this check will send a
	  * LookupOnNodeEvent and LookupOnLinkEvent notification
	  * @param Final the final node to reache
	  * @exception CommException if the node final can not be reached
	  * @see LookupOnNodeEvent
	  * @see LookupOnLinkEvent
	  */	
	void checkWay(NetNode Final) throws CommException
	{
		if (!checkWay(Final, new MessageChain()))
			throw new CommException();
	}
	
	boolean checkWay(NetNode Final, MessageChain way)
	{
		setChanged();
		notifyObservers(new LookupOnNodeEvent());
		doDelay();
		way.addNode(Id);
		boolean ret=this==Final;
		if(!ret)
		{
			int nLinks=links.size();
			if (nLinks>0)
			{
				CycleInt cycle=new CycleInt(nextLink,nLinks-1);
				while(!ret && !cycle.completedCycle())
				{
					nextLink=cycle.getNext();
					NetLink link=(NetLink) (links.elementAt(nextLink));
					if (!way.isLinkPresent(link.getId()))
						ret=link.checkWay(Final,way);
				}
				nextLink=cycle.getNext();
			}
		}
		return ret;
	}
	
	void doDelay()
	{
		if (Delay>0)
			try{Thread.currentThread().sleep(Delay);}
			catch(InterruptedException ex){}
	}
	
	private NodeId Id;
	private Vector links=new Vector(2,2);
	private Hashtable servers=new Hashtable(2);
	private int nextLink=0;
	private long Delay;
}