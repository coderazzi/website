package vnet;

/**
  * Event Class to notify the destruction of a NetNode
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see NodeEvent
  * @see NetNode
  */
public class NodeDestroyedEvent extends NodeEvent
{
}