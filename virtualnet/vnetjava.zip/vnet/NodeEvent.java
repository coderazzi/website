package vnet;

/**
  * Abstract parent class for all the NetNode events.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VNetEvent
  * @see NetNode
  */
public class NodeEvent extends VNetEvent
{
}