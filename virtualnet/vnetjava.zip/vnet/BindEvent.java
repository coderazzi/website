package vnet;

/**
  * Event Class to notify the binding or unbinding of server to the net
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VNetEvent
  * @see NetNode
  */
public class BindEvent extends VNetEvent
{
/**
  * @param serverName: the name of the server being binded or unbinded
  * @param bBind: specifies if it is a binding (true) or an unbinding (false)
  */
	public BindEvent(String serverName, boolean bBind)
	{
		this.serverName=serverName;
		binding=bBind;
	}
/**
  * Gets the name of server whose binding or unbinding has produced the event
  * @return The name of the server being binded or unbinded
  */
	public String getServerName()
	{
		return serverName;
	}
/**
  * Gets the type of event: binding or unbinding
  * @return True if the server is being binded
  */
	public boolean isBinded()
	{
		return binding;
	}
	private boolean binding;
	private String serverName;
}