package vnet;

/**
  * Class exception for communication exceptions
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNetException
  */
public class CommException extends VirtualNetException
{
/**
  * This constructor is used when the server has been unbinded
  * @param Server the server unbinded (it is not used inside the constructor)
  */
	public CommException(Object Server)
	{
		super("The server has been unbinded");
	}
/**
  * This constructor is used for a general Communication Exception
  */
	public CommException()
	{
		super("Communication failure");
	}
/**
  * This constructor is used to create a communication exception produced by
  * a not virtual net exception
  */
	public CommException(Exception ex)
	{
		super(ex.toString());
	}
}