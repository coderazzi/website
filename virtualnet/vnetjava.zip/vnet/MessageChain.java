package vnet;

import java.util.Vector;

/**
  * Class to represent the way that a message in the net has walked
  * It is represented by all the nodes and links that the message has been in
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
class MessageChain
{
	/**
	  * Add a node to the chain
	  * @param node the NodeId to add
	  */
	public void addNode(NodeId node)
	{
		doDelay();
		if (!nodes.contains(node))
			nodes.addElement(node);
	}
	
	/**
		* Checks if a node is in the chain
	  * @param node the NodeId to check
	  * @return true if the node is in the chain
	  */
	public boolean isNodePresent(NodeId node)
	{
		return nodes.contains(node);
	}
	
	/**
	  * Add a link to the chain
	  * @param link the LinkId to add
	  */
	public void addLink(LinkId link)
	{
		doDelay();
		if (!links.contains(link))
			links.addElement(link);
	}
	
	/**
		* Checks if a link is in the chain
	  * @param node the LinkId to check
	  * @return true if the link is in the chain
	  */
	public boolean isLinkPresent(LinkId link)
	{
		return links.contains(link);
	}
	
	void doDelay()
	{
		if (Delay>0)
			try{Thread.currentThread().sleep(Delay);}
			catch(InterruptedException ex){}
	}
	
	/**
		* Sets an additional delay that applies to every addNode and addLink on
		* any MessageChain object (is an static operation)
	  * @param delay the delay in milliseconds
	  */
	static public void setDelay(long delay)
	{
		Delay=delay;
	}

	private Vector nodes=new Vector(4,4);
	private Vector links=new Vector(4,4);
	static private long Delay=0;
};