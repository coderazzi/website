package vnet.display;

import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;
import java.util.Observer;

import vnet.*;

/**
  * Graphical peer of a NetLayout, managing GraphNodes and GraphLinks
  * This class is Observable: when it considers that must be redrawn, notifys it
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see GraphGeometry
  * @see vnet.NetLink
  */
public class GraphNet extends Observable implements Observer
{
	/**
	  * @param net the netlayout to represent
	  * @param geometry the GraphGeometry that gives the right position to the items
	  * in the GraphNet
	  */
	public GraphNet(NetLayout net, GraphGeometry geometry)
	{
		constructor(net, geometry, defaultPeriodState);
	}
	/**
	  * @param net the netlayout to represent
	  * @param geometry the GraphGeometry that gives the right position to the items
	  * in the GraphNet
	  * @param periodState when a NetLink or a NetNode changes its state, the graphLink 
	  * or the GraphNode will change its color, and the duration of this change is given 
	  * by this parameter. The duration is given in the number of calls to the draw method
	  */
	public GraphNet(NetLayout net, GraphGeometry geometry, int periodState)
	{
		constructor(net, geometry, periodState);
	}
	void constructor(NetLayout net, GraphGeometry geometry, int periodState)
	{
		PeriodState=periodState;
		Geometry=geometry;
		Enumeration enum=net.getNodes();
		while(enum.hasMoreElements())
			newNode((NetNode) enum.nextElement(),false);
		enum=net.getLinks();
		while(enum.hasMoreElements())
			newLink((NetLink) enum.nextElement(),false);
		net.addObserver(this);
		geometry.addObserver(this);
		recalculatePos();
	}
	
	/**
	  *Observer method. It doesn't pay attention to the bindEvents
	  */
	public void update(Observable obs, Object o)
	{
		if (obs instanceof GraphGeometry)
			recalculatePos();
		else if (o instanceof VirtualNetEvent)
		{
			VirtualNetEvent vo=(VirtualNetEvent)o;
			if (vo.getObservable() instanceof NetNode)
				newNode((NetNode) vo.getObservable(),true);
			else if (vo.getObservable() instanceof NetLink)
				newLink((NetLink) vo.getObservable(),true);
		}
		else if (o instanceof NodeDestroyedEvent)
		{
			Nodes.remove(((NetNode)obs).getId());
			completeRePaint=true;
			recalculatePos();
		}
		else if (o instanceof LinkDestroyedEvent)
		{
			Links.remove(((NetLink)obs).getId());
			completeRePaint=true;
		}
	}
	
	/**
	  * Draws the net, drawing each of the nodes and links
	  * @param g the Graphics where the link will be drawn
	  * @param bUpdate is true if the origin of this call has not been a
	  * component update method
	  */
	public void draw(Graphics g, boolean bUpdate)
	{
		if (completeRePaint)
		{
			completeRePaint=bUpdate=false;
			g.clearRect(0,0,lastDimension.width,lastDimension.height);
		}
		Enumeration enum=Nodes.elements();
		while(enum.hasMoreElements())
			((GraphNode) enum.nextElement()).draw(g,bUpdate);
		enum=Links.elements();
		while(enum.hasMoreElements())
			((GraphLink) enum.nextElement()).draw(g,bUpdate);
	}
	
	/**
	  * Sets the correct size for the GraphNet. 
	  * The GraphGeometry gives the positions in realite ways, between 0 and 1. These
	  * numbers have to be multiplied by the factor given by the setSize method
	  * @param redimension the dimension of the area where the net is being drawn
	  */
	public void setSize(Dimension dimension)
	{
		lastDimension=new Dimension(dimension);
		Enumeration enum=Nodes.elements();
		while(enum.hasMoreElements())
			((GraphNode) enum.nextElement()).setSize(dimension);
		enum=Links.elements();
		while(enum.hasMoreElements())
			((GraphLink) enum.nextElement()).setSize(dimension);
	}
	
	synchronized void newNode(NetNode node, boolean bOnUpdate)
	{
		bOnNewNode=true;
		GraphNode gNode=new GraphNode(node, Geometry, bOnUpdate, PeriodState);
		Nodes.put(node.getId(), gNode);
		node.addObserver(this);
		gNode.setSize(lastDimension);
		bOnNewNode=false;
		if (bRecalculatePos)
		{
			recalculatePos();
			bRecalculatePos=false;
		}
	}
	
	synchronized void newLink(NetLink link, boolean bOnUpdate)
	{
		GraphLink gLink=new GraphLink(link, Geometry, bOnUpdate, PeriodState);
		Links.put(link.getId(), gLink);
		link.addObserver(this);
		gLink.setSize(lastDimension);
	}
	
	synchronized void recalculatePos()
	{
		if (bOnNewNode)
			bRecalculatePos=true;
		else
		{
			int n=Nodes.size();
			NodeId ids[]=new NodeId[n];
			Enumeration enum=Nodes.keys();
			while(enum.hasMoreElements())
				ids[--n]=(NodeId)enum.nextElement();
			Geometry.reset(ids);
			enum=Nodes.elements();
			while(enum.hasMoreElements())
				((GraphNode)(enum.nextElement())).changePosition(Geometry);
			enum=Links.elements();
			while(enum.hasMoreElements())
				((GraphLink)(enum.nextElement())).changePosition(Geometry);
			setChanged();
			notifyObservers();
		}
	}
	
	private Hashtable Nodes=new Hashtable(4);
	private Hashtable Links=new Hashtable(4);
	private GraphGeometry Geometry;
	private Dimension lastDimension=new Dimension(0,0);
	private boolean completeRePaint=false;
	private final int defaultPeriodState=5;
	private int PeriodState;
	private boolean bOnNewNode=false, bRecalculatePos=false;
}