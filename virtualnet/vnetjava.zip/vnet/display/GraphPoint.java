package vnet.display;

/**
  * Class to manage points using float numbers
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
class GraphPoint
{
	public GraphPoint(){x=y=0;}
	public GraphPoint(double X, double Y){x=X;y=Y;}
	public GraphPoint(GraphPoint g){x=g.x;y=g.y;}
	
	public double x;
	public double y;
}