package vnet.display;

import java.awt.BorderLayout;
import java.awt.AWTEvent;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Frame;

/**
  * Simple frame to hold a GraphCanvas, and show a GraphCanvas
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class GraphNetFrame extends Frame
{

	/**
	  * @param net the GraphNet to show
	  * @param title the title for the frame
	  * @param initial new initial dimension of the frame
	  * @param periodUpdating time, in milliseconds, to do the updating of the GraphNet
	  */
	public GraphNetFrame(GraphNet net, String title, Dimension initial, long periodUpdating) 
	{
		constructor(net,title,initial,periodUpdating);
	}
	/**
	  * @param net the GraphNet to show
	  * @param title the title for the frame
	  * @param initial new initial dimension of the frame
	  */
	public GraphNetFrame(GraphNet net, String title, Dimension initial) 
	{
		constructor(net,title,initial,defaultPeriodUpdating);
	}
	void constructor(GraphNet net, String title, Dimension initial, long periodUpdating) 
	{
		//This constructor implicitly calls the Frame no-argument 
		//constructor and then adds components to the window.
		setLayout(new BorderLayout());
		add("Center",new GraphCanvas(net,periodUpdating,initial));
		setTitle(title);
		pack();
		show();
		addWindowListener(new WindowAdapter(){
													public void windowClosing(WindowEvent e)
													{dispose();}
												});
	}
	
	final int defaultPeriodUpdating=100;
	
}