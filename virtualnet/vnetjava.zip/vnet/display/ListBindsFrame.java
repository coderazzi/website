package vnet.display;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import vnet.ListBindsNet;

/**
  * Simple frame to show the servers binded in a net,
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class ListBindsFrame extends Frame
{

	/**
	  * @param lNet the ListBindsNet that is observing the net
	  * @param title the title for the frame
	  * @param initial new initial dimension of the frame
	  */
	public ListBindsFrame(ListBindsNet lNet, String title, Dimension initial)
	{
		GridBagLayout gbag=new GridBagLayout();
		GridBagConstraints c=new GridBagConstraints();
		setLayout(gbag);
		
		List l = new List();
		c.gridx=0;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.gridwidth=2;
		c.weightx=1;
		c.weighty=1;
		c.insets=new Insets(5,5,5,5);
		gbag.setConstraints(l,c);
		add(l);		
		l.setFont(new Font("Monospaced",Font.PLAIN,12));
		
		listBind=new ListBindsList(lNet,l);
		
		Button b=new Button("Update");
		c.gridy=1;
		c.fill=GridBagConstraints.NONE;
		c.gridwidth=1;
		c.weighty=0;
		
		gbag.setConstraints(b,c);
		add(b);
		b.addActionListener(
			new ActionListener(){
					public void actionPerformed(ActionEvent e)
						{listBind.update();}
		});
		
		ButSorting=new Button(SortingServer);
		sortServers=false;
		c.gridx=1;
		
		gbag.setConstraints(ButSorting,c);
		add(ButSorting);
		ButSorting.addActionListener(
			new ActionListener(){
					public void actionPerformed(ActionEvent e)
						{
							listBind.show(sortServers);
							if (sortServers=!sortServers)
								ButSorting.setLabel(NodeServer);
							else
								ButSorting.setLabel(SortingServer);
						}
		});
		

		setTitle(title);
		pack();
		setSize(initial);
		show();

		addWindowListener(new WindowAdapter(){
													public void windowClosing(WindowEvent e)
													{dispose();}
												});
		
	}
	
	boolean sortServers;
	Button ButSorting;
	String SortingServer=new String("Server Name sorting");
	String NodeServer=new String("Node Name sorting");
	ListBindsList listBind;
	
}