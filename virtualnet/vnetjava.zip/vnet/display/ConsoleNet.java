package vnet.display;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;

import vnet.*;

/**
  * Class to track down the events on a net layout
  * By default, all these events are printed in the standard output
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class ConsoleNet implements Observer
{
	/**
	  * @param net the NetLayout to manage
	  */
	public ConsoleNet(NetLayout net)
	{
		this.net=net;
		Enumeration enum=net.getNodes();
		while(enum.hasMoreElements())
			newNode((NetNode) enum.nextElement(),false);
		enum=net.getLinks();
		while(enum.hasMoreElements())
			newLink((NetLink) enum.nextElement(),false);
		net.addObserver(this);
	}
	
	/**
	  * Destructor: clean up all its observables
	  */
	public synchronized void destroy()
	{
		net.deleteObserver(this);
		Enumeration enum=net.getNodes();
		while(enum.hasMoreElements())
			((NetNode) enum.nextElement()).deleteObserver(this);
		enum=net.getLinks();
		while(enum.hasMoreElements())
			((NetLink) enum.nextElement()).deleteObserver(this);
	}
	
	/**
	  * Observer method
	  */
	public synchronized void update(Observable obs, Object o)
	{
		if (o instanceof VirtualNetEvent)
		{
			VirtualNetEvent vo=(VirtualNetEvent)o;
			if (vo.getObservable() instanceof NetNode)
				newNode((NetNode) vo.getObservable(),true);
			else if (vo.getObservable() instanceof NetLink)
				newLink((NetLink) vo.getObservable(),true);
		}
		else if (o instanceof NodeDestroyedEvent)
			console("Node ["+((NetNode)obs).getId()+"] destroyed");
		else if (o instanceof LinkDestroyedEvent)
			console("Link["+((NetLink)obs).getId()+"] destroyed");
		else if (o instanceof LookupOnNodeEvent)
			console("Node ["+((NetNode)obs).getId()+"] visited");
		else if (o instanceof LookupOnLinkEvent)
			console("Link["+((NetLink)obs).getId()+"] visited");
		else if (o instanceof BindEvent)
			manageBindEvent((NetNode) obs, (BindEvent)o);
	}

	void newNode(NetNode node, boolean bOnUpdate)
	{
		if (bOnUpdate)
			console("Node ["+node.getId()+"] created");
		node.addObserver(this);
	}
	
	void newLink(NetLink link, boolean bOnUpdate)
	{
		if (bOnUpdate)
			console("Link ["+link.getId()+"] created");
		link.addObserver(this);
	}
	
	void manageBindEvent(NetNode node, BindEvent event)
	{
		String start;
		if (event.isBinded())
			start=new String("Binded new");
		else
			start=new String("Unbinded");
		console(start+" server ["+event.getServerName()+"] on node ["+node.getId()+"]");
	}
	
	/**
	  * Output of the consoleNet. this method must be override if the output has 
	  * be redirected
	  * @param show the message to show
	  */
	protected void console(String show)
	{
		System.out.println(show);
	}
	
 NetLayout net;
	
}

	