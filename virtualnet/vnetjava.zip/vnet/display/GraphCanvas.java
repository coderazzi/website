package vnet.display;

import java.awt.AWTEvent;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.Graphics;

import java.util.Observable;
import java.util.Observer;

/**
  * Canvas component to draw a GraphNet.
  * This canvas will be automatically update every n milliseconds.
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class GraphCanvas extends Canvas implements ComponentListener, Observer
{
	/**
	  * @param net the GraphNet to hold
	  * @param periodUpdating time, in milliseconds, to do the updating of the GraphNet
	  * @param initial initial dimension of the canvas
	  */
	public GraphCanvas(GraphNet net, long periodUpdating, Dimension initial)
	{
		this.periodUpdating=periodUpdating;
		PreferredSize=new Dimension(initial);
		gNet=net;
		new graphCanvasThread().start();
		addComponentListener(this);
		net.addObserver(this);
	}

	public Dimension getPreferredSize() 
	{
		return PreferredSize;
	}
	
	public void componentHidden(ComponentEvent ce){}
	public void componentShown(ComponentEvent ce){}
	public void componentMoved(ComponentEvent ce){}
	public void componentResized(ComponentEvent ce)
	{
		gNet.setSize(getSize());
		invalidate();
		repaint();
	}
	
	/**
	  *Observer method. It doesn't pay attention to the bindEvents
	  */
	public void update(Observable obs, Object o)
	{
		gNet.setSize(getSize());
		paintTotal=true;
		invalidate();
		repaint();
	}
	public void paint (Graphics g) 
	{
		gNet.draw(g,false);
	}
	
	public void update (Graphics g) 
	{
		if (!paintTotal)
			gNet.draw(g,true);
		else
		{
			paintTotal=false;
			super.update(g);
		}
	}
	
	class graphCanvasThread extends Thread
	{
		public void run()
		{
			while(true)
			{
				try{sleep(periodUpdating);}catch(InterruptedException ie){}
				if (isShowing())
				{
					invalidate();
					repaint();
				}
			}
		}
	}
	
	Dimension PreferredSize;
	GraphNet gNet;
	long periodUpdating;
	boolean paintTotal=false;
}