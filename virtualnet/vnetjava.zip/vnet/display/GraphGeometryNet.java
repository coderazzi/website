package vnet.display;

import java.awt.Point;

import java.lang.Math;

import vnet.NodeId;

/**
  * Class to manage the output layout of a net, that disposes in a net form.
  * This geometry creates a net of squares of 4 rows and 4 columns, and disposes 
  * the nodes from left to right, from up to down.
  * The squares are disposed with the next layout:<br>
  * 41 39 37 36 38 40 42<br>
  * 32 19 17 16 18 20 33<br>
  * 28 12 05 04 06 13 29<br>
  * 26 10 02 01 03 11 27<br>
  * 30 14 08 07 09 15 31<br>
  * 34 24 22 21 23 25 35<br>
  * 48 46 44 43 45 47 49<br>
  * ...and so on<br>
  *
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class GraphGeometryNet extends GraphGeometry
{
	
	/**
	  * A geometry can calculate the position of a node in function of the nodes
	  * already present. This method allows to say to the GeometryClass which
	  * are the nodes.
	  */
	public synchronized void reset(NodeId nodes[])
	{
		minx=Integer.MAX_VALUE;
		maxx=Integer.MIN_VALUE;
		miny=Integer.MAX_VALUE;
		maxy=Integer.MIN_VALUE;
		radiusX=0;
		radiusY=0;
		for (int i=0;i<nodes.length;i++)
		{
			Point p=getRelPosition(nodes[i]);
			checkPoint(p,false);
		}
	}
	
	/**
	  * Gets the radiusX (relative size, between 0 and 1) for each node.
	  * @return the radiusX of the nodes
	  */
	public synchronized double getRadiusX()
	{
		return radiusX;
	}
	
	/**
	  * Gets the radiusY (relative size, between 0 and 1) for each node.
	  * @return the radiusY of the nodes
	  */
	public synchronized double getRadiusY()
	{
		return radiusY;
	}
	
	/**
	  * Gets the position (relative position, between 0 and 1) for a Node
	  * @param Id the Node identity
	  * @return the position for the node
	  */
	public GraphPoint getPosition(NodeId Id)
	{
		Point p=getRelPosition(Id);
		checkPoint(p,true);
		return getAbsPos(p);
	}
	
	GraphPoint getAbsPos(Point p)
	{
		double x, y;
		if (minx==maxx)
			x=0.5;
		else
			x=((((double)p.x)-minx)/(maxx-minx))*(1.0-4.0*radiusX)+2.0*radiusX;
		if (miny==maxy)
			y=0.5;
		else
			y=((((double)p.y)-miny)/(maxy-miny))*(1.0-4.0*radiusY)+2.0*radiusY;
		return new GraphPoint(x,y);
	}
	
	Point getRelPosition(NodeId Id)
	{
		int id=Id.getId();
		RelPos square=new RelPos(1+id/16);
		int nId=id%16;
		int x=4*square.x+nId%4;
		int y=4*square.y+nId/4;
		return new Point(x,y);
	}
	
	void checkPoint(Point p, boolean bAdviseIfChange)
	{
		boolean bChange=false;
		if (p.x<minx)
		{
			minx=p.x;
			bChange=true;
		}
		if (p.x>maxx)
		{
			maxx=p.x;
			bChange=true;
		}
		if (p.y<miny)
		{
			miny=p.y;
			bChange=true;
		}
		if (p.y>maxy)
		{
			maxy=p.y;
			bChange=true;
		}
		if (bChange)
		{
			radiusX=1.0/(4.0*(1+maxx-minx));
			radiusY=1.0/(4.0*(1+maxy-miny));
			if (bAdviseIfChange)
			{
				setChanged();
				notifyObservers();
			}
		}
	}
	
	int minx=Integer.MAX_VALUE,maxx=Integer.MIN_VALUE,miny=Integer.MAX_VALUE,maxy=Integer.MIN_VALUE;
	double radiusX=0, radiusY=0;
	
	/**
	  *This class gives the coordinates for an integer, with the next layout:
	  *
	  * 41 39 37 36 38 40 42
	  * 32 19 17 16 18 20 33
	  * 28 12 05 04 06 13 29
	  * 26 10 02 01 03 11 27
	  * 30 14 08 07 09 15 31
	  * 34 24 22 21 23 25 35
	  * 48 46 44 43 45 47 49
	  *
	  * ... and so on: it accepts any number. If this number is less than 1, the
	  * behaviour for the class is the same as for the number 1
	  */
	
	class RelPos
	{
		public int x,y;
	
		public RelPos(int n)
		{
			if (n<2)
				x=y=0;
			else
			{
				int l=lado(n);
				if (n<=(l*(l-2)))
					inLateral(n,l);
				else if (n<=(l*(l-1)))
					inAbove(n,l);
				else
					inDown(n,l);
			}
		}
		void inLateral(int n,int l)
		{
			n-=(l-2)*(l-2);
			if (n%2!=0)
				x=(1-l)/2;
			else
			{
				x=(l-1)/2;
				n--;
			}
			y=-relPos((int)(1+((int)(n-1)/2)));
		}
		void inAbove(int n, int l)
		{
			y=(1-l)/2;
			n-=l*(l-2);
			x=relPos(n);
		}
		void inDown(int n, int l)
		{
			y=(l-1)/2;
			n-=l*(l-1);
			x=relPos(n);
		}
		int relPos(int n)
		{
			int ret=n/2;
			return n%2==0? -ret : ret;
		}
		int lado(int n)
		{
			return (1+2*((int)((1+((int) Math.sqrt((double)(n-1))))/2)));
		}
	}	
}