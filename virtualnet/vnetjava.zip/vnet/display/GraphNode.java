package vnet.display;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Observable;
import java.util.Observer;

import vnet.NodeId;
import vnet.NetNode;
import vnet.LookupOnNodeEvent;

/**
  * Graphical peer of a NetNode (its graphical representation is a circle)
  * It manages the events lunched by a netNode, and is able to draw itself, using
  * a GraphGeometry
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see GraphGeometry
  * @see vnet.NetNode
  */
class GraphNode implements Observer
{
	/**
	  * @param node the NetNode to manage
	  * @param locator the GraphGeometry that gives the right position to the node
	  * @param bJustCreated if the associated NetNode has been just created
	  * @param stayInState when the NetNode changes its state, the graphNode will
	  * change its color, and the duration of this change is given by this parameter.
	  * The duration is given in the number of calls to the draw method
	  * @see GraphNode#draw
	  */
	public GraphNode(final NetNode node, GraphGeometry locator, boolean bJustCreated, int StayInColor)
	{
		this.StayInColor=StayInColor;
		node.addObserver(this);
		Id=node.getId();
		gPos=new GraphPoint(locator.getPosition(Id));
		gRadiusX=locator.getRadiusX();
		gRadiusY=locator.getRadiusY();
		if (bJustCreated)
			stateCreated=StayInColor;
		stateChanged=true;
	}
	
	/**
	  * Sets the correct size for the node. 
	  * The GraphGeometry gives the positions in realite ways, between 0 and 1. These
	  * numbers have to be multiplied by the factor given by the setSize method
	  * @param redimension the dimension of the area where the net is being drawn
	  */
	public void setSize(Dimension redimension)
	{
		Pos.x=(int)(gPos.x*redimension.width);
		Pos.y=(int)(gPos.y*redimension.height);
		RadiusX=(int)(gRadiusX*redimension.width);
		RadiusY=(int)(gRadiusY*redimension.height);
	}
	
	/**
	  * Change the position of the node
	  * @param locator the GraphGeometry to use
	  */
	public void changePosition(GraphGeometry locator)
	{
		gPos=new GraphPoint(locator.getPosition(Id));
		gRadiusX=locator.getRadiusX();
		gRadiusY=locator.getRadiusY();
	}
	
	/**
	  * Draws the line, if it is considered needed.
	  * It is considered needed to be painted, if the process is not an updating 
	  * process, or if the NetNode associated has just changed its state, or if,
	  * after have changed the state, the GraphNode have to come back to the original
	  * color.
	  * @param g the Graphics where the link will be drawn
	  * @param bUpdate is true if the origin of this call has not been a
	  * component update method
	  */
	public void draw(Graphics g, boolean bUpdate)
	{
		if (hasToBePainted(g,bUpdate))
		{
			g.fillOval(Pos.x-RadiusX, Pos.y-RadiusY, 2*RadiusX, 2*RadiusY);
			calculateLetterPos(g);
			g.setColor(letterColor);
			g.drawString(Id.toString(),Pos.x-LetterPos.x, Pos.y+LetterPos.y);
		}
	}
	
	boolean hasToBePainted(Graphics g, boolean bUpdate)
	{
		boolean bPaint=!bUpdate || stateChanged;
		if (bPaint || (stateCreated>0) || (stateInLookup>0))
		{
			Color c=normalColor;
			stateChanged=false;
			if(stateCreated>0)
			{
				if (--stateCreated==0)
					stateChanged=true;
				c=createdColor;
			}
			if (stateInLookup>0)
			{
				if (--stateInLookup==0)
					stateChanged=true;
				c=lookupColor;
			}
			if (bPaint)
				g.setColor(c);
		}
		return bPaint;
	}
	
	/**
	  *Observer method
	  */
	public void update(Observable obs, Object o)
	{
		if (o instanceof LookupOnNodeEvent)
		{
			stateInLookup=StayInColor;
			stateChanged=true;
		}
	}
	
	void calculateLetterPos(Graphics g)
	{
		if (bCalculateLetterPos)
		{
			bCalculateLetterPos=false;
			FontMetrics f=g.getFontMetrics();
			String print=Id.toString();
			LetterPos.y=f.getAscent()/2;
			LetterPos.x=f.stringWidth(print)/2;
		}
	}
	
	final NodeId Id;
	final Color normalColor=Color.blue;
	final Color lookupColor=Color.red;
	final Color createdColor=Color.green;
	final Color letterColor=Color.white;
	final int StayInColor;
	int RadiusX, RadiusY;
	double gRadiusX, gRadiusY;
	Point Pos=new Point();
	GraphPoint gPos;
	Point LetterPos=new Point();
	boolean bCalculateLetterPos=true;
	int stateInLookup=0;
	int stateCreated=0;
	boolean stateChanged=false;
}