package vnet.display;

import vnet.NodeId;

/**
  * Class to manage the output layout of a net, that disposes in a circular form.
  * It is create concentric circles for the nodes; in this way, the nodes A-P can
  * be in a first circle, the nodes AA-AP, in the next one, and so on.
  *
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class GraphGeometryCircle extends GraphGeometry
{
	/**
	  * A geometry can calculate the position of a node in function of the nodes
	  * already present. This method allows to say to the GeometryClass which
	  * are the nodes.
	  */
	public synchronized void reset(NodeId nodes[])
	{
		minc=Integer.MAX_VALUE;
		maxc=Integer.MIN_VALUE;
		radius=1.0/25.0;
		for (int i=0;i<nodes.length;i++)
			checkNCircles(nodes[i],false);
	}		
	/**
	  * Gets the radiusX (relative size, between 0 and 1) for each node.
	  * @return the radiusX of the nodes
	  */
	public synchronized double getRadiusX()
	{
		return radius;
	}
	
	/**
	  * Gets the radiusY (relative size, between 0 and 1) for each node.
	  * @return the radiusY of the nodes
	  */
	public synchronized double getRadiusY()
	{
		return radius;
	}

	/**
	  * Gets the position (relative position, between 0 and 1) for a Node
	  * @param Id the Node identity
	  * @return the position for the node
	  */
	public GraphPoint getPosition(NodeId Id)
	{
		checkNCircles(Id,true);
		double angle=getAnglePosition(Id);
		int c=getCircle(Id);
		double r=(1.0-4.0*radius)*((double)(c-minc+1))/((double)(maxc-minc+1));
		return new GraphPoint(
			0.5-Math.cos(angle)*r/2.0,
			0.5-Math.sin(angle)*r/2.0);
	}
	
	int getCircle(NodeId Id)
	{
		return 1+Id.getId()/16;
	}
	
	void checkNCircles(NodeId Id, boolean bAdviseIfChange)
	{
		int c=getCircle(Id);
		boolean bChange=false;
		if (c<minc)
		{
			minc=c;
			bChange=true;
		}
		if (c>maxc)
		{
			maxc=c;
			bChange=true;
		}
		if (bChange)
		{
			radius=(1.0/25.0)/((double)(maxc-minc+1));
			if (bAdviseIfChange)
			{
				setChanged();
				notifyObservers();
			}
		}
}
	
	double getAnglePosition(NodeId Id)
	{
		return ((double)(Id.getId()%16))*Math.PI/8.0;
	}

	int minc=Integer.MAX_VALUE, maxc=Integer.MIN_VALUE;	
	double radius=1.0/25.0;
}