package vnet.display;

import java.awt.List;

import java.util.Enumeration;
import java.util.Vector;

import vnet.NodeId;
import vnet.ListBindsNet;

/**
  * Class to manage the servers binded to the net, allowing its sorting
  * by Node or by Name and its display in a List
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class ListBindsList
{
	/**
	  * @param net the ListBindsNet that observes the net
	  * @param list the list where the servers will be shown
	  * @see vnet.ListBindsNet
	  */
	public ListBindsList(ListBindsNet net, List list)
	{
		this.net=net;
		this.list=list;
		update();
	}

	/**
	  * This method is called to get an output in the list.
	  * @param NodeSorted the servers are sorted by the name if NodeSorted is false
	  * and by the Node if it is true
	  */
	public void show(boolean NodeSorted)
	{
		bNodeSorted=NodeSorted;
		update();
	}

	/**
	  * This method is called to get an output in the list.
	  */
	public void update()
	{
		list.removeAll();
		StringListSorted listSorted=new StringListSorted();
		Enumeration nodes=net.getHostNodes();
		while(nodes.hasMoreElements())
		{
			NodeId id=(NodeId) nodes.nextElement();
			Enumeration servers=net.getServers(id);
			while(servers.hasMoreElements())
			{
				String serverName=(String) servers.nextElement();
				String nodeName="["+id.toString()+"]";
				if (bNodeSorted)
					listSorted.add(nodeName+sep+serverName);
				else
					listSorted.add(serverName+sep+nodeName);
			}
		}
		Enumeration names=listSorted.elements();
		while(names.hasMoreElements())
			list.add((String)names.nextElement());
	}
	
	class StringListSorted
	{
		void add(String item)
		{
			int n=cont.size();
			int pos=0;
			boolean bCont=true;
			for (int i=0;bCont && i<n;i++)
				if (((String)cont.elementAt(i)).compareTo(item)>=0)
				{
					pos=i;
					bCont=false;
				}
			if (bCont)
				cont.addElement(item);
			else
				cont.insertElementAt(item,pos);
		}
		Enumeration elements()
		{
			return cont.elements();
		}
		Vector cont=new Vector(4,4);
	}

	ListBindsNet net;
	List list;
	boolean bNodeSorted=true;
	final String sep=new String("     ");
}