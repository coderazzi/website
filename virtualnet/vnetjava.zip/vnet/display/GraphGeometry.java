package vnet.display;

import java.util.Observable;

import vnet.NodeId;

/**
  * Abstract class to manage the output layout of a net.
  * This classes has to give, for each NodeId, a position (GraphPoint), that
  * is a number (two numbers) between 0 and 1.
  * It is also able to get the line (GraphLine) that will join two NodeIds
  * Finally, it also manage the size of each node (its radius)
  * This class is observable; if the class considers that the positions that
  * have been returned are not longer valid, it will notify to its observers
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public abstract class GraphGeometry extends Observable
{
	/**
	  * A geometry can calculate the position of a node in function of the nodes
	  * already present. This method allows to say to the GeometryClass which
	  * are the nodes.
	  */
	public synchronized abstract void reset(NodeId nodes[]);
	
	/**
	  * Gets the radiusX (relative size, between 0 and 1) for each node.
	  * @return the radiusX of the nodes
	  */
	public synchronized abstract double getRadiusX();
	
	/**
	  * Gets the radiusY (relative size, between 0 and 1) for each node.
	  * @return the radiusY of the nodes
	  */
	public synchronized abstract double getRadiusY();
	
	/**
	  * Gets the position (relative position, between 0 and 1) for a Node
	  * @param Id the Node identity
	  * @return the position for the node
	  */
	public synchronized abstract GraphPoint getPosition(NodeId Id);
	
	/**
	  * Gets the line (relative sizes, between 0 and 1) for a link between two nodes
	  * @param IdA the Node identity of the first node
	  * @param IdB the Node identity of the second node
	  * @return the line that joins both nodes
	  */
	public GraphLine getPosition(NodeId IdA, NodeId IdB)
	{
		GraphPoint A=getPosition(IdA);
		GraphPoint B=getPosition(IdB);
		double angle;
		double difX=B.x-A.x;
		double difY=B.y-A.y;
		if(difX==0)
			if (difY>=0)
				angle=java.lang.Math.PI/2;
			else
				angle=-java.lang.Math.PI/2;
		else
		{
			angle=java.lang.Math.atan(difY/difX);
			if (difX<0)
				angle+=java.lang.Math.PI;
		}
		double upx=getRadiusX()*java.lang.Math.cos(angle);
		double upy=getRadiusY()*java.lang.Math.sin(angle);
		A.x+=upx;
		B.x-=upx;
		A.y+=upy;
		B.y-=upy;
		return new GraphLine(A,B);
	}

}