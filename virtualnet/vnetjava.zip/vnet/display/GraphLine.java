package vnet.display;


/**
  * Class to manage Lines, in its definition as the conection between two Points,
  * in this case, two GraphPoint
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
class GraphLine
{
	public GraphLine()
	{
		start=new GraphPoint();
		end=new GraphPoint();
	}
		
	public GraphLine(GraphPoint Start, GraphPoint End)
	{
		start=new GraphPoint(Start);
		end=new GraphPoint(End);
	}
		
	public GraphLine(GraphLine line)
	{
		start=new GraphPoint(line.start);
		end=new GraphPoint(line.end);
	}
		
	public GraphPoint start,end;
}