package vnet.display;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Observable;
import java.util.Observer;

import vnet.LinkId;
import vnet.NetLink;
import vnet.LookupOnLinkEvent;

/**
  * Graphical peer of a NetLink (its graphical representation is a line)
  * It manages the events lunched by a netLink, and is able to draw itself, using
  * a GraphGeometry
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see GraphGeometry
  * @see vnet.NetLink
  */
class GraphLink implements Observer
{
	/**
	  * @param link the NetLink to manage
	  * @param locator the GraphGeometry that gives the right position to the line
	  * @param bJustCreated if the associated NetLink has been just created
	  * @param stayInState when the NetLink changes its state, the graphLink will
	  * change its color, and the duration of this change is given by this parameter.
	  * The duration is given in the number of calls to the draw method
	  * @see GraphLink#draw
	  */
	public GraphLink(NetLink link, GraphGeometry locator, boolean bJustCreated, int stayInState)
	{
		this.link=link;
		this.StayInColor=stayInState;
		link.addObserver(this);
		Id=link.getId();
		gLine=new GraphLine(locator.getPosition(link.getNodeA().getId(),link.getNodeB().getId()));
		if (bJustCreated)
			stateCreated=StayInColor;
		stateChanged=true;
	}
	
	/**
	  * Sets the correct size for the line. 
	  * The GraphGeometry gives the positions in realite ways, between 0 and 1. These
	  * numbers have to be multiplied by the factor given by the setSize method
	  * @param redimension the dimension of the area where the net is being drawn
	  */
	public void setSize(Dimension redimension)
	{
		PosA.x=(int)(gLine.start.x*redimension.width);
		PosA.y=(int)(gLine.start.y*redimension.height);
		PosB.x=(int)(gLine.end.x*redimension.width);
		PosB.y=(int)(gLine.end.y*redimension.height);
	}
	
	/**
	  * Change the position of the node
	  * @param locator the GraphGeometry to use
	  */
	public void changePosition(GraphGeometry locator)
	{
		gLine=new GraphLine(locator.getPosition(link.getNodeA().getId(),link.getNodeB().getId()));
	}
	
	/**
	  * Draws the line, if it is considered needed.
	  * It is considered needed to be painted, if the process is not an updating 
	  * process, or if the NetLink associated has just changed its state, or if,
	  * after have changed the state, the GraphLink have to come back to the original
	  * color.
	  * @param g the Graphics where the link will be drawn
	  * @param bUpdate is true if the origin of this call has not been a
	  * component update method
	  */
	public void draw(Graphics g, boolean bUpdate)
	{
		if (hasToBePainted(g,bUpdate))
		{
			g.drawLine(PosA.x, PosA.y,PosB.x, PosB.y);
			calculateLetterPos(g);
			g.drawString(Id.toString(),(PosA.x+PosB.x)/2-LetterPos.x, (PosA.y+PosB.y)/2+LetterPos.y);
		}
	}
	
	boolean hasToBePainted(Graphics g, boolean bUpdate)
	{
		boolean bPaint=!bUpdate || stateChanged;
		if (bPaint || (stateCreated>0) || (stateInLookup>0))
		{
			Color c=normalColor;
			stateChanged=false;
			if(stateCreated>0)
			{
				if (--stateCreated==0)
					stateChanged=true;
				c=createdColor;
			}
			if (stateInLookup>0)
			{
				if (--stateInLookup==0)
					stateChanged=true;
				c=lookupColor;
			}
			if (bPaint)
				g.setColor(c);
		}
		return bPaint;
	}
	
	/**
	  *Observer method
	  */
	public void update(Observable obs, Object o)
	{
		if (o instanceof LookupOnLinkEvent)
		{
			stateInLookup=StayInColor;
			stateChanged=true;
		}
	}
	
	void calculateLetterPos(Graphics g)
	{
		if (bCalculateLetterPos)
		{
			bCalculateLetterPos=false;
			FontMetrics f=g.getFontMetrics();
			String print=Id.toString();
			LetterPos.y=f.getAscent()/2;
			LetterPos.x=f.stringWidth(print)/2;
		}
	}
	
	final NetLink link;
	final LinkId Id;
	final int StayInColor;
	final Color normalColor=Color.blue;
	final Color createdColor=Color.green;
	final Color lookupColor=Color.red;
	boolean bCalculateLetterPos=true;
	Point LetterPos=new Point();
	Point PosA=new Point();
	Point PosB=new Point(); 
	GraphLine gLine;
	int stateInLookup=0;
	int stateCreated=0;
	boolean stateChanged=false;
}