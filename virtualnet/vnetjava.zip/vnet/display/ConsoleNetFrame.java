package vnet.display;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import vnet.NetLayout;

/**
  * Class to track down the events on a net layout, showing the events in a frame
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class ConsoleNetFrame extends Frame
{

	/**
	  * @param net the NetLayout to manage
	  * @param title the title for the frame
	  * @param initial new initial dimension of the frame
	  */
	public ConsoleNetFrame(NetLayout net, String title, Dimension initial)
	{
		GridBagLayout gbag=new GridBagLayout();
		GridBagConstraints c=new GridBagConstraints();
		setLayout(gbag);
		
		
		listEvents = new List ();
		c.gridx=0;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.weightx=1;
		c.weighty=1;
		c.insets=new Insets(5,5,5,5);
		gbag.setConstraints(listEvents,c);
		add(listEvents);		
		
		Button b=new Button("Clear");
		c.gridy=1;
		c.fill=GridBagConstraints.NONE;
		c.weighty=0;
		
		gbag.setConstraints(b,c);
		add(b);
		b.addActionListener(
			new ActionListener(){
					public void actionPerformed(ActionEvent e)
						{listEvents.removeAll();}
		});

		setTitle(title);		
		pack();
		setSize(initial);
		show();

		addWindowListener(new WindowAdapter(){
													public void windowClosing(WindowEvent e)
													{dispose();}
												});
		
		this.net=new GraphConsoleNet(net);

	}
	
	/**
	  * Allows the destruction of the ConsoleNet, and its cleaning up
	  */
	public void dispose()
	{
		net.destroy();
		super.dispose();
	}
	
	List listEvents;
	GraphConsoleNet net;
	
	class GraphConsoleNet extends ConsoleNet
	{
		GraphConsoleNet(NetLayout net){super(net);}	
		protected void console(String s){listEvents.add(s);}
	}
	
}