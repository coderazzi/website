package vnet;

/**
  * Class to represent general exceptions involving the NetLayout
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see BuildNetLayout
  * @see NetLayout
  * @see NetNode
  * @see NodeId
  */
public class VNException extends VirtualNetException
{
/**
  * This constructor is used when to manage the creation of a node/link
  * that already exists, or the removing of a node/link not allowing to the net.
  * @param bApplyToNode true ifthe exception applies to a node
  * @Id the identity of the node/link
  * @bItExists true if the exception is produced because the node/linl already existed
  */
	public VNException(boolean bApplyToNode, String Id, boolean bItExists)
	{
		StringBuffer create=new StringBuffer();
		if (bApplyToNode)
			create.append("Node [");
		else
			create.append("Link [");
		create.append(Id);
		if (bItExists)
			create.append("] already exists");
		else
			create.append("] doesn't exist");
		string=new String(create.toString());
	}
	
/**
  * This constructor is used when the exception is produced by a NodeId null or with
  * length=0;
  */
	public VNException()
	{
		string=new String("The NodeId descriptor can not be null or empty");
	}
	
/**
  * This constructor is used when the exception is produced by a NodeId not valid
  * @param Id the char invalid in the string representing the Node
  */
	public VNException(char Id)
	{
		string=new String("["+Id+"] is not a char valid for a NodeId");
	}
	
/**
  * General constructor
  * @param input the exception message
  */
	public VNException(String input)
	{
		string=new String(input);
	}
	
/**
  * @Return a description of the exception
  */
	public String toString()
	{
		return super.toString()+" : "+string;
	}

	private String string;	
}