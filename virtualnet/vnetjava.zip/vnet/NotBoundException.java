package vnet;

/**
  * Class exception for unbind operations
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNetException
  */
public class NotBoundException extends BindException
{
/**
  * This constructor is used when the name of the server is not found
  * @param server the name of the server being looking for
  */
	public NotBoundException (String server)
	{
		super("NameServer ["+server+"] is not binded");
	}
}