package vnet;

/**
  * Class to represent a link identity
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see NetLink
  */
public class LinkId implements java.io.Serializable
{
	/**
	  * @param id the short representing the link
	  */
	public LinkId(int id)
	{
		Id=id;
	}

	/**
	  * @param element other Linkd to be compared to
	  * @return true if bot have the same identity
	  */
	public boolean equals(Object element)
	{
		boolean ret=false;
		if (element instanceof LinkId)
			ret=Id==((LinkId)element).Id;
		return ret;
	}

	/**
	  * @return a valid hash code
	  */
	public int hashCode()
	{
		return Id;
	}
	
	/**
	  * @return a printable form of the LinkId
	  */
	public String toString()
	{
		return String.valueOf(Id);
	}

	/**
	  * @return the identity
	  */
	public int getId()
	{
		return Id;
	}

	private int Id;
}