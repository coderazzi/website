package vnet;

/**
  * Class exception for Server Binding exceptions
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNetException
  */
public class BindException extends VirtualNetException
{
/**
  * @param message the reason for the exception
  */
	public BindException (String message)
	{
		super(message);
	}
}