package vnet;

import java.util.Observable;

/**
  * Class to represent a link in the net. 
  * In this simulation, a link is any communication channel beetween two nodes
  * in the net, that can be break down at any moment. If a node is fail down,
  * all its links are also considered to fail.
  * It implements the Observable function of the observer pattern.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class NetLink extends Observable 
{
	/**
	  * @param id the identity of the link
	  * @param nodeA any of the two nodes associated to this link
	  * @param nodeB the another node
	  * @param delay the delay involving any operation on this link
	  * @exception VNException if any of the nodes fails in the operation addLink
	  * @see NetNode#addLink
	  */	
	public NetLink(final LinkId id, NetNode nodeA, NetNode nodeB, long delay) throws VNException
	{
		Id=id;
		this.nodeA=nodeA;
		this.nodeB=nodeB;
		Delay=delay;
		try
		{
			nodeA.addLink(this);
			nodeB.addLink(this);
		}
		catch(VNException ne)
		{
			try
			{
				nodeA.removeLink(this);
				nodeB.removeLink(this);
			}
			catch(VNException e)
			{
			}
			throw ne;
		}
	}
	
	/**
	  * Returns the identity of the Link
	  * @return The identity of the link
	  */	
	public LinkId getId()
	{
		return Id;
	}
	
	/**
	  * Returns the first of the nodes associated to the link
	  * @return The first of the nodes associated
	  */	
	public NetNode getNodeA()
	{
		return nodeA;
	}
	
	/**
	  * Returns the second node associated to the link
	  * @return The second node associated to the link
	  */	
	public NetNode getNodeB()
	{
		return nodeB;
	}
	
	/**
	  * Destructor of the link: notifies it to the nodes associated to the link
	  * The observers of the node will receive a LinkDestroyedEvent notification
	  * The list of observers is cleared
	  * @exception VNException if any of the nodes associated fails during the
	  * removeLink operation
	  * @see NetNode#removeLink
	  * @see LinkDestroyedEvent
	  */	
	public void destroy() throws VNException
	{
		nodeA.removeLink(this);
		nodeB.removeLink(this);
		setChanged();
		notifyObservers(new LinkDestroyedEvent());
		deleteObservers();
	}
	
	VirtualPath lookup(String server, MessageChain way)
	{
		setChanged();
		notifyObservers(new LookupOnLinkEvent());
		doDelay();
		VirtualPath ret=null;
		way.addLink(Id);
		if (!way.isNodePresent(nodeA.getId()))
			ret=nodeA.lookup(server,way);
		else if (!way.isNodePresent(nodeB.getId()))
			ret=nodeB.lookup(server,way);
		return ret;
	}
	
	boolean checkWay(NetNode Final, MessageChain way)
	{
		setChanged();
		notifyObservers(new LookupOnLinkEvent());
		boolean ret=false;
		doDelay();
		way.addLink(Id);
		if (!way.isNodePresent(nodeA.getId()))
			ret=nodeA.checkWay(Final,way);
		else if (!way.isNodePresent(nodeB.getId()))
			ret=nodeB.checkWay(Final,way);
		return ret;
	}
	
	void doDelay()
	{
		if (Delay>0)
			try{Thread.currentThread().sleep(Delay);}
			catch(InterruptedException ex){}
	}
	
	private NetNode nodeA, nodeB;
	private LinkId Id;
	private long Delay;
}