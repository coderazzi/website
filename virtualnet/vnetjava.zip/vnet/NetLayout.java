package vnet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

/**
  * Class to represent the virtual net layout
  * It is a representation of nodes (machines) and links (communication channels)
  * where any node or link can fail.
  * This net layout only simulates only the physical layout, that is, it manages
  * the adding or removing of nodes and links in the net, but not the binding,
  * unbinding or lookup of servers in the net.
  * It implements the Observable function of the observer pattern.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class NetLayout extends Observable implements Observer
{

/**
  * Default constructor
  */
	public NetLayout()	
	{
		Delay=defaultDelay;
	}

/**
  * This constructor allows to specify the default delay that will apply for the
  * nodes and links in the net.
  * @param delay the delay that will apply by default to the nodes and links
  */
	public NetLayout(long delay)
	{
		Delay=delay;
	}
	
/**
  * This is the destructor: destroy the nodes of the net, who destroy themselves
  * the links, notifying all this events to the observes.
  * @exception VNException if any NetNode.destroy() fails
  * @see NetNode#destroy
  */
	public void destroy() throws VNException
	{
		Enumeration nodes=getNodes();
		while(nodes.hasMoreElements())
			((NetNode)nodes.nextElement()).destroy();
	}

/**
  * Inserts a new node in the net, with the default delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new node inside
  * @param id the Node identity
  * @exception VNException if the NodeId has already been added to the net
  * @see NetLayout#NetLayout(long)
  */
	public void addNode(NodeId id) throws VNException
	{
		addNode(id,Delay);
	}
	
/**
  * Inserts a new node in the net, with the specified delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new node inside
  * @param id the Node identity
  * @param delay the expected delay
  * @exception VNException if the NodeId has already been added to the net
  */
	public synchronized void addNode(NodeId id, long delay) throws VNException
	{
		if (nodes.containsKey(id))
			throw new VNException(true,id.toString(),true);
		else
		{
			NetNode node=new NetNode(id,delay);
			nodes.put(id,node);
			node.addObserver(this);
			setChanged();
			notifyObservers(new VirtualNetEvent(node));
		}
	}
	
/**
  * Removes a Node out of the net.
  * @param id the Node identity
  * @exception VNException if the NodeId doesn't allow to the net
  */
	public synchronized void removeNode(NodeId id) throws VNException
	{
		getNode(id).destroy();
	}
	
/**
  * Inserts a new link in the net, with the default delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new link inside
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  * @see NetLayout#NetLayout(long)
  */
	public void addLink(LinkId id, NodeId idA, NodeId idB) throws VNException
	{
		addLink(id,idA,idB,Delay);
	}
	
/**
  * Inserts a new link in the net, with the specified delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new link inside
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @param delay the expected delay
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  */
	public synchronized void addLink(LinkId id, NodeId idA, NodeId idB, long delay) throws VNException
	{
		if (links.containsKey(id))
			throw new VNException(false,id.toString(),true);
		else
		{
			NetNode nodeA=getNode(idA);
			NetNode nodeB=getNode(idB);
			NetLink link=new NetLink(id,nodeA,nodeB,delay);
			links.put(id,link);
			link.addObserver(this);
			setChanged();
			notifyObservers(new VirtualNetEvent(link));
		}
	}
	
/**
  * Removes a Link out of the net.
  * @param id the Link identity
  * @exception VNException if the LinkId doesn't allow to the net or the destroy()
  * NetLink method fails
  * @see NetLink#destroy
  */
	public synchronized void removeLink(LinkId id) throws VNException
	{
		NetLink link=(NetLink) (links.get(id));
		if (link==null)
			throw new VNException(false,id.toString(),false);
		else
		{
			link.destroy();
			links.remove(id);
		}
	}
	
	/**
		* Sets an additional delay that applies to every message operation between nodes
		* (and links)
	  * @param delay the delay in milliseconds
	  */
	static public void setNetDelay(long delay)
	{
		MessageChain.setDelay(delay);
	}
	
	/**
		* Gets the nodes included in the net
	  * @return the nodes in the net
	  */
	public synchronized Enumeration getNodes()
	{
		return nodes.elements();
	}
	
	/**
		* Gets the links included in the net
	  * @return the links in the net
	  */
	public synchronized Enumeration getLinks()
	{
		return links.elements();
	}
	
	/**
		* Observable method
	  */
	public synchronized void update(Observable o, Object arg)
	{
		if (arg instanceof NodeDestroyedEvent)
			nodes.remove(((NetNode) o).getId());
		else if (arg instanceof LinkDestroyedEvent)
			links.remove(((NetLink) o).getId());
	} 
	
	/**
		* Gets the NetNode of the net with the specified id
		* @param id the NodId to look for
	  * @return the NetNode with the specified id
	  * @exception VNException if there is no NetNode with such NodeId
	  */
	public synchronized NetNode getNode(NodeId id) throws VNException
	{
		NetNode node=(NetNode) (nodes.get(id));
		if (node==null)
			throw new VNException(true,id.toString(),false);
		return node;
	}
	

	private Hashtable nodes=new Hashtable(4);
	private Hashtable links=new Hashtable(4);
	private final int defaultDelay=100;
	private long Delay;
}