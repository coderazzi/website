package vnet;

/**
  * A BindedServer is a wrapper for the server connected, in order to
  * have an unique identifier
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class BindedServer
{
	/**
	  * @param Server the server to wrap
	  * @param hostNode the NetNode where this server is hosted (it can be
	  * different from the node where it is binded)
	  */
	public BindedServer(Object Server, NetNode hostNode)
	{
		object=Server;
		this.hostNode=hostNode;
		uniqueId=nextId++;
	}
	/**
	  * @param other the object to compare
	  */
	public boolean equals(Object other)
	{
		boolean ret=false;
		if (other instanceof BindedServer)
			ret=uniqueId==((BindedServer)other).uniqueId;
		return ret;
	}
	/**
	  * The object (server) wrapped
	  */
	public Object object=null;
	/**
	  * The id, unique for each BindedServer object
	  */
	public long uniqueId;
	/**
	  * the NetNode where this server is hosted (it can be
	  * different from the node where it is binded)
	  */
	public NetNode hostNode;
	
	static private long nextId=1l;
}