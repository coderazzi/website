package vnet;

/**
  * A virtual path is the node initial and final of the communication, and the
  * server involved in that communication. 
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class VirtualPath
{
	/**
	  * @param NodeInitial the node initial in the communication
	  * @param NodeFinal the node where the server is located.
	  * @param Server teh server involved inthe communication
	  */
	public VirtualPath(NetNode NodeInitial, NetNode NodeFinal, BindedServer Server)
	{
		nodeInitial=NodeInitial;
		nodeFinal=NodeFinal;
		server=Server;
	}
	/**
	  * @param NodeFinal the node where the server is located.
	  * @param Server teh server involved inthe communication
	  */
	public VirtualPath(NetNode NodeFinal, BindedServer Server)
	{
		nodeFinal=NodeFinal;
		server=Server;
	}
	/**
	  * The node initial in the communication involving this path
	  */
	public NetNode nodeInitial=null;
	/**
	  * The node final in the communication involving this path
	  */
	public NetNode nodeFinal=null;
	/**
	  * The server involved in this path
	  */
	public BindedServer server=null;
}