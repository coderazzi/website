package vnet;

/**
  * Class to build net layouts from a formatted string
  * It converts a string into a serie of add and remove link and nodes, and
  * execute them. The operation format is (it doesn't mind the case):<p>
  * -addNode A: +A<p>
  * -removeNode AB : -AB<p>
  * -addLink 1 between B and CD : +B1CD (or +CD1B)<p>
  * -removeLink 1 : -1<p>
  * -specify a delay : [delay]<p>
  * Example: to create a netlayout with three nodes A, B, C, three links, a 
  * delay for all of them of 100, and a specific delay of [200] for the 3rd link,
  * the string could be:<p>
  * [100]+A+B+C+A1B+A2C[200]+B3C
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class BuildNetLayout
{
/**
  * Basic constructor
  * @param net the NetLayout to build
  */
	public BuildNetLayout(NetLayout net)
	{
		this.net=net;
	}

/**
  * Extended constructor, it allows to specify an string to be processed
  * @param net the NetLayout to build
  * @exception VNException if buildNet raises this exception
  * @see BuildNetLayout#buildNet
  */
	public BuildNetLayout(String s, NetLayout net) throws VNException
	{
		this.net=net;
		buildNet(s);
	}
	
/**
  * Process the string and builds the net. If an exception is raised, the
  * processing finishes, but the substring already processed is not affected.
  * @param s the string to process
  * @exception VNException if the string format is not valid, or any of the 
  * operations produced raises the exception.
  */
	public void buildNet(String s) throws VNException
	{
		int len=s.length();
		if (len==1)
			error(s);
		else if (len>0)
		{
			String next=null;
			String rest=s.substring(1);
			switch(s.charAt(0))
			{
				case '+':
					next=addItem(rest);
					break;
				case '-':
					next=removeItem(rest);
					break;
				case '[':
					next=modifyDelay(rest);
					break;
				default:
					error(s);
			}
			if (next!=null)
				buildNet(next);
		}
	}
	
	void error(String s) throws VNException
	{
		throw new VNException(s+" is not a valid input");
	}
	
	String addItem(String s) throws VNException
	{
		String now=null;
		String rest=null;
		int next=findNextOrder(s);
		if(next==0)
			error(s);
		else if(next==-1)
			now=s;
		else
		{
			now=s.substring(0,next);
			rest=s.substring(next);
		}
		proccessItemToAdd(now);
		return rest;
	}
	
	void proccessItemToAdd(String now) throws VNException
	{
		int d=findNextDigit(now);
		if (d==0)
			error(now);
		else if (d==-1)	//only a node
			addNode(new NodeId(now));
		else //node link node
		{
			String szNodeA=now.substring(0,d);
			String rest=now.substring(d);
			int l=findNextLetter(rest);
			if (l==-1)
				error(now);
			else
			{
				String szLink=rest.substring(0,l);
				String szNodeB=rest.substring(l);
				NodeId nodeA=new NodeId(szNodeA);
				NodeId nodeB=new NodeId(szNodeB);
				LinkId link=null;
				try{link=new LinkId(Integer.valueOf(szLink).intValue());}
				catch (Exception ex){error(now);}
				addLink(link,nodeA,nodeB);
			}
		}
	}
	
	String removeItem(String s) throws VNException
	{
		String now=null;
		String rest=null;
		int next=findNextOrder(s);
		if(next==0)
			error(s);
		else if(next==-1)
			now=s;
		else
		{
			now=s.substring(0,next);
			rest=s.substring(next);
		}
		proccessItemToRemove(now);
		return rest;
	}
	
	void proccessItemToRemove(String now) throws VNException
	{
		LinkId link=null;
		NodeId node=null;
		try
		{
			link=new LinkId(Integer.valueOf(now).intValue());
		}
		catch (Exception n)
		{
			node=new NodeId(now);
		}
		if (link==null)
			net.removeNode(node);
		else
			net.removeLink(link);
	}
	
	String modifyDelay(String s) throws VNException
	{
		String rest=null;
		int i=s.indexOf(']');
		if(i==-1 || i==0)
			error(s);
		else
		{
			String now=null;
			now=s.substring(0,i);
			if (i!=(s.length()-1))
				rest=s.substring(i+1);
			try{delay=Long.valueOf(now).longValue();}
			catch (Exception ex){error(s);}
			System.out.println("Nuevo delay: "+delay);
		}
		return rest;
	}
	
	int findNextOrder(String s)
	{
		int a=s.indexOf('+');
		int b=s.indexOf('-');
		int c=s.indexOf('[');
		if (a==-1) a=Integer.MAX_VALUE;
		if (b==-1) b=Integer.MAX_VALUE;
		if (c==-1) c=Integer.MAX_VALUE;
		int ret=java.lang.Math.min(a,b);
		ret=java.lang.Math.min(ret,c);
		if (ret==Integer.MAX_VALUE)
			ret=-1;
		return ret;
	}
	
	int findNextDigit(String s)
	{
		int ret=-1;
		for (int i=0;i<s.length() && ret==-1;i++)
			if (Character.isDigit(s.charAt(i)))
				ret=i;
		return ret;
	}
	
	int findNextLetter(String s)
	{
		int ret=-1;
		for (int i=0;i<s.length() && ret==-1;i++)
			if (Character.isLetter(s.charAt(i)))
				ret=i;
		return ret;
	}
	
	void addNode(NodeId node) throws VNException
	{
		if (delay!=-1)
			net.addNode(node,delay);
		else
			net.addNode(node);
	}
	
	void addLink(LinkId link, NodeId nodeA, NodeId nodeB) throws VNException
	{
		if (delay!=-1)
			net.addLink(link,nodeA,nodeB,delay);
		else
			net.addLink(link,nodeA,nodeB);
	}
	
	NetLayout net;
	long delay=-1;
	
}