package vnet;

/**
  * Class to represent an integer from 0 to a maximum number
  * This cycleInt element can be incremented by one each time; when it reaches
  * the maximum, its value is set to 0.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
class CycleInt
{
	/**
		* param _start the number between 0 and _max to start the cycling
		* param _max the maximum number (included) that CyCleInt can hold
	  */
	public CycleInt(int _start, int _max)
	{
		start=_start;
		max=_max;
		if(_start>_max)
			_start=0;
		next=start;
		completed=false;
	}
	
	/**
		* @return the next element in the iteration
	  */
	public int getNext()
	{
		int ret=next;
		if (++next>max)
			next=0;
		completed=next==start;
		return ret;
	}
	
	/**
		* @return true if the CycleInt has finished a complete iteration
	  */
	public boolean completedCycle()
	{
		return completed;
	}
	
	private int start, max, next;
	private boolean completed;
}