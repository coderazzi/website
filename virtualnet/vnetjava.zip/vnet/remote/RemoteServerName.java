package vnet.remote;

import java.net.MalformedURLException;
import java.net.UnknownHostException;

import vnet.NodeId;
import vnet.VNException;

/**
  * Class to manage the server Names in the remote VirtualNet
  * All the operations needs to have a serverName. This string may be the
  * plain server Name, or a qualified one, specifying the host for the server;
  * in this last case, the string starts with '/', and the expected format is:<p>
  * /name of the virtualNet/HostN/name of the server.<p>
  * For example, to look for the server "Server" in the Host B of the virtualNet
  * called "ExampleNet", the serverName would be: /ExampleNet/HostB/Server
  * @author LuisM Pena
  * @version 0.2, august-1997
  */
public class RemoteServerName
{
	/**
	  * Checks that the serverName is valid, 
	  * @param serverName the name to verify
	  * @param virtualNetName The name of the virtualNet using this class
	  * @exception MalformedURLException if is not a valid string
	  * @exception UnknownHostException if the host specified is not valid
	  */
	public RemoteServerName(String serverName, String virtualNetName) throws MalformedURLException, UnknownHostException
	{
		if(serverName==null || serverName.length()==0)
			throw new MalformedURLException(serverName);
		if(serverName.charAt(0)!='/')
		{
			node=null;
			this.serverName=new String(serverName);
		}
		else
		{
			String checkName=new String("/"+virtualNetName+"/Host");
			int lenCheckName=checkName.length();
			int lastBar=serverName.lastIndexOf('/');
			if (!serverName.startsWith(checkName) || lenCheckName>=lastBar)
				throw new MalformedURLException(serverName);
			else
			{
				try{node=new NodeId(serverName.substring(lenCheckName,lastBar));}
				catch(VNException e){throw new UnknownHostException(serverName);}
				this.serverName=new String(serverName.substring(lastBar+1));
			}
		}
	}
	
	public String getServerName(){return serverName;}
	public NodeId getNode(){return node;}
	
	private String serverName=null;
	private NodeId node=null;
}
	  