package vnet.remote;

import java.lang.reflect.Method;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;

/**
  * Remote Vnet compiler. It generates an vnet stub for any server stub in the virtual
  * net. The class generated has to be compiled before use it (it is only generated
  * the .java file); the name of this file is the server class name, with Stub__VNet as suffix
  * The class is defined in the same package as the original class.
  * The directory will be also defined by the package
  * In fact, what this compiler does is generate an stub for the rmic stub, not for
  * the server itself.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class vnc
{
	public vnc(String file)
	{
		try
		{
			Class c = Class.forName(file);
			String name=getName(c);
			String packageName=getPackage(c);
			String nameVNet=name+"_Stub_VNet";
			createFile(packageName,nameVNet);
			StringBuffer intro=new StringBuffer();
			if (packageName!=null)
				generate("package "+packageName+";\n");
			intro.append("public class "+nameVNet+" extends "+ remoteClass);
			Class intf[]=c.getInterfaces();
			if (intf.length==0)
				error(c.getName()+" doesn't implement a " +remoteInterface +" Interface");
			else
			{
				intro.append(" implements " + intf[0].getName());
				for (int j=1;j<intf.length;j++)
					intro.append(" , "+intf[j].getName());
				generate(intro.toString());
				generate("{");
				generate("\tpublic "+nameVNet+"() throws java.rmi.RemoteException{}");
				for (int j=0;j<intf.length;j++)
				{
					checkIsVRemote(intf[j]);
					Method methods[]=intf[j].getMethods();
					for(int k=0;k<methods.length;k++)
						newMethod(methods[k]);
				}
				generate("}");
			}
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(IOException c)
		{
			System.out.println(c);
		}
		catch(Exception c)
		{
			System.out.println(c.getMessage());
		}
		closeFiles();
	}
	
	void newMethod(Method m) throws Exception
	{
		Class returnType=m.getReturnType();
		String name=m.getName();
		Class exceptions[]=m.getExceptionTypes();
		Class parameters[]=m.getParameterTypes();
		boolean bIsVRemoteException=false;
		for(int i=0;!bIsVRemoteException && i<exceptions.length;i++)
				bIsVRemoteException=checkIsVException(exceptions[i]);;
		if (!bIsVRemoteException)
			throw new Exception("The method "+ name+" has to throw the "+ remoteException+" exception");
		StringBuffer signature=new StringBuffer("\tpublic "+returnType.getName()+" "+name+"(");
		StringBuffer call=new StringBuffer("(("+m.getDeclaringClass().getName()+") Path.server.object)."+name+"(");
		for(int i=0;i<parameters.length;i++)
		{
			String parameterName=parameters[i].getName();
			int j=parameterName.lastIndexOf('.');
			String parameter;
			if (j==0)
				parameter=parameterName;
			else
				parameter=parameterName.substring(j+1);
			if(i>0)
			{
				signature.append(", ");
				call.append(", ");
			}
			signature.append(parameterName+" _"+parameter);
			call.append(" _"+parameter);
		}
		signature.append(") throws "+exceptions[0].getName());
		call.append(");");
		for(int i=1;i<exceptions.length;i++)
			signature.append(", " + exceptions[i].getName());
		generate(signature.toString());
		generate("\t{");
		generate("\t\tcheckWay();");
		if (returnType.getName().compareTo("void")==0)
			generate("\t\t"+call.toString());
		else
			generate("\t\treturn "+call.toString());
		generate("\t}");
	}
	
	void checkIsVRemote(Class c) throws Exception
	{
		if (c.getName().compareTo(remoteInterface)!=0)
		{
			Class intf[]=c.getInterfaces();
			if (intf.length==0)
				throw new Exception(c.getName()+" doesn't extend the "+remoteInterface+" Interface");
			for(int i=0;i<intf.length;i++)
				checkIsVRemote(intf[i]);
		}
	}
	
	boolean checkIsVException(Class c) throws Exception
	{
		boolean ret=c.getName().compareTo(remoteException)!=0;
		if (!ret)
		{
			Class padre=c.getSuperclass();
			if (padre!=null)
				ret=checkIsVException(padre);
		}
		return ret;
	}
	
	String getName(Class c)
	{
		String temp=c.getName();
		int i=temp.lastIndexOf('.');
		String ret;
		if (i==-1)
			ret=temp;
		else
			ret=temp.substring(i+1);
		return ret;
	}
	
	String getPackage(Class c)
	{
		String temp=c.getName();
		int i=temp.lastIndexOf('.');
		String ret;
		if (i==-1)
			ret=null;
		else
			ret=temp.substring(0,i);
		return ret;
	}
	
	void createFile(String packageName, String name) throws IOException
	{
		closeFiles();
		StringBuffer cname=new StringBuffer();
		if (packageName!=null)
			cname.append(packageName.replace('.','/')+"/");
		cname.append(name+".java");
		String scname=cname.toString();
		fileOutput=new FileOutputStream(scname);
		output=new PrintWriter(fileOutput);
		System.out.println("Generating file "+scname);
	}
	
	void closeFiles()
	{
		try
		{
			if (output!=null)
				output.close();
			output=null;
		}
		catch(Exception ex){}
		try
		{
			if (fileOutput!=null)
				fileOutput.close();
			fileOutput=null;
		}
		catch(Exception ex){}
	}
	
	void error(String s)
	{
		System.out.println(s);
	}
	
	void generate(String s)
	{
		output.println(s);
	}
	
	String remoteClass=new String("vnet.remote.RemoteClass");
	String remoteInterface=new String("java.rmi.Remote");
	String remoteException=new String("java.rmi.RemoteException");
	FileOutputStream fileOutput=null;
	PrintWriter output=null;
	
	public static void main(String args[])
	{
		System.out.println("Remote VNet Compiler v0.1 (c) LuisM Pena, Agosto-1997");
		if (args.length!=1)
			System.out.println("Use vnc file");
		else
			new vnc(args[0]);
	}
}