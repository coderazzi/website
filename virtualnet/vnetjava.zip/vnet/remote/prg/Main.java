package vnet.remote.prg;

import java.awt.Dimension;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;

import java.rmi.*;

import vnet.*;
import vnet.display.*;
import vnet.remote.*;

/**
  * This class allows the creation of a virtualNe in a console way.
  * The options for the initialization are<p>
	* Arguments: [options] [VirtualNetName]<p>
	* Options:<p>
	* -noecho : not display initialization information<p>
	* -help : shows this window<p>
	* -console : display all the VirtualNet events<p>
	* -gconsole : display all the VirtualNet events in a window<p>
	* -csize=w,h : size of the Console Window<p>
	* -binds : display the servers binded to the VirtualNet<p>
	* -bsize=w,h: size of the BindServers window<p>
	* -graphcircle : display the VirtualNet as a round graph<p>
	* -graphnet : display the VirtualNet as a net graph<p>
	* -gsize=w,h : size of the Graph Windows<p>
	* -gupdate=n : timems to update the graphs<p>
	* -gremain=m : number of times needed to change the state<p>
	* -delay=n : timems of delay in each node and link<p>
	* -initfile=file : file to read the initialization. If the file is not
	* given, and there is not given the -init option, it will try to open 
	* the file name.net, being name the name of the virtualNet.
	* -init=cad : initializacion string.<p>
  * @author LuisM Pena
  * @version 0.2, august-1997
  */

public class Main
{
	
	public static void main(String args[])
	{
		
//////////////////////////////////////////////////////////
//	INITIALIZATION
//////////////////////////////////////////////////////////

		String serverName=null;
		boolean bNoEcho=false;
		boolean bConsole=false;
		boolean bGConsole=false;
		boolean bBinds=false;
		boolean bGraphCircle=false;
		boolean bGraphNet=false;
		boolean bUpdate=false;
		boolean bGSize=false;
		boolean bBSize=false;
		boolean bCSize=false;
		boolean bDelay=false;
		boolean bRemain=false;
		String init=null;
		String initFileName=null;
		int SyntaxError=-1;
		long update=0;
		Dimension gsize=new Dimension(200,200);
		Dimension csize=new Dimension(200,300);
		Dimension bsize=new Dimension(200,300);
		long delay=0;
		int remain=0;

//////////////////////////////////////////////////////////
//	ARGUMENT CHECKING
//////////////////////////////////////////////////////////

		for (int i=0;SyntaxError==-1 && i<args.length;i++)
			if (args[i].compareTo("-noecho")==0)
				if (bNoEcho || (serverName!=null))
					SyntaxError=i;
				else
					bNoEcho=true;
			else if (args[i].compareTo("-console")==0)
				if (bConsole|| (serverName!=null))
					SyntaxError=i;
				else
					bConsole=true;
			else if (args[i].compareTo("-gconsole")==0)
				if (bGConsole|| (serverName!=null))
					SyntaxError=i;
				else
					bGConsole=true;
			else if (args[i].compareTo("-binds")==0)
				if (bBinds|| (serverName!=null))
					SyntaxError=i;
				else
					bBinds=true;
			else if (args[i].compareTo("-graphcircle")==0)
				if (bGraphCircle|| (serverName!=null))
					SyntaxError=i;
				else
					bGraphCircle=true;
			else if (args[i].compareTo("-graphnet")==0)
				if (bGraphNet|| (serverName!=null))
					SyntaxError=i;
				else
					bGraphNet=true;
			else if (args[i].startsWith("-gupdate="))
				if (bUpdate|| (serverName!=null))
					SyntaxError=i;
				else
				{
					update=conv(args[i].substring(9));
					bUpdate=true;
				}
			else if (args[i].startsWith("-gsize="))
				if (bGSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					gsize=getDimension(args[i].substring(7));
					bGSize=true;
				}
			else if (args[i].startsWith("-csize="))
				if (bCSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					csize=getDimension(args[i].substring(7));
					bCSize=true;
				}
			else if (args[i].startsWith("-bsize="))
				if (bBSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					bsize=getDimension(args[i].substring(7));
					bBSize=true;
				}
			else if (args[i].startsWith("-delay="))
				if (bDelay|| (serverName!=null))
					SyntaxError=i;
				else
				{
					delay=conv(args[i].substring(7));
					bDelay=true;
				}
			else if (args[i].startsWith("-gremain="))
				if (bRemain|| (serverName!=null))
					SyntaxError=i;
				else
				{
					remain=(int) conv(args[i].substring(9));
					bRemain=true;
				}
			else if (args[i].startsWith("-init="))
				if ((init!=null) || (initFileName!=null) || (serverName!=null))
					SyntaxError=i;
				else
					init=args[i].substring(6);
			else if (args[i].startsWith("-initfile="))
				if ((init!=null) || (initFileName!=null) || (serverName!=null))
					SyntaxError=i;
				else
					initFileName=args[i].substring(10);
			else if (args[i].charAt(0)=='-')
					SyntaxError=i;
			else if (serverName==null)
				serverName=new String(args[i]);
			else
				SyntaxError=i-1;
		if (SyntaxError!=-1)
			syntax(args[SyntaxError]);
		else

//////////////////////////////////////////////////////////
//	VIRTUALNET CREATION
//////////////////////////////////////////////////////////

			try
			{
				if (!bNoEcho)
					System.out.println("Remote VirtualNet");
				if (serverName==null)
					serverName=new String("VirtualNet");
				if (init==null)
				{
					if (initFileName==null)
						initFileName=new String(serverName+".net");
					if (!bNoEcho)
						System.out.println("Loading "+initFileName);
					BufferedReader input=new BufferedReader(new InputStreamReader(new FileInputStream(initFileName)));
					String line=input.readLine();
					StringBuffer temp=new StringBuffer();
					while(line!=null)
					{
						temp.append(line);
						line=input.readLine();
					}
					input.close();
					init=temp.toString();
					if (!bNoEcho)
						System.out.println(initFileName+" loaded");
				}
				VirtualNet net=null;
				if (bDelay)
				{
					if (!bNoEcho)
						System.out.println("-->Initializing VirtualNet with delay "+delay);
					net=new VirtualNet(serverName,delay);
				}
				else
				{
					if (!bNoEcho)
						System.out.println("-->Initializing VirtualNet");
					net=new VirtualNet(serverName);
				}
				
				/////////////////////////////////////////////////////
				// CONSOLE
				/////////////////////////////////////////////////////
				
				if (bConsole)
				{
					if (!bNoEcho)
						System.out.println("-->Initializing console");
					new ConsoleNet(net);
				}
				
				
				/////////////////////////////////////////////////////
				// CONSOLE GRAPH
				/////////////////////////////////////////////////////
				
				if (bGConsole)
				{
					if (!bNoEcho)
						System.out.println("-->Initializing graphic console");
					new ConsoleNetFrame(net,"Console on "+serverName,csize);
				}
				
				/////////////////////////////////////////////////////
				// BIND GRAPH
				/////////////////////////////////////////////////////
				
				if (bBinds)
				{
					if (!bNoEcho)
						System.out.println("-->Initializing binded Server window");
					new ListBindsFrame(new ListBindsNet(net),"List of servers binded to "+serverName,bsize);
				}
				
				/////////////////////////////////////////////////////
				// GRAPHCIRCLE
				/////////////////////////////////////////////////////
				
				if (bGraphCircle)
				{
					GraphNet gnet=null;
					if (bRemain)
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graphnet circle with remain of "+remain);
						gnet=new GraphNet(net, new GraphGeometryCircle(),remain);
					}
					else
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graphnet circle");
						gnet=new GraphNet(net, new GraphGeometryCircle());
					}
					if (bUpdate)
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graph frame with updating of "+update);
						new GraphNetFrame(gnet,serverName,gsize,update);
					}
					else
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graph frame");
						new GraphNetFrame(gnet,serverName,gsize);
					}
				}
				
				/////////////////////////////////////////////////////
				// GRAPHNET
				/////////////////////////////////////////////////////
				
				if (bGraphNet)
				{
					GraphNet gnetc=null;
					if (bRemain)
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graphnet net with remain of "+remain);
						gnetc=new GraphNet(net, new GraphGeometryNet(),remain);
					}
					else
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graphnet net");
						gnetc=new GraphNet(net, new GraphGeometryNet());
					}
					if (bUpdate)
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graph frame with updating of "+update);
						new GraphNetFrame(gnetc,serverName,gsize,update);
					}
					else
					{
						if (!bNoEcho)
							System.out.println("-->Initializing graph frame");
						new GraphNetFrame(gnetc,serverName,gsize);
					}
				}
				if (!bNoEcho)
					System.out.println("-->Building virtual net with the init string");
				new BuildNetLayout(init,net);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
	}
	
	static void syntax(String s)
	{
		System.out.println("Main for VirtualNet "+VersionInfo.getInfo()+" (c)LuisM Pena.");
		System.out.println();
		System.out.println("Arguments: [options] [VirtualNetName]");
		System.out.println("Options:");
		System.out.println("          -noecho      : not display initialization information");
		System.out.println("          -help        : shows this window");
		System.out.println();
		System.out.println("          -console     : display all the VirtualNet events");
		System.out.println("          -gconsole    : display all the VirtualNet events in a window");
		System.out.println("          -csize=w,h   : size of the Console Window");
		System.out.println();
		System.out.println("          -binds       : display the servers binded to the VirtualNet");
		System.out.println("          -bsize=w,h   : size of the BindServers window");
		System.out.println();
		System.out.println("          -graphcircle : display the VirtualNet as a round graph");
		System.out.println("          -graphnet    : display the VirtualNet as a net graph");
		System.out.println("          -gsize=w,h   : size of the Graph Windows");
		System.out.println("          -gupdate=n   : time(ms) to update the graphs");
		System.out.println("          -gremain=m   : number of times needed to change the state");
		System.out.println();
		System.out.println("          -delay=n     : time(ms) of delay in each node and link");
		System.out.println();
		System.out.println("          -init=cad    : initializacion string.");
		System.out.println("          -initfile=file : file to read the initialization. By default, the file is name.net");
		if (s.compareTo("-help")!=0)
		{
			System.out.println();
			System.out.println("Wrong argument: "+s);
		}
	}

	static Dimension getDimension(String args)
	{
		int h=0,w=0;
		try
		{
			int n=args.indexOf(',');
			if (n==-1)
				throw new Exception();
			String init=args.substring(0,n);
			String end=args.substring(n+1);
			w=Integer.valueOf(init).intValue();
			h=Integer.valueOf(end).intValue();
		}
		catch(Exception ex)
		{
			System.out.println(args+" doesn't represent a valid size");
			System.exit(0);
		}
		return new Dimension(h,w);
	}
	
	static long conv(String args)
	{
		long ret=0;
		try
		{
			ret=Long.valueOf(args).longValue();
			if (ret<=0)
				throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println(args+" doesn't represent a valid number");
			System.exit(0);
		}
		return ret;
	}
		
}