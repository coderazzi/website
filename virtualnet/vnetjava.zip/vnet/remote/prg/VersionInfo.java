package vnet.remote.prg;

/**
  * This class allows  to store information about the vnet: Author, version, etc.
  * @author LuisM Pena
  * @version 0.2, august-1997
  */

public class VersionInfo
{
	public static String getInfo()
	{
		return "v0.21, August-1997";
	}
}