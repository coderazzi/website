package vnet.remote.prg;

import java.awt.Dimension;
import java.awt.Frame;

import java.util.Enumeration;
import java.util.Vector;

import vnet.ListBindsNet;
import vnet.VNException;
import vnet.display.ConsoleNetFrame;
import vnet.display.GraphGeometry;
import vnet.display.GraphNet;
import vnet.display.GraphNetFrame;
import vnet.display.ListBindsFrame;
import vnet.remote.VirtualNet;

class GraphVNItem
{
	GraphVNItem(VirtualNet net)
	{
		virtualNet=net;
	}
	
	public void destroy() throws VNException
	{
		Enumeration enFrames=frames.elements();
		while(enFrames.hasMoreElements())
		{
			Frame frame=(Frame) enFrames.nextElement();
			frame.dispose();
		}
		frames.removeAllElements();
		if (netList!=null)
			netList.destroy();
		virtualNet.destroy();
	}
	
	public void createConsole(Dimension size)
	{
		frames.addElement(new ConsoleNetFrame(virtualNet,virtualNet.getName(),size));
	}
	
	public void createBindedServersWindow(Dimension size)
	{
		if (netList==null)
			netList=new ListBindsNet(virtualNet);
		frames.addElement(new ListBindsFrame(netList,virtualNet.getName(),size));
	}
	
	public void createGraph(GraphGeometry geometry, Dimension size, int remain, long update)
	{
		frames.addElement(new GraphNetFrame(new GraphNet(virtualNet,geometry,remain),virtualNet.getName(),size, update));
	}

	public VirtualNet virtualNet;
	Vector frames=new Vector(2,2);
	ListBindsNet netList=null;
}