package vnet.remote.prg;

import java.awt.*;
import java.awt.event.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;

import java.rmi.Naming;

import java.util.Enumeration;
import java.util.Hashtable;

import vnet.BuildNetLayout;
import vnet.ListBindsNet;

import vnet.display.ConsoleNetFrame;
import vnet.display.ListBindsFrame;
import vnet.display.GraphGeometryCircle;
import vnet.display.GraphGeometryNet;
import vnet.display.GraphNet;
import vnet.display.GraphNetFrame;

import vnet.remote.VirtualNet;

/**
  * This class allows the creation of a virtualNe in a graphical way.
  * @author LuisM Pena
  * @version 0.2, august-1997
  */

public class GraphMain extends Frame
{
/**
  * @param bStart true if the VirtualNet has to be created inmediately
  * @param serverName the name for the VirtualNet
  * @param netDelay default delay for the VirtualNet
  * @param dConsole size for the Console Windows
  * @param dBind size for the List Binded Servers Windows
  * @param dGraph  size for the graph Windows
  * @param graphUpdate time (ms) to do the updating on the graph Windows
  * @param graphRemain in the graph Windows, number of times the state remain unchanged
  * @param init initialization chain
  * @param initFile file initialization chain
  * @param initConsole true to lunch inmediately a console window
  * @param initBinds true to lunch inmediately a List Binded Servers window
  * @param initCircleGraph true to lunch inmediately a circle graph window
  * @param initNetGraph true to lunch inmediately a net graph window
  * @param szError non null if it has to be shown an error string
  */
	public GraphMain(boolean bStart, String serverName, long netDelay,
											Dimension dConsole, Dimension dBind, Dimension dGraph,
											long graphUpdate, int graphRemain, String init, String initFile,
											boolean initConsole, boolean initBinds, 
											boolean initCircleGraph, boolean initNetGraph,
											String szError)
	{
		NewServerName=new String(serverName);
		delay=netDelay;
		csize=new Dimension(dConsole);
		bsize=new Dimension(dBind);
		gsize=new Dimension(dGraph);
		update=graphUpdate;
		remain=graphRemain;
		
		//Frame initialization/////////////////////////////////////
		setLayout(new BorderLayout());
		MenuBar bar=new MenuBar();
		setMenuBar(bar);
		Menu virtualNet=new Menu("VirtualNet");
		bar.add(virtualNet);
		start=new MenuItem ("New ...");
		worknet=new MenuItem ("Set work VirtualNet ...");
		close=new MenuItem ("Close");
		setdelay=new MenuItem("Set Delay to all the nets...");
		MenuItem exit=new MenuItem("Exit");
		virtualNet.add(start);
		virtualNet.add(worknet);
		virtualNet.add(close);
		virtualNet.add("-");
		virtualNet.add(setdelay);
		virtualNet.add("-");
		virtualNet.add(exit);
		Menu view=new Menu("View");
		bar.add(view);
		console=new MenuItem ("Console",new MenuShortcut(KeyEvent.VK_F5));
		binded=new MenuItem ("Binded servers",new MenuShortcut(KeyEvent.VK_F6));
		gcircle=new MenuItem ("Graph circle",new MenuShortcut(KeyEvent.VK_F7));
		gnet=new MenuItem ("Graph net",new MenuShortcut(KeyEvent.VK_F8));
		options=new MenuItem ("Options ...");
		view.add(console);
		view.add(binded);
		view.add(gcircle);
		view.add(gnet);
		view.add("-");
		view.add(options);
		Menu mnet=new Menu("Net");
		bar.add(mnet);
		file=new MenuItem ("Read file",new MenuShortcut(KeyEvent.VK_F9));
		cad=new MenuItem ("String Input",new MenuShortcut(KeyEvent.VK_F10));
		mnet.add(file);
		mnet.add(cad);
		Menu help=new Menu("Help");
		bar.add(help);
		MenuItem arguments=new MenuItem ("Arguments");
		help.add(arguments);
		help.add("-");
		MenuItem about=new MenuItem ("About");
		help.add(about);
		ta=new TextArea();
		ta.setEditable(false);
		ta.setFont(new Font("Monospaced",Font.PLAIN,12));
		add("Center",ta);
		changeTitle();
		checkMenuState();
		pack();
		setSize(300,150);
		show();

		//Frame Listener initialization/////////////////////////////////////
		addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){quit();}});
		start.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){start();}});
		worknet.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){selectnet();}});
		close.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){close();}});
		setdelay.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setdelay();}});
		options.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){options();}});
		exit.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){quit();}});
		console.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){console();}});
		binded.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){bindedServers();}});
		gcircle.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){circle();}});
		gnet.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){net();}});
		cad.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){readCad(true);}});
		file.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){readCad(false);}});
		about.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){about();}});
		arguments.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){arguments();}});

		//Last initializations/////////////////////////////////////
		if (szError!=null)
			printInfo("Error in arguments : "+ szError);
		else if (bStart)
		{
			if (initVirtualNet(NewServerName))
			{
				if (initConsole)
					console();
				if (initBinds)
					bindedServers();
				if (initCircleGraph)
					circle();				
				if (initNetGraph)
					net();				
				if (initFile!=null)
				{
					fileName=initFile;
					buildNetWithFile(initFile);
				}
				if (init!=null)
					buildNet(init);
			}
		}
		else
			about();
	}
	
	String getServerName()
	{
		String ret=null;
		if (net!=null)
			ret=net.virtualNet.getName();
		return ret;
	}
	
	void changeTitle()
	{
		StringBuffer title=new StringBuffer("VirtualNet control panel");
		String name=getServerName();
		if (name!=null)
			title.append(" - " + name);
		setTitle(title.toString());
	}
	
	void about()
	{
		printInfo("GraphMain for VirtualNet "+VersionInfo.getInfo()+" (c)LuisM Pena.");
	}
	
	void arguments()
	{
		printInfo("Arguments: [options] [VirtualNetName]\n" +
							"Options:\n" +
							"          -start       : initialize the virtual net\n"+
							"          -delay=n     : time(ms) of delay in each node and link\n"+
							"          -bsize=w,h   : size of the BindServers window\n"+
							"          -csize=w,h   : size of the Console Window\n"+
							"          -gsize=w,h   : size of the Graph Windows\n"+
							"          -gupdate=n   : time(ms) to update the graphs\n"+
							"          -gremain=m   : number of times needed to change the state\n\n"+
							"If start is present, next options are also available\n"+
							"          -init=cad    : initialize the VirtualNet with the cad info\n"+
							"          -gconsole    : display all the VirtualNet events in a window\n"+
							"          -binds       : display the servers binded to the VirtualNet\n"+
							"          -graphcircle : display the VirtualNet as a round graph\n"+
							"          -graphnet    : display the VirtualNet as a net graph\n");
	}
	
	void setModal(boolean bSet)
	{
		if (bSet)
		{
			start.setEnabled(false);
			worknet.setEnabled(false);
			close.setEnabled(false);
			setdelay.setEnabled(false);
			console.setEnabled(false);
			binded.setEnabled(false);
			gcircle.setEnabled(false);
			gnet.setEnabled(false);
			options.setEnabled(false);
			file.setEnabled(false);
			cad.setEnabled(false);
		}
		else
		{
			start.setEnabled(true);
			options.setEnabled(true);
			checkMenuState();
		}
	}
	
	void checkMenuState()
	{
		boolean bGeneral=net!=null;
		close.setEnabled(bGeneral);
		setdelay.setEnabled(bGeneral);
		console.setEnabled(bGeneral);
		binded.setEnabled(bGeneral);
		gcircle.setEnabled(bGeneral);
		gnet.setEnabled(bGeneral);
		file.setEnabled(bGeneral);
		cad.setEnabled(bGeneral);
		int n=existingNets.size();
		worknet.setEnabled(n>1 || ((n==1) && net==null));
	}
	
	void buildNet(String init)
	{
		printInfo("Building the Net");
		try {new BuildNetLayout(init,net.virtualNet);printInfo("Net builded");}
		catch(Exception ex){printInfo(ex.toString());}
	}
	
	void buildNetWithFile(String fileName)
	{
		printInfo("Opening the file");
		try
		{
			BufferedReader input=new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			String line=input.readLine();
			BuildNetLayout builder=new BuildNetLayout(net.virtualNet);
			while(line!=null)
			{
				builder.buildNet(line);
				line=input.readLine();
			}
			input.close();
			printInfo("File readed");
		}
		catch(Exception ex)
		{
			printInfo(ex.toString());
		}
	}
	
	boolean initVirtualNet(String serverName)
	{
		boolean ret=false;
		if (existingNets.containsKey(serverName))
			printInfo("It exists already another VirtualNet with this name");
		else
			try
			{
				VirtualNet newNet=new VirtualNet(serverName,delay);
				net=new GraphVNItem(newNet);
				existingNets.put(serverName,net);
				printInfo(serverName + " started");
				ret=true;
			}
			catch(Exception ex)
			{
				printInfo(ex.toString());
			}
		checkMenuState();
		changeTitle();
		return ret;
	}
	
	void close()
	{
		String serverName=getServerName();
		printInfo("Closing "+serverName);
		existingNets.remove(serverName);
		try
		{
			net.destroy();
			printInfo(serverName + " has been closed.");
		}
		catch(Exception ex)
		{
			printInfo(ex.toString());
		}
		net=null;
		changeTitle();
		checkMenuState();
	}
	
////////////////////////////////////////////////////////////////////////
/////////	MEMBERS
////////////////////////////////////////////////////////////////////////

	TextArea ta;
	MenuItem start, worknet, close, console, setdelay, binded, gcircle, gnet, options;
	MenuItem file,cad;
	//window new... and setDelay
	String NewServerName;
	long delay;
	boolean bAutoLoadNetFile=true;
	//windows read file and input
	String fileName=new String("");
	String inputStream=new String("");
	GraphVNItem net=null;
	Hashtable existingNets=new Hashtable(1);
	Dimension gsize;
	Dimension csize;
	Dimension bsize;
	long update;
	int remain;

////////////////////////////////////////////////////////////////////////
/////////	COMMON and SIMPLE FUNCTIONS
////////////////////////////////////////////////////////////////////////

	void console()
	{
		String serverName=getServerName();
		printInfo("Creating new console for "+serverName);
		net.createConsole(csize);
		printInfo("A new console for "+serverName+" has been created");
	}
	
	void bindedServers()
	{
		String serverName=getServerName();
		printInfo("Creating new window with binded Servers for "+serverName);
		net.createBindedServersWindow(bsize);
		printInfo("A new window with binded Servers to "+serverName+" has been created");
	}
	
	void circle()
	{
		String serverName=getServerName();
		printInfo("Creating new circle graph for "+serverName);
		net.createGraph(new GraphGeometryCircle(),gsize,remain,update);
		printInfo("A new circle graph for "+serverName+" has been created");
	}
	
	void net()
	{
		String serverName=getServerName();
		printInfo("Creating new net graph for "+serverName);
		net.createGraph(new GraphGeometryNet(),gsize,remain,update);
		printInfo("A new net graph for "+serverName+" has been created");
	}
	
	void printInfo(String s)
	{
		ta.setText(s);
	}
	
	int getInt(TextField tf) throws Exception
	{
		int ret;
		try
		{
			ret=Integer.valueOf(tf.getText()).intValue();
			if (ret<=0)
				throw new Exception();
		}
		catch (Exception ex)
		{
			tf.getToolkit().beep();
			tf.requestFocus();
			throw ex;
		}
		return ret;
	}
	
	long getLong(TextField tf, boolean bAllowZero) throws Exception
	{
		long ret;
		try
		{
			ret=Long.valueOf(tf.getText()).longValue();
			if ((ret<0) || (!bAllowZero && ret==0))
				throw new Exception();
		}
		catch (Exception ex)
		{
			tf.getToolkit().beep();
			tf.requestFocus();
			throw ex;
		}
		return ret;
	}
	
////////////////////////////////////////////////////////////////////////
/////////	START	
////////////////////////////////////////////////////////////////////////
	
	void start()
	{
		class Start extends Frame
		{
			Start()
			{
				GridBagLayout gbag=new GridBagLayout();
				GridBagConstraints c=new GridBagConstraints();
				setLayout(gbag);
				c.weightx=0;
				c.weighty=1;
				c.insets=new Insets(5,5,5,5);
				Label l=new Label("Virtual Net Name:");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=1;
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				tfName=new TextField(NewServerName,20);
				gbag.setConstraints(tfName,c);
				add(tfName);		
				c.gridx=0;
				c.gridy=1;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				l=new Label("Normal delay:");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=1;
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				tfDelay=new TextField(String.valueOf(delay),6);
				gbag.setConstraints(tfDelay,c);
				add(tfDelay);		
				c.gridy=2;
				bAutoLoad=new Checkbox("Autoload net file",bAutoLoadNetFile);
				gbag.setConstraints(bAutoLoad,c);
				add(bAutoLoad);		
				c.gridx=0;
				c.gridy=3;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				Button bOk=new Button("Ok");
				gbag.setConstraints(bOk,c);
				add(bOk);		
				c.gridx=1;
				Button bCancel=new Button("Cancel");
				gbag.setConstraints(bCancel,c);
				add(bCancel);
				setTitle("Start");
				setResizable(false);
				show();
				pack();
				addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){setModal(false);dispose();}});
				bOk.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){common();}});
				bCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setModal(false);dispose();}});
			}

			void common()
			{
				try
				{
					delay=getLong(tfDelay,true);
					NewServerName=new String(tfName.getText());
					bAutoLoadNetFile=bAutoLoad.getState();
					dispose();
					setModal(false);
					if (initVirtualNet(NewServerName))
						if (bAutoLoadNetFile)
							buildNetWithFile(NewServerName+".net");
				}
				catch(Exception ex)
				{
					getToolkit().beep();
					tfDelay.requestFocus();
				}
			}
			
			TextField tfName, tfDelay;
			Checkbox bAutoLoad;
		}	

		setModal(true);
		new Start();
	}
	
////////////////////////////////////////////////////////////////////////
/////////	SET DELAY
////////////////////////////////////////////////////////////////////////
	
	void setdelay()
	{
		class SetDelay extends Frame
		{
			SetDelay()
			{
				GridBagLayout gbag=new GridBagLayout();
				GridBagConstraints c=new GridBagConstraints();
				setLayout(gbag);
				c.weightx=0;
				c.weighty=1;
				c.insets=new Insets(5,5,5,5);
				Label l=new Label("New delay:");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=1;
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				tfDelay=new TextField("",6);
				gbag.setConstraints(tfDelay,c);
				add(tfDelay);		
				c.gridx=0;
				c.gridy=1;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				Button bOk=new Button("Ok");
				gbag.setConstraints(bOk,c);
				add(bOk);		
				c.gridx=1;
				Button bCancel=new Button("Cancel");
				gbag.setConstraints(bCancel,c);
				add(bCancel);
				setTitle("SetDelay");
				setResizable(false);
				show();
				pack();
				addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){setModal(false);dispose();}});
				bOk.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){common();}});
				bCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setModal(false);dispose();}});
			}
			void common()
			{
				try
				{
					long ndelay=getLong(tfDelay,true);
					setModal(false);
					dispose();
					setdelay.setEnabled(true);
					printInfo("Setting new delay ...");
					try
					{
						net.virtualNet.setNetDelay(ndelay);
						printInfo(getServerName() + " has an additional delay of "+ndelay+" ms.");
					}
					catch(Exception ex)
					{
						printInfo(ex.toString());
					}
				}
				catch(Exception ex)
				{
				}
			}
			
			TextField tfDelay;
		}	
		
		setModal(true);
		new SetDelay();
	}
	
////////////////////////////////////////////////////////////////////////
/////////	READCAD
////////////////////////////////////////////////////////////////////////
	
	void readCad(boolean bCad)
	{
		class ReadCad extends Frame
		{
			ReadCad(boolean bCad)
			{
				bFile=!bCad;
				GridBagLayout gbag=new GridBagLayout();
				GridBagConstraints c=new GridBagConstraints();
				setLayout(gbag);
				c.weightx=0;
				c.weighty=1;
				c.insets=new Insets(5,5,5,5);
				Label l=null;
				if (bCad)
					l=new Label("Building string :");
				else
					l=new Label("File name :");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=1;
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				tfCad=new TextField("",65);
				gbag.setConstraints(tfCad,c);
				add(tfCad);		
				c.gridx=0;
				c.gridy=1;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				Button bOk=new Button("Ok");
				gbag.setConstraints(bOk,c);
				add(bOk);		
				c.gridx=1;
				Button bCancel=new Button("Cancel");
				gbag.setConstraints(bCancel,c);
				add(bCancel);
				setTitle(getServerName());
				setResizable(false);
				if (bCad)
					tfCad.setText(inputStream);
				else
					tfCad.setText(fileName);
				show();
				pack();
				addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){setModal(false);dispose();}});
				bOk.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){common();}});
				bCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setModal(false);dispose();}});
			}
			void common()
			{
				setModal(false);
				dispose();
				if(!bFile)
					buildNet(inputStream=tfCad.getText());
				else
					buildNetWithFile(fileName=tfCad.getText());
			}
			
			TextField tfCad;
			boolean bFile;
		}	
		
		setModal(true);
		new ReadCad(bCad);
	}
	
	
////////////////////////////////////////////////////////////////////////
/////////	SelectNet
////////////////////////////////////////////////////////////////////////
	
	void selectnet()
	{
		class SelectNet extends Frame
		{
			public SelectNet ()
			{
				GridBagLayout gbag=new GridBagLayout();
				GridBagConstraints c=new GridBagConstraints();
				setLayout(gbag);
				listServers= new List();
				c.gridx=0;
				c.gridy=0;
				c.fill=GridBagConstraints.BOTH;
				c.gridwidth=2;
				c.weightx=1;
				c.weighty=1;
				c.insets=new Insets(5,5,5,5);
				gbag.setConstraints(listServers,c);
				add(listServers);		
				Button bOk=new Button("Ok");
				c.gridy=1;
				c.fill=GridBagConstraints.NONE;
				c.gridwidth=1;
				c.weighty=0;
				gbag.setConstraints(bOk,c);
				add(bOk);
				Button bCancel=new Button("Cancel");
				c.gridx=1;
				gbag.setConstraints(bCancel,c);
				add(bCancel);
				setTitle("Select work VirtualNet");
				pack();
				show();
				
				Enumeration nets=existingNets.elements();
				while(nets.hasMoreElements())
					listServers.add(((GraphVNItem)nets.nextElement()).virtualNet.getName());

				addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){setModal(false);dispose();}});
				bOk.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){common();}});
				bCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setModal(false);dispose();}});
			}
			
			void common()
			{
				String item=listServers.getSelectedItem();
				dispose();
				if (item==null)
				{
					printInfo("No work virtual net is selected");
					net=null;
				}
				else
				{
					net=(GraphVNItem) existingNets.get(item);
					printInfo(net.virtualNet.getName() + " is the current VirtualNet");
				}
				setModal(false);
				changeTitle();
			}
			
			List listServers;
		}
		setModal(true);
		new SelectNet();
	}
	
	
////////////////////////////////////////////////////////////////////////
/////////	Exit
////////////////////////////////////////////////////////////////////////
	
	void quit()
	{
		try
		{
			printInfo("Destroying net(s)");
			Enumeration nets=existingNets.elements();
			while(nets.hasMoreElements())
				((GraphVNItem)nets.nextElement()).destroy();
			System.exit(0);
		}
		catch(Exception ex)
		{
			class Quit extends Frame
			{
				public Quit (String error)
				{
					setLayout(new FlowLayout());
					add(new Label(error));		
					setTitle("Error on exit");
					show();
					pack();
					addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
				}
			}	
			dispose();
			new Quit(ex.toString());
		}
	}
	
	
////////////////////////////////////////////////////////////////////////
/////////	OPTIONS
////////////////////////////////////////////////////////////////////////
	
	void options()
	{
		class Options extends Frame
		{
			Options()
			{
				GridBagLayout gbag=new GridBagLayout();
				GridBagConstraints c=new GridBagConstraints();
				setLayout(gbag);
				
				c.insets=new Insets(5,5,5,5);
				c.weightx=0;
				c.weighty=1;
				c.gridx=1;
				Label l=new Label("Widht");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=2;
				l=new Label("Height");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=3;
				l=new Label("Update (ms)");
				gbag.setConstraints(l,c);
				add(l);		
				c.gridx=4;
				l=new Label("State remain");
				gbag.setConstraints(l,c);
				add(l);		
				
				c.gridx=0;
				c.gridy=1;
				l=new Label("Graphs");
				gbag.setConstraints(l,c);
				add(l);		
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				c.gridx=1;
				graphw=new TextField(String.valueOf(gsize.width),4);
				gbag.setConstraints(graphw,c);
				add(graphw);		
				c.gridx=2;
				graphh=new TextField(String.valueOf(gsize.height),4);
				gbag.setConstraints(graphh,c);
				add(graphh);	
				c.gridx=3;
				graphu=new TextField(String.valueOf(update),6);
				gbag.setConstraints(graphu,c);
				add(graphu);		
				c.gridx=4;
				graphr=new TextField(String.valueOf(remain),6);
				gbag.setConstraints(graphr,c);
				add(graphr);		
				
				c.gridx=0;
				c.gridy=2;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				l=new Label("Console");
				gbag.setConstraints(l,c);
				add(l);		
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				c.gridx=1;
				consolew=new TextField(String.valueOf(csize.width),4);
				gbag.setConstraints(consolew,c);
				add(consolew);		
				c.gridx=2;
				consoleh=new TextField(String.valueOf(csize.height),4);
				gbag.setConstraints(consoleh,c);
				add(consoleh);	
				
				c.gridx=0;
				c.gridy=3;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				l=new Label("Binded servers");
				gbag.setConstraints(l,c);
				add(l);		
				c.fill=GridBagConstraints.HORIZONTAL;
				c.weightx=1;
				c.gridx=1;
				bindsw=new TextField(String.valueOf(bsize.width),4);
				gbag.setConstraints(bindsw,c);
				add(bindsw);		
				c.gridx=2;
				bindsh=new TextField(String.valueOf(bsize.height),4);
				gbag.setConstraints(bindsh,c);
				add(bindsh);	
				
				
				c.gridx=3;
				c.gridy=4;
				c.fill=GridBagConstraints.NONE;
				c.weightx=0;
				Button bOk=new Button("Ok");
				gbag.setConstraints(bOk,c);
				add(bOk);		
				c.gridx=4;
				Button bCancel=new Button("Cancel");
				gbag.setConstraints(bCancel,c);
				add(bCancel);
				setTitle("View options");
				setResizable(false);
				show();
				pack();
				addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){setModal(false);dispose();}});
				bOk.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){common();}});
				bCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){setModal(false);dispose();}});
			}

			void common()
			{
				try
				{
					int fgraphw=getInt(graphw);
					int fgraphh=getInt(graphh);
					long fgraphu=getLong(graphu,false);
					int fgraphr=getInt(graphr);
					int fconsolew=getInt(consolew);
					int fconsoleh=getInt(consoleh);
					int fbindsw=getInt(bindsw);
					int fbindsh=getInt(bindsh);
					gsize=new Dimension(fgraphw,fgraphh);
					csize=new Dimension(fconsolew,fconsoleh);
					bsize=new Dimension(fbindsw,fbindsh);
					update=fgraphu;
					remain=fgraphr;
					dispose();
					setModal(false);
					printInfo("Options changed");
				}
				catch(Exception ex)
				{
				}
			}
			
			TextField graphw, graphh, graphu, graphr;
			TextField consolew, consoleh;
			TextField bindsw, bindsh;
		}	
		
		setModal(true);
		new Options();
	}



//////////////////////////////////////////////////////////
//	*********** STATIC FUNCTIONS *****************
//////////////////////////////////////////////////////////

	static Dimension getDimension(String args)
	{
		int h=0,w=0;
		try
		{
			int n=args.indexOf(',');
			if (n==-1)
				throw new Exception();
			String init=args.substring(0,n);
			String end=args.substring(n+1);
			w=Integer.valueOf(init).intValue();
			h=Integer.valueOf(end).intValue();
		}
		catch(Exception ex)
		{
			System.out.println(args+" doesn't represent a valid size");
			System.exit(0);
		}
		return new Dimension(w,h);
	}
	
	static long conv(String args)
	{
		long ret=0;
		try
		{
			ret=Long.valueOf(args).longValue();
			if (ret<=0)
				throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println(args+" doesn't represent a valid number");
			System.exit(0);
		}
		return ret;
	}
	
//////////////////////////////////////////////////////////
//	***********MAIN*****************
//////////////////////////////////////////////////////////
/**
  * The options for the initialization are:<p>
	* Arguments: [options] [VirtualNetName]<p>
	* Options:<p>
	* -start : initializa directly a VirtualNet<p>
	* -delay=n : timems of delay in each node and link<p>
	* -bsize=w,h: size of the BindServers window<p>
	* -csize=w,h : size of the Console Window<p>
	* -gsize=w,h : size of the Graph Windows<p>
	* -gupdate=n : timems to update the graphs<p>
	* -gremain=m : number of times needed to change the state<p>
	* if start is present, next options are also available:<p>
	* -init=cad : initializacion string. <p>
	* -initfile=name : initialization file. By default, is vnetName.net
	* -gconsole : display all the VirtualNet events in a window<p>
	* -binds : display the servers binded to the VirtualNet<p>
	* -graphcircle : display the VirtualNet as a round graph<p>
	* -graphnet : display the VirtualNet as a net graph<p>
	*/
	public static void main(String args[])
	{
//////////////////////////////////////////////////////////
//	INITIALIZATION
//////////////////////////////////////////////////////////

		String serverName=null;
		String init=null;
		String initFile=null;
		boolean bGConsole=false;
		boolean bBinds=false;
		boolean bGraphCircle=false;
		boolean bGraphNet=false;
		boolean bUpdate=false;
		boolean bGSize=false;
		boolean bBSize=false;
		boolean bCSize=false;
		boolean bDelay=false;
		boolean bRemain=false;
		boolean bStart=false;
		int SyntaxError=-1;
		long update=100;
		Dimension gsize=new Dimension(200,200);
		Dimension csize=new Dimension(200,300);
		Dimension bsize=new Dimension(200,300);
		long delay=0;
		int remain=5;

//////////////////////////////////////////////////////////
//	ARGUMENT CHECKING
//////////////////////////////////////////////////////////

		for (int i=0;i<args.length;i++)
			if (args[i].compareTo("-start")==0)
				if (bStart|| (serverName!=null))
					SyntaxError=i;
				else
					bStart=true;
			else if (args[i].compareTo("-gconsole")==0)
				if (bGConsole|| (serverName!=null))
					SyntaxError=i;
				else
					bGConsole=true;
			else if (args[i].compareTo("-binds")==0)
				if (bBinds|| (serverName!=null))
					SyntaxError=i;
				else
					bBinds=true;
			else if (args[i].compareTo("-graphcircle")==0)
				if (bGraphCircle|| (serverName!=null))
					SyntaxError=i;
				else
					bGraphCircle=true;
			else if (args[i].compareTo("-graphnet")==0)
				if (bGraphNet|| (serverName!=null))
					SyntaxError=i;
				else
					bGraphNet=true;
			else if (args[i].startsWith("-gupdate="))
				if (bUpdate|| (serverName!=null))
					SyntaxError=i;
				else
				{
					update=conv(args[i].substring(9));
					bUpdate=true;
				}
			else if (args[i].startsWith("-gsize="))
				if (bGSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					gsize=getDimension(args[i].substring(7));
					bGSize=true;
				}
			else if (args[i].startsWith("-csize="))
				if (bCSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					csize=getDimension(args[i].substring(7));
					bCSize=true;
				}
			else if (args[i].startsWith("-bsize="))
				if (bBSize|| (serverName!=null))
					SyntaxError=i;
				else
				{
					bsize=getDimension(args[i].substring(7));
					bBSize=true;
				}
			else if (args[i].startsWith("-delay="))
				if (bDelay|| (serverName!=null))
					SyntaxError=i;
				else
				{
					delay=conv(args[i].substring(7));
					bDelay=true;
				}
			else if (args[i].startsWith("-gremain="))
				if (bRemain|| (serverName!=null))
					SyntaxError=i;
				else
				{
					remain=(int) conv(args[i].substring(9));
					bRemain=true;
				}
			else if (args[i].startsWith("-init="))
				if ((init!=null) || (initFile!=null) || (serverName!=null))
					SyntaxError=i;
				else
					init=args[i].substring(6);
			else if (args[i].startsWith("-initfile="))
				if ((init!=null) || (initFile!=null) || (serverName!=null))
					SyntaxError=i;
				else
					initFile=args[i].substring(10);
			else if (args[i].charAt(0)=='-')
					SyntaxError=i;
			else if (serverName==null)
				serverName=new String(args[i]);
			else
				SyntaxError=i-1;

//////////////////////////////////////////////////////////
//	VIRTUALNET CREATION
//////////////////////////////////////////////////////////

		if (serverName==null)
			serverName=new String("VirtualNet");
		String error=null;
		if (SyntaxError!=-1)
		{
			error=args[SyntaxError];
			bStart=false;
		}
		else if (!bStart && (bGConsole || bBinds || bGraphCircle || bGraphNet || (init!=null) || (initFile!=null)))
			error=new String("Use -start");
		new GraphMain(bStart,serverName,delay,csize,bsize,gsize,update,remain,init,
			initFile, bGConsole, bBinds, bGraphCircle, bGraphNet,error);
	}
}


		