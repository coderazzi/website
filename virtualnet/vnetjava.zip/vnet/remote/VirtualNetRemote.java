package vnet.remote;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import vnet.NodeId;
import vnet.LinkId;
import vnet.VNException;
import vnet.BuildNetLayout;

/**
  * Class implementation for a virtual net remote.
  * The purpose of this class is to allow a remote interaction with
  * the virtual net.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNet
  * @see vnet.NetLayout
  */
public class VirtualNetRemote extends UnicastRemoteObject implements VirtualNetIntf
{
/**
  * @param net The virtual Net connected to this class
  * @exception RemoteException mandatory for remote objects
  */
	public VirtualNetRemote(VirtualNet net) throws RemoteException
	{
		Net=net;
	}
/**
  * Inserts a new node in the net, with the default delay
  * @param id the Node identity
  * @exception VNException if the NodeId has already been added to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addNode(NodeId id) throws VNException, RemoteException
	{
		Net.addNode(id);
	}
/**
  * Inserts a new node in the net, with the specified delay
  * @param id the Node identity
  * @param delay the expected delay
  * @exception VNException if the NodeId has already been added to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addNode(NodeId id, long Delay) throws VNException, RemoteException
	{
		Net.addNode(id,Delay);
	}
/**
  * Removes a Node out of the net.
  * @param id the Node identity
  * @exception VNException if the NodeId doesn't allow to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void removeNode(NodeId id) throws VNException, RemoteException
	{
		Net.removeNode(id);
	}
/**
  * Inserts a new link in the net, with the default delay
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addLink(LinkId id, NodeId idA, NodeId idB) throws VNException, RemoteException
	{
		Net.addLink(id,idA,idB);
	}
/**
  * Inserts a new link in the net, with the default delay
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @param delay the expected delay
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addLink(LinkId id, NodeId idA, NodeId idB, long Delay) throws VNException, RemoteException
	{
		Net.addLink(id,idA,idB,Delay);
	}
/**
  * Removes a Link out of the net.
  * @param id the Link identity
  * @exception VNException if the LinkId doesn't allow to the net or the destroy()
  * NetLink method fails
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void removeLink(LinkId id) throws VNException, RemoteException
	{
		Net.removeLink(id);
	}
/**
  * Building of the net from a string
  * @param buildString the input stream
  * @exception VNException if the string format is not valid, or any of the 
  * operations produced raises the exception.
  * @see vnet.BuildNetLayout
  */
	public void build(String buildString) throws VNException, RemoteException
	{
		new BuildNetLayout(buildString,Net);
	}
/**
	* Sets an additional delay that applies to every message operation between nodes
	* (and links)
  * @param delay the delay in milliseconds
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void setNetDelay(long Delay) throws RemoteException
	{
		Net.setNetDelay(Delay);
	}
/**
  * Gives the name of the net
  * @return the name of the virtual net
  * @exception RemoteException mandatory for remote objects
  */
	public String getName() throws RemoteException
	{
		return Net.getName();
	}
	private VirtualNet Net;
	
}