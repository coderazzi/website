package vnet.remote;

import java.rmi.Naming;
import java.rmi.RemoteException;

import java.util.Observable;
import java.util.Observer;

import vnet.NetLayout;
import vnet.NetNode;
import vnet.NodeId;
import vnet.VNException;
import vnet.NodeDestroyedEvent;

/**
  * Class that represents a NetLayout remote
  * This remote Netlayout creates a Host for each node in the net, in order
  * to allow to clients and servers to get attached to the nodes (the machines).
  * Because several VirtualNets can bur running at the same time, they are
  * differenciated by a name, that must ve valid (only letters).
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see NetLayout
  */
public class VirtualNet extends NetLayout
{
/**
  * @param name The name of the virtualNet
  * @exception VNRemoteException if the name is not valid
  */
	public VirtualNet(String name) throws VNRemoteException
	{
		Constructor(name);
	}
/**
  * @param name The name of the virtualNet
  * @param delay the delay that will apply by default to the nodes and links
  * @exception VNRemoteException if the name is not valid
  */
	public VirtualNet(String name, long delay) throws VNRemoteException
	{
		super(delay);
		Constructor(name);
	}
/**
  * @param name The name of the virtualNet
  * @exception VNRemoteException if the name is not valid, or it is not possible
  * to create the binded VirtualNetRemote server
  */
	void Constructor(String name) throws VNRemoteException
	{
		VirtualNetName=name;
		if (!isValidVNName(name))
			throw new VNRemoteException(name);
		try{Naming.rebind(name,new VirtualNetRemote(this));}
		catch(Exception ex){throw new VNRemoteException(name,ex);}
	}
/**
  * This is the destructor: detsroy the NetLayout and unbinds the VirtualNetRemote
  * @exception VNException if any NetNode.destroy() fails
  * @see vnet.NetLayout#destroy
  */
	public void destroy() throws VNException
	{
		super.destroy();
		try{Naming.unbind(getName());}
		catch(Exception ex){throw new VNRemoteException(getName(),ex);}
	}

/**
  * Gives the name of the net
  * @return the name of the virtual net
  */
	public String getName()
	{
		return VirtualNetName;
	}
/**
  * Inserts a new node in the net, with the specified delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new node inside
  * @param id the Node identity
  * @exception VNException if the NodeId has already been added to the net
  * @exception VNRemoteException if the new Node can not be binded in the rmiregistry
  */
	public void addNode(NodeId id, long Delay) throws VNException, VNRemoteException
	{
		super.addNode(id,Delay);
		String nodeName=null;
		try
		{
			nodeName=createName(id);
			Naming.rebind(nodeName, new HostImpl(this,getNode(id)));
		}
		catch(Exception ex)
		{
			try{removeNode(id);} catch(Exception exx){}
			throw new VNRemoteException(nodeName, ex);
		}
	}

	/**
		* Observable method
	  */
	public void update(Observable o, Object arg)
	{
		super.update(o,arg);
		if (arg instanceof NodeDestroyedEvent)
			try{Naming.unbind(createName(((NetNode)o).getId()));}
			catch(Exception ex){}
	} 
	
	String createName(NodeId id)
	{
		return VirtualNetName+"/Host"+id.toString();
	}
	
	/**
	  * Checks if a name is a valid virtual name.
	  * A valid VirtualNet Name is those with only letters, and having 
	  * at least one letter
	  * @param name the name to check
	  * @return true if the name is valid
	  */
	static public boolean isValidVNName(String name)
	{
		int n=name.length();
		boolean ret=n>0;
		for(int i=0;ret && i<n;i++)
		{
			char c=name.charAt(i);
			ret=(c>='A' && c<='Z') || (c>='a' && c<='z');
		}
		return ret;
	}
	
	private String VirtualNetName;
}