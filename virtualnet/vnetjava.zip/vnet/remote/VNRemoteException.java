package vnet.remote;

import java.rmi.AlreadyBoundException;
import vnet.VNException;

/**
  * Class to represent general exceptions involving the remote Virtual Net
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see NetLayout
  */
public class VNRemoteException extends VNException
{
/**
  * @param name the inavlid name for the virtual net
  */
	public VNRemoteException(String name)
	{
		super(name+" is not a valid VirtualNet name");
	}
	
/**
  * @param name the name of the server that was been binded
  * @param exception the exception produced in the binding
  */
	public VNRemoteException(String name, Exception exception)
	{
		super("It is not possible to bind "+name+".\nReason: "+exception.toString());
	}
}