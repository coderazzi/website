package vnet.remote;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;

/**
  * Interface to represent a machine -a node- in the remote VirtualNet
  * Every server or client, to interact with any other in the virtual net
  * has to be previously 'attached'to a host. Once attached, it is able to
  * do the general operations bind, rebind, unbind and lookup<p>
  * All the operations needs to have a serverName. This string may be the
  * plain server Name, or a qualified one, specifying the host for the server;
  * in this last case, the format for the string will be :<p>
  * /name of the virtualNet/HostN/name of the server.<p>
  * For example, to look for the server "Server" in the Host B of the virtualNet
  * called "ExampleNet", the serverName would be: /ExampleNet/HostB/Server
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public interface Host extends Remote
{
/**
  * Binds a server with the serverName specified
  * @param serverName the name for the server (can be qualified)
  * @param server the Remote server
  * @exception AlreadyBoundException if there is already another server
  * binded with the same serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#bind
  */
	public void bind(String serverName, Remote server) throws AlreadyBoundException, MalformedURLException, UnknownHostException, RemoteException;
/**
  * Rebinds a server with the serverName specified
  * If it would exist other server with the same serverName, it is first unbinded
  * @param serverName the name for the server (can be qualified)
  * @param server the Remote server
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#rebind
  */
	public void rebind(String serverName, Remote server) throws MalformedURLException, UnknownHostException, RemoteException;
/**
  * Unbinds the server that is binded with the serverName specified
  * @param serverName the name for the server
  * @param serverName the name for the server
  * @exception NotBoundException if it is not bound such a serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#unbind
  */
	public void unbind(String serverName) throws NotBoundException, MalformedURLException, UnknownHostException, RemoteException;
/**
  * Looks the net for a server binded with the serverName specified.
  * @param serverName the name of the server 
  * @return a reference to the server (an stub of it)
  * @exception NotBoundException if it is not bound such a serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#lookup
  */	
	public Remote lookup(String serverName) throws NotBoundException, MalformedURLException, UnknownHostException, RemoteException;
/**
  * Gives the complete list of servers binded.
  * The parameter name is here for compatibility with the RMI signature
	* @param name it is not used
	* @return the list of servers, in the format /VirtualNet/HostX/Name
  * @exception MalformedURLException not possible, only for compatibility with the RMI signature
  * @exception UnknownHostException not possible, only for compatibility with the RMI signature
  * @exception RemoteException mandatory in any remote object
	*/
	public String[] list(String name) throws MalformedURLException, UnknownHostException, RemoteException;
}