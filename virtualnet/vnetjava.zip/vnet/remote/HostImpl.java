package vnet.remote;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.StubNotFoundException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.server.UnicastRemoteObject;

import java.util.Enumeration;
import java.util.Vector;

import vnet.NetNode;
import vnet.NodeId;
import vnet.VirtualPath;
import vnet.VNException;
import vnet.CommException;

/**
  * Implementation Class to represent a machine -a node- in the remote VirtualNet
  * Every server or client, to interact with any other in the virtual net
  * has to be previously 'attached'to a host. Once attached, it is able to
  * do the general operations bind, rebind, unbind and lookup<p>
  * All the operations needs to have a serverName. This string may be the
  * plain server Name, or a qualified one, specifying the host for the server;
  * in this last case, the string starts with '/', and the expected format is:<p>
  * /name of the virtualNet/HostN/name of the server.<p>
  * For example, to look for the server "Server" in the Host B of the virtualNet
  * called "ExampleNet", the serverName would be: /ExampleNet/HostB/Server
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class HostImpl extends UnicastRemoteObject implements Host
{
/**
  * Create a host for the specified Node
  * @param virtualNetName The name of the virtualNet holding this HostImpl
  * @param NetNode The node represented by this host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode
  */
	public HostImpl(VirtualNet vNet, NetNode node) throws RemoteException
	{
		this.vNet=vNet;
		Node=node;
	}
/**
  * Binds a server with the serverName specified
  * @param serverName the name for the server (can be qualified)
  * @param server the Remote server
  * @exception AlreadyBoundException if there is already another server
  * binded with the same serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#bind
  */
	public void bind(String serverName, Remote server) throws AlreadyBoundException, MalformedURLException, UnknownHostException, RemoteException
	{
		RemoteServerName remoteServerName=new RemoteServerName(serverName,vNet.getName());
		NodeId node=remoteServerName.getNode();
		String finalName=remoteServerName.getServerName();
		try
		{
			if (node==null)
				Node.bind(finalName,server,Node);
			else
				try
				{
					NetNode hostNode=vNet.getNode(node);
					hostNode.bind(finalName,server,Node);
				}
				catch(VNException e)
				{
					throw new UnknownHostException(serverName);
				}
		}
		catch(vnet.AlreadyBoundException ex)
		{
			throw new AlreadyBoundException(ex.toString());
		}
		catch(CommException ex)
		{
			throw new UnknownHostException(serverName);
		}
	}
/**
  * Rebinds a server with the serverName specified
  * If it would exist other server with the same serverName, it is first unbinded
  * @param serverName the name for the server (can be qualified)
  * @param server the Remote server
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#rebind
  */
	public void rebind(String serverName, Remote server) throws MalformedURLException, UnknownHostException, RemoteException
	{
		RemoteServerName remoteServerName=new RemoteServerName(serverName,vNet.getName());
		NodeId node=remoteServerName.getNode();
		String finalName=remoteServerName.getServerName();
		try
		{
			if (node==null)
				Node.rebind(finalName,server,Node);
			else
				try
				{
					NetNode hostNode=vNet.getNode(node);
					hostNode.rebind(finalName,server,Node);
				}
				catch(VNException e)
				{
					throw new UnknownHostException(serverName);
				}
		}
		catch(CommException ex)
		{
			throw new UnknownHostException(serverName);
		}
	}
/**
  * Unbinds the server that is binded with the serverName specified
  * @param serverName the name for the server
  * @param serverName the name for the server
  * @exception NotBoundException if it is not bound such a serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#unbind
  */
	public void unbind(String serverName) throws NotBoundException, MalformedURLException, UnknownHostException, RemoteException
	{
		RemoteServerName remoteServerName=new RemoteServerName(serverName,vNet.getName());
		NodeId node=remoteServerName.getNode();
		String finalName=remoteServerName.getServerName();
		try
		{
			if (node==null)
				Node.unbind(finalName);
			else
				try
				{
					NetNode hostNode=vNet.getNode(node);
					hostNode.unbind(finalName);
				}
				catch(VNException e)
				{
					throw new UnknownHostException(serverName);
				}
		}
		catch(vnet.NotBoundException ex)
		{
			throw new NotBoundException(ex.toString());
		}
	}
/**
  * Looks the net for a server binded with the serverName specified.
  * @param serverName the name of the server 
  * @return a reference to the server (an stub of it)
  * @exception NotBoundException if it is not bound such a serverName
  * @exception MalformedURLException if the name is not valid
  * @exception UnknownHostException if the serverName is qualified, and
  * refers to a node that is not accesible from the cuurent Host
  * @exception RemoteException mandatory in any remote object
  * @see vnet.NetNode#lookup
  */	
	public Remote lookup(String serverName) throws NotBoundException, MalformedURLException, UnknownHostException, RemoteException
	{
		VirtualPath path=null;
		RemoteServerName remoteServerName=new RemoteServerName(serverName,vNet.getName());
		NodeId node=remoteServerName.getNode();
		String finalName=remoteServerName.getServerName();
		if (node==null)
			path=Node.lookup(finalName);
		else
			try
			{
				NetNode hostNode=vNet.getNode(node);
				path=Node.lookup(finalName,hostNode);
			}
			catch(VNException e)
			{
				throw new UnknownHostException(serverName);
			}
			catch(CommException ex)
			{
				throw new UnknownHostException(serverName);
			}
		if (path==null)
			throw new NotBoundException(serverName);
		return createRClass(path);
	}
	
	RemoteClass createRClass(VirtualPath path) throws StubNotFoundException
	{
		String className=path.server.object.getClass().getName()+"_VNet";
		Object o=null;
		try
		{
			o=Class.forName(className).newInstance();
		}
		catch(Exception e)
		{
			throw new StubNotFoundException(className,e);
		}
		if (!(o instanceof RemoteClass))
			throw new StubNotFoundException(className);
		RemoteClass ret=(RemoteClass)o;
		ret.setVirtualPath(path);
		return ret;
	}

/**
  * Gives the complete list of servers binded.
  * The parameter name is here for compatibility with the RMI signature
  * FOR PROBLEMS WITH THE RMIC COMPILER (INVOLVING THE STRING[] RETURN), THIS
  * FUNCTION IS NOT READY.
	* @param name it is not used
	* @return the list of servers, in the format /VirtualNet/HostX/Name
  * @exception MalformedURLException not possible, only for compatibility with the RMI signature
  * @exception UnknownHostException not possible, only for compatibility with the RMI signature
  * @exception RemoteException mandatory in any remote object
	*/
	public String [] list(String name) throws MalformedURLException, UnknownHostException, RemoteException
	{
		Vector temp=new Vector(4,4);
		Enumeration nodes=vNet.getNodes();
		while(nodes.hasMoreElements())
		{
			NetNode node=(NetNode) nodes.nextElement();
			Enumeration servers=node.getServers();
			while(servers.hasMoreElements())
				temp.addElement(new String("/"+vNet.getName()+"/Host"+node.getId().toString()+"/"+(String)servers.nextElement()));
		}
		int n=temp.size();
		String ret[]=new String[n];
		Enumeration list=temp.elements();
		while(n-->0)
			ret[n]=new String((String)list.nextElement());
		temp.removeAllElements();
		return ret;
	}
	
	private NetNode Node;
	private VirtualNet vNet;
	
}