package vnet.remote;

import java.rmi.Remote;
import java.rmi.RemoteException;

import vnet.VNException;
import vnet.LinkId;
import vnet.NodeId;

/**
  * Interface for a virtual net remote.
  * The virtual net doesn't need to implement this interface, it is only
  * for the VirtualNetRemote, whose purpose is to allow a remote interaction with
  * the virtual net.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNet
  * @see vnet.NetLayout
  */
public interface VirtualNetIntf extends Remote
{
/**
  * Inserts a new node in the net, with the default delay
  * @param id the Node identity
  * @exception VNException if the NodeId has already been added to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addNode(NodeId id) throws VNException, RemoteException;
/**
  * Inserts a new node in the net, with the specified delay
  * @param id the Node identity
  * @param delay the expected delay
  * @exception VNException if the NodeId has already been added to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addNode(NodeId id, long Delay) throws VNException, RemoteException;
/**
  * Removes a Node out of the net.
  * @param id the Node identity
  * @exception VNException if the NodeId doesn't allow to the net
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void removeNode(NodeId id) throws VNException, RemoteException;
/**
  * Inserts a new link in the net, with the default delay
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addLink(LinkId id, NodeId idA, NodeId idB) throws VNException, RemoteException;
/**
  * Inserts a new link in the net, with the default delay
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @param delay the expected delay
  * @exception VNException if the LinkId has already been added to the net, or if
  * the nodes don't allow to the net.
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void addLink(LinkId id, NodeId idA, NodeId idB, long Delay) throws VNException, RemoteException;
/**
  * Removes a Link out of the net.
  * @param id the Link identity
  * @exception VNException if the LinkId doesn't allow to the net or the destroy()
  * NetLink method fails
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void removeLink(LinkId id) throws VNException, RemoteException;
/**
  * Building of the net from a string
  * @param buildString the input stream
  * @exception VNException if the string format is not valid, or any of the 
  * operations produced raises the exception.
  * @see vnet.BuildNetLayout
  */
	public void build(String buildString) throws VNException, RemoteException;
/**
	* Sets an additional delay that applies to every message operation between nodes
	* (and links)
  * @param delay the delay in milliseconds
  * @exception RemoteException mandatory for remote objects
  * @see vnet.NetLayout
  */
	public void setNetDelay(long Delay) throws RemoteException;
/**
  * Gives the name of the net
  * @return the name of the virtual net
  * @exception RemoteException mandatory for remote objects
  */
	public String getName() throws RemoteException;
}