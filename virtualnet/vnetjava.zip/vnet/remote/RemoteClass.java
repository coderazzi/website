package vnet.remote;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

import vnet.VirtualPath;
import vnet.NetNode;
import vnet.CommException;

/**
	* Class that represents a server in the remote Virtual Net.
  * Every vnet stub remote server has to extend this class.
  * This is done automatically by the vnc compiler
  * This stub gives a function to the server: checkWay, that will
  * check if there is a way to the host node, and that the server
  * is still alive.
  * If the server is not really hosted in that node (it is only binded
  * to it), it also checks that the connection to the real host node is
  * still there.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class RemoteClass extends UnicastRemoteObject
{
	public RemoteClass() throws RemoteException
	{
	}
	public void setVirtualPath(VirtualPath path)
	{
		Path=path;
	}
	public final void checkWay() throws RemoteException
	{
		try
		{
			Path.nodeInitial.checkWay(Path.nodeFinal, Path.server);
		}
		catch(CommException ex)
		{
			throw new RemoteException("checkWay",ex);
		}
	}
	public VirtualPath Path;
}