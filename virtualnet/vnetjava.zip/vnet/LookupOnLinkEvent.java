package vnet;

/**
  * Event Class to notify the passing of a net message on an specific NetLink
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see LinkEvent
  * @see NetLink
  */
public class LookupOnLinkEvent extends LinkEvent
{
}