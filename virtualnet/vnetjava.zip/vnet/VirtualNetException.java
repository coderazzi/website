package vnet;

/**
  * Abstract parent class for all the VirtualNet exceptions
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
abstract public class VirtualNetException extends Exception
{
	public VirtualNetException(){}
/**
  * @param message the string used to initialize the Exception
  */
	public VirtualNetException(String message){super(message);}
}