package vnet;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import java.util.Hashtable;
import java.util.Vector;

/**
  * Class to manage the BindEvents on a net.
  * It stores all the nodes and servers in the net.
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class ListBindsNet implements Observer
{
/**
  * @param net The NetLayout to manage
  */
	public ListBindsNet(NetLayout net)
	{
		this.net=net;
		Enumeration enum=net.getNodes();
		while(enum.hasMoreElements())
			newNode((NetNode)enum.nextElement());
		net.addObserver(this);
	}
	
/**
  * Destructor, needed to clean up the observables
  */
	public synchronized void destroy()
	{
		net.deleteObserver(this);
		Enumeration enum=net.getNodes();
		while(enum.hasMoreElements())
			((NetNode)enum.nextElement()).deleteObserver(this);
		binds.clear();
	}
	
/**
  * Gets the Nodes in the network that have servers binded
  * @return the identities of the nodes with servers binded
  */
	public Enumeration getHostNodes()
	{
		return binds.keys();
	}
	
/**
  * Gets the name of the servers binded to an specific Node
  * @param node the identity of the node to study
  * @return an enumeration of the names of the servers binded
  */
	public Enumeration getServers(NodeId node)
	{
		Enumeration ret=null;
		Vector v=(Vector) binds.get(node);
		if (v!=null)
			ret=v.elements();
		return ret;
	}
	
	/**
		* Observable method
	  */
	public synchronized void update(Observable obs, Object o)
	{
		if (o instanceof VirtualNetEvent)
		{
			VirtualNetEvent vo=(VirtualNetEvent)o;
			if (vo.getObservable() instanceof NetNode)
				newNode((NetNode) vo.getObservable());
		}
		else if (o instanceof BindEvent)
		{
			BindEvent bindEvent=(BindEvent) o;
			NetNode node=(NetNode) obs;
			if (bindEvent.isBinded())
				newServer(node.getId(),bindEvent.getServerName());
			else
				removeServer(node.getId(),bindEvent.getServerName());
		}
	}

	void newNode(NetNode node)
	{
		Enumeration servers=node.getServers();
		while(servers.hasMoreElements())
			newServer(node.getId(),(String) servers.nextElement());
		node.addObserver(this);
	}
	
	void newServer(NodeId id, String nameServer)
	{
		if (!binds.containsKey(id))
			binds.put(id,new Vector(4,4));
		Vector v=(Vector) binds.get(id);
		v.addElement(nameServer);
	}
	
	void removeServer(NodeId id, String nameServer)
	{
		Vector v=(Vector) binds.get(id);
		v.removeElement(nameServer);
		if (v.isEmpty())
			binds.remove(id);
	}
	
	private Hashtable binds=new Hashtable(4);
	private NetLayout net;
	
}