package vnet;

/**
  * Class exception for exceptions on bind operations
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNetException
  */
public class AlreadyBoundException extends BindException
{
/**
  * This constructor is used when the name of the server being binded
  * is already busy (there is another server binded with this name)
  * @param server the name of the server being binded
  */
	public AlreadyBoundException (String server)
	{
		super("NameServer ["+server+"] already binded");
	}
}