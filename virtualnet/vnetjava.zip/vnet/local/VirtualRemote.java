package vnet.local;

/**
  * Interface that any server in the local virtualNet has to implement
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public interface VirtualRemote
{
}