package vnet.local;

import vnet.CommException;
import vnet.VirtualPath;

/**
	* Class that represents a server in the local Virtual Net.
  * Every vnet stub local server has to extend this class.
  * This is done automatically by the vnc compiler
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class VirtualRemoteClass implements VirtualRemote
{
	public void setVirtualPath(VirtualPath path)
	{
		Path=path;
	}
	public final void checkWay() throws CommException
	{
		Path.nodeInitial.checkWay(Path.nodeFinal, Path.server);
	}
	public VirtualPath Path;
}