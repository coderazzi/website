package vnet.local;

import vnet.VirtualNetException;

/**
  * Class to deal with exception on the VirtualNet stub class.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see VirtualNetException
  */
public class ClassVNetException extends VirtualNetException
{
/**
  * This constructor is used when an exception is produced while loading
  * the VNet Stub class.
  * @param className the name of the class to load
  * @param exception the exception produced during the load
  */
	public ClassVNetException(String className, Exception exception)
	{
		super("Error loading " + className + " : " + exception);
	}
/**
  * This constructor is used when the VNet Stub class is not valid
  * @param className the name of the stub class loaded
  */
	public ClassVNetException(String className)
	{
		super("Error in class "+className+" : it has to extend VirtualRemoteClass");}
}