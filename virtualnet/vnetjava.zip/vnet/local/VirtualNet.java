package vnet.local;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

import vnet.*;

/**
  * Local implementation of a virtual net, that is, a net layout with abilities
  * to bind, unbind or lookup servers.
  * Local means that this virtual net can only be used inside the same
  * java machines it is executed
  * The servers written for the local virtual net have the next requirements: <p>
  * - They have to implement an interface that extends the VirtualRemote interface 
  * (it is an empty interface)<p>
  * - Each of the methods of the interface has to throw the VirtualNetException
  * - They need to have a Virtual Net stub, that is generated automatically by the
  * local vnet compiler: vnc.
  * @author LuisM Pena
  * @version 0.1, august-1997
  * @see vnet.remote.VirtualNet
  * @see vnc
  */
public class VirtualNet extends NetLayout 
{
	
/**
  * Default constructor
  */
	public VirtualNet()
	{
	}
	
/**
  * This constructor allows to specify the default delay that will apply for the
  * nodes and links in the net.
  * @param delay the delay that will apply by default to the nodes and links
  */
	public VirtualNet(long delay)
	{
		super(delay);
	}
	
/**
  * Binds a server with the serverName specified to the node with identity id;
  * @param host the identity of the node on which the server is to be binded
  * @param hostToBind the identity of the node on which the server is to be binded
  * @param serverName the name for the server
  * @param server the VirtualRemote server
  * @exception VNException if the NodeId doesn't exist in the net
  * @exception AlreadyBoundException if the node specified has already another server
  * binded with the same serverName
  * @see NetNode#bind
  */
	public synchronized void bind(NodeId host, String serverName, VirtualRemote server) throws VNException, AlreadyBoundException
	{
		NetNode node=getNode(host);
		try{node.bind(serverName,server,node);}catch(CommException c){}
		//this exception is not going to be produced
	}
	
/**
  * Binds a server with the serverName specified to the node with identity id, no
  * matter if the servername is already in use
  * @param host the identity of the node on which the server is hosted
  * @param hostToBind the identity of the node on which the server is to be binded
  * @param serverName the name for the server
  * @param server the VirtualRemote server
  * @exception VNException if the NodeId doesn't exist in the net
  * @see NetNode#rebind
  */
	public synchronized void rebind(NodeId host, String serverName, VirtualRemote server) throws VNException
	{
		NetNode node=getNode(host);
		try{node.rebind(serverName,server,node);}catch(CommException c){}
		//this exception is not going to be produced

	}
	
/**
  * Unbinds the server that is binded with the serverName specified from the node given
  * @param host the identity of the node on which the server is hosted
  * @param serverName the name for the server
  * @exception VNException if the NodeId doesn't exist in the net
  * @exception NotBoundException if the node specified doesn't have any server binded
  * with the same serverName given
  * @see NetNode#unbind
  */
	public synchronized void unbind(NodeId host, String serverName) throws VNException, NotBoundException
	{
		getNode(host).unbind(serverName);
	}
	
/**
  * Looks the net for a server binded with the serverName specified.
  * The search starts from a node (the node where the client is suposed to be hosted).
  * @param host the identity of the node on which the server is binded
  * @param serverName the name of the server 
  * @return a reference to the server (an stub of it), or null if it is not found
  * @exception VNException if the NodeId doesn't exist in the net
  * @exception ClassVNetException if the stub class of the server can not be loaded
  * @see NetNode#lookup
  */	
	public synchronized VirtualRemote lookup(NodeId host, String serverName) throws VNException, ClassVNetException
	{
		VirtualRemoteClass ret=null;
		VirtualPath path=getNode(host).lookup(serverName);
		if (path!=null)
			ret=createVRClass(path);
		return ret;
	}
	
/**
  * Looks the net for a server binded with the serverName specified in the node given.
  * The search starts from a node (the node where the client is suposed to be hosted).
  * @param host the identity of the node on which the server is binded
  * @param serverName the name of the server 
  * @param hostServer the node where the server is binded
  * @return a reference to the server (an stub of it), or null if it is not found
  * @exception VNException if the NodeId id or host don't exist in the net.
  * @exception CommException if the host can not be accesed from the id
  * @exception ClassVNetException if the stub class of the server can not be loaded
  * @see NetNode#lookup
  */	
	public synchronized VirtualRemote lookup(NodeId host, String serverName, NodeId hostServer) throws VNException, ClassVNetException, CommException
	{
		VirtualRemoteClass ret=null;
		VirtualPath path=getNode(host).lookup(serverName,getNode(hostServer));
		if (path!=null)
			ret=createVRClass(path);
		return ret;
	}
	
	VirtualRemoteClass createVRClass(VirtualPath path) throws ClassVNetException
	{
		String className=path.server.object.getClass().getName()+"_VNet";
		Object o=null;
		try
		{
			o=Class.forName(className).newInstance();
		}
		catch(Exception e)
		{
			throw new ClassVNetException(className,e);
		}
		if (!(o instanceof VirtualRemoteClass))
			throw new ClassVNetException(className);
		VirtualRemoteClass ret=(VirtualRemoteClass)o;
		ret.setVirtualPath(path);
		return ret;
	}

}