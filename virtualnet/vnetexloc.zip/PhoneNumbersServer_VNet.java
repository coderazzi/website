public class PhoneNumbersServer_VNet extends vnet.local.VirtualRemoteClass implements PhoneNumbersIntf
{
	public java.lang.String getNumber() throws vnet.VirtualNetException
	{
		checkWay();
		return ((PhoneNumbersIntf) Path.server.object).getNumber();
	}
}
