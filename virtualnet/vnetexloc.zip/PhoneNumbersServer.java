import vnet.*;
import vnet.local.*;

public class PhoneNumbersServer implements PhoneNumbersIntf
{
  public PhoneNumbersServer(String number)
  {
    Number=number;
  }
  public String getNumber() throws vnet.VirtualNetException
  {
	  return Number;
  }
  String Number;
}