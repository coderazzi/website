import java.awt.Dimension;

import vnet.*;
import vnet.display.*;
import vnet.local.*;

public class PhoneProof
{
	public static void main(String args[])
	{
		try
		{
			System.out.println("Initializing");
			VirtualNet net=new VirtualNet();
			new BuildNetLayout("+a+e+i+m+o+a1e+e2i+e3m+i4m+m5o",net);
			new GraphNetFrame(new GraphNet(net,new GraphGeometryCircle()), "Local test", new Dimension(200,200));
			new ConsoleNetFrame(net,"Local Test",new Dimension(300,300));
			new ListBindsFrame(new ListBindsNet(net),"Binded servers",new Dimension(200,300));
			
			System.out.println("Creating servers");
			PhoneNumbersIntf pLmp=new PhoneNumbersServer("763.27.17");
			PhoneNumbersIntf pSLmp=new PhoneNumbersServer("859.82.94");
			
			System.out.println("Creating nodes");
			NodeId a=new NodeId("a");
			NodeId d=new NodeId("m");
			NodeId e=new NodeId("o");
			
			System.out.println("Binding servers");
			net.bind(d,"LMP phone",pLmp);
			net.bind(e,"LMP phone",pSLmp);
			
			PhoneNumbersIntf found;
			String lookFor;
			
			lookFor=new String("LMP phone12");
			System.out.println("Looking for "+lookFor);
			found=(PhoneNumbersIntf)net.lookup(a,lookFor);
			if (found==null)
				System.out.println("Not found");

			lookFor=new String("LMP phone");
			System.out.println("Looking for "+lookFor);
			found=(PhoneNumbersIntf)net.lookup(a,lookFor);
			if (found==null)
				System.out.println("Not found");
			else
				System.out.println("telephone: "+found.getNumber());

			System.out.println("Looking for "+lookFor+" in node specific");
			found=(PhoneNumbersIntf)net.lookup(a,lookFor,e);
			if (found==null)
				System.out.println("Not found");
			else
				System.out.println("telephone: "+found.getNumber());

			System.out.println("Removing the link 5");
			new BuildNetLayout("-5",net);
			System.out.println("Looking for "+lookFor+" in node specific");
			found=(PhoneNumbersIntf)net.lookup(a,lookFor,e);
			if (found==null)
				System.out.println("Not found");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}