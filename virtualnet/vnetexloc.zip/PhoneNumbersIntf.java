import vnet.*;
import vnet.local.*;

public interface PhoneNumbersIntf extends VirtualRemote
{
  public String getNumber() throws VirtualNetException;
}