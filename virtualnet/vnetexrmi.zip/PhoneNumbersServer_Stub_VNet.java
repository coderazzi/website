public class PhoneNumbersServer_Stub_VNet extends vnet.remote.RemoteClass implements PhoneNumbersIntf
{
	public PhoneNumbersServer_Stub_VNet() throws java.rmi.RemoteException{}
	public java.lang.String getNumber() throws java.rmi.RemoteException
	{
		checkWay();
		return ((PhoneNumbersIntf) Path.server.object).getNumber();
	}
}
