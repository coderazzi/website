import java.rmi.Naming;

import vnet.remote.Host;

public class InsertServers
{
	public static void main(String args[])
	{
		try
		{
			System.out.println("This test expects to have a virtualNet called TestA, with 4 nodes C,M,U,Y, with links between C-M, M-U, V-Y");
			System.out.println();
			System.out.println("Getting the hosts...");
			Host C=(Host) Naming.lookup("/TestA/HostC");
			Host M=(Host) Naming.lookup("/TestA/HostM");
			Host U=(Host) Naming.lookup("/TestA/HostU");
			Host Y=(Host) Naming.lookup("/TestA/HostY");
			System.out.println("Binding the servers");
			System.out.println("In M there is a server called LMP");
			M.bind("LMP",new PhoneNumbersServer("763271"));
			System.out.println("In Y there is the same server ,but with a different number");
			Y.bind("LMP",new PhoneNumbersServer("859829"));
			System.out.println("In C there is a server, hosted in U, called BELLMP (/TestA/HostC/BELLMP");
			U.bind("/TestA/HostC/BELLMP", new PhoneNumbersServer("213207"));
			System.out.println();
			System.out.println();
			System.out.println("Ready");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}