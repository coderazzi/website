public class PhoneNumbersServer extends java.rmi.server.UnicastRemoteObject implements PhoneNumbersIntf
{
	public PhoneNumbersServer(String number)  throws java.rmi.RemoteException
	{
		Number=number;
	}
	public String getNumber() throws java.rmi.RemoteException
	{
		return Number;
	}
	String Number;
}