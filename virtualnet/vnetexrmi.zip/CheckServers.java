import java.rmi.Naming;

import vnet.remote.Host;

public class CheckServers
{
	public static void main(String args[])
	{
		System.out.println("This test expects to have a virtualNet called TestA, with 4 nodes C,M,U,Y, with links between C-M, M-U, V-Y");
		if (args.length!=1)
			System.out.println("This test need an argument: The letter of the host from where the tests are done");
		else 
			try
			{
				System.out.println("Getting the host");
				Host host=(Host) Naming.lookup("/TestA/Host"+args[0]);
				PhoneNumbersIntf phone=null;
				System.out.println("getting LMP");
				phone=(PhoneNumbersIntf)host.lookup("LMP");
				System.out.println("phone: "+phone.getNumber());
				System.out.println("getting /TestA/HostY/LMP");
				phone=(PhoneNumbersIntf)host.lookup("/TestA/HostY/LMP");
				System.out.println("phone: "+phone.getNumber());
				System.out.println("getting /TestA/HostM/LMP");
				phone=(PhoneNumbersIntf)host.lookup("/TestA/HostM/LMP");
				System.out.println("phone: "+phone.getNumber());
				System.out.println("getting BELLMP");
				phone=(PhoneNumbersIntf)host.lookup("BELLMP");
				System.out.println("phone: "+phone.getNumber());
				System.out.println("getting /TestA/HostC/BELLMP");
				phone=(PhoneNumbersIntf)host.lookup("/TestA/HostC/BELLMP");
				System.out.println("phone: "+phone.getNumber());
				System.out.println("getting /TestA/HostU/BELLMP");
				phone=(PhoneNumbersIntf)host.lookup("/TestA/HostU/BELLMP");
				System.out.println("phone: "+phone.getNumber());
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
	}
}