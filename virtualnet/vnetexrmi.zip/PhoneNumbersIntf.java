public interface PhoneNumbersIntf extends java.rmi.Remote
{
	public String getNumber() throws java.rmi.RemoteException;
}