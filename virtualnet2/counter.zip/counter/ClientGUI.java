package counter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

interface ClientGUIListener
{
  void close();
  void getCounter();
};

class ClientGUI extends JFrame implements ActionListener
{
  JLabel counter;
  final ClientGUIListener listener;

  public ClientGUI (final ClientGUIListener listener)
  {
    super("Counter / Client");
    this.listener = listener;

    addWindowListener (new WindowAdapter()
                          {public void windowClosing(WindowEvent e) {listener.close();}}
                        );

    java.awt.Container contentPane=getContentPane();

    GridBagLayout gridbag = new GridBagLayout();
    contentPane.setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.NONE;

    JLabel label = new JLabel("Last counter value got:  ",SwingConstants.CENTER);
    c.weightx = 0.0;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 4;
    gridbag.setConstraints(label, c);
    contentPane.add(label);

    counter = new JLabel("Unknown",SwingConstants.CENTER);
    counter.setFont(new Font("Serif",Font.BOLD,18));
    counter.setBorder(BorderFactory.createLoweredBevelBorder());
    c.weightx = 0.0;
    c.gridx = 4;
    c.gridy = 0;
    c.gridwidth = 1;
    c.insets = new Insets(10,10,10,10);
    gridbag.setConstraints(counter, c);
    contentPane.add(counter);

    JPanel addPanel = new JPanel(new FlowLayout());
    JButton button = new JButton("Get new counter\'s value");
    button.setMnemonic('g');
    button.addActionListener( this );
    addPanel.add(button);

    c.weightx = 0.0;
    c.weighty = 1.0;
    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.NORTH;
    c.insets = new Insets(0,0,0,0);
    gridbag.setConstraints(addPanel, c);
    contentPane.add(addPanel);

    pack();
    setVisible (true);
  }

  public void setCounter(int value)
  {
    counter.setText(Integer.toString(value));
  }

  public void setError(String error)
  {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);
  }

  public void actionPerformed(java.awt.event.ActionEvent e)
  {
    listener.getCounter();
  }


}