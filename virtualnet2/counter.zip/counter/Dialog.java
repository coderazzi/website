package counter;

import java.awt.*;
import javax.swing.*;

public class Dialog extends JDialog
{
  public Dialog(String title, String message)
  {
//		super(title);
    JPanel pane = new JPanel();
    JLabel text = new JLabel (message);
    pane.setLayout(new BorderLayout());
    pane.add(text, BorderLayout.CENTER);
    //pack();
    //setVisible(true);
  }

  public static void main(String args[])
  {
    new Dialog ("title","message") . show();
  }
}

