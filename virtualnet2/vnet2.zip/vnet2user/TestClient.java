/**
  * File: TestClient.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2user;

import java.io.*;
import java.net.*;

/**
  * Class implementing each session with the VirtualNet
  **/
public class TestClient
{

  BufferedReader reader;
  byte node[];

  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/

  public TestClient(Socket client) throws IOException
  {
    reader = new BufferedReader(new InputStreamReader(System.in));
    run(client);
  }

  /*******************************************************************************/
  /**************************** RUN **********************************************/
  /*******************************************************************************/

  public void run(Socket client)  throws IOException
  {
    InputStream input=client.getInputStream();
    OutputStream output=client.getOutputStream();

    byte result[]=new byte[1];

    while(readNode())
    {
      output.write(node);
      if (input.read(result)==0)
      {
        System.out.println("\nRead 0 bytes");
        break;
      }
      else
      {
        boolean success=result[0]==0;
        if (success)
          System.out.println("Success");
        else
          System.out.println("No success");
      }
    }
  }

  /*******************************************************************************/
  /**************************** READ NODE ****************************************/
  /*******************************************************************************/

  boolean readNode()  throws IOException
  {
    System.out.print("Introduce node: ");
    String line = reader.readLine();
    if (line==null)
      return false;
    int len=line.length();
    if (len==0)
      return readNode();

    byte read[]=line.getBytes("UTF-8");
    int iLength=read.length;
    if (iLength>255)
    {
      System.out.println("Too long node!");
      return readNode();
    }
    node=new byte[1+iLength];
    node[0]=(byte) iLength;
    while(iLength-->0)
      node[iLength+1]=read[iLength];
    System.out.print("["+line+"]:");
    return true;
  }

/*******************************************************************************/
  /*******************************************************************************/
  /*******************************************************************************/

  public static void main(String args[])
  {
    if (args.length!=1)
      System.out.println("Specify the port to test as only argument");
    else
      try
      {
        new TestClient (new Socket(InetAddress.getLocalHost().getHostName(), Integer.parseInt(args[0])));
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
  }
}
