/**
  * File: InterceptorsUser.java
  * Content: Definition of the interface to be implemented by users of the
  *          Interceptor
  * Author: LuisM Pena
  * Date: 07th February 2001
  * Version: 0.10.01
  * Last change:
  *
  *
  **/

package vnet2user;

public interface InterceptorsUser
{
  /**
    * If error is set to true, the interceptor will not do any further
    * work, avoiding any communication!
    **/
  public void vnet2Message(String msg, boolean error);
}
