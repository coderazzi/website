/**
  * File: Interceptor.java
  * Content: Class handling the client and server interceptions.
  * Author: LuisM Pena
  * Date: 07th February 2001
  * Version: 0.10.01
  * Last change:
  *
  *
  **/

package vnet2user;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;

import org.omg.CORBA.LocalObject;
import org.omg.IOP.ServiceContext;

import org.omg.PortableInterceptor.ClientRequestInfo;
import org.omg.PortableInterceptor.ClientRequestInterceptor;
import org.omg.PortableInterceptor.ORBInitInfo;
import org.omg.PortableInterceptor.ORBInitializer;
import org.omg.PortableInterceptor.ServerRequestInfo;
import org.omg.PortableInterceptor.ServerRequestInterceptor;

public class Interceptor extends LocalObject
  implements ClientRequestInterceptor, ServerRequestInterceptor, ORBInitializer
{

  //*************************************************************************************//
  //**************************** SETUP **************************************************//
  //*************************************************************************************//

  /**
    * This method must be called with the properties that will be later
    * passed to the ORB.init method. It is therefore important to call
    * this method before starting the ORB!
    * This method is intended to make the use of virtualnet as transparent as
    * possible. It checks the args given to verify that the parameters are
    * included. If the virtualNetPort or the virtuaHostName or or the virtualNetName
    * the are specified, the setup considers that the virtualnet is going to be used.
    * In that case, arguments virtualNetPort and virtuaHostName are mandatory!
    * In case of errors, the user is informed directly. If the user is not specified
    * (null) the fatal errors are sent to the normal output and the system exited!
    * It is returned a string containing the original arguments without those used on
    * the virtualnet
    **/
  public static String [] setup(InterceptorsUser user, String args[], Properties props)
  {
    Interceptor.user = user;
    String ret[]=args;

    int virtualHostNameArg=-1;
    int virtualNetHostArg =-1;
    int virtualNetPortArg =-1;
    String argRepeated=null;

    int j,len = args.length;
    for (j=0;(argRepeated==null) && (j<len-1);j++)
      if (args[j].equalsIgnoreCase(VirtualHostNameParam))
        if (virtualHostNameArg==-1)
          virtualHostNameArg=j++;
        else
          argRepeated=VirtualHostNameParam;
      else if (args[j].equalsIgnoreCase(VirtualNetHostParam))
        if (virtualNetHostArg==-1)
          virtualNetHostArg=j++;
        else
          argRepeated=VirtualNetHostParam;
      else if (args[j].equalsIgnoreCase(VirtualNetPortParam))
        if (virtualNetPortArg==-1)
          virtualNetPortArg=j++;
        else
          argRepeated=VirtualNetPortParam;

    if (argRepeated!=null)
      staticInformUser(argRepeated + " param specified twice", true);
    else if (virtualHostNameArg==-1)
      staticInformUser("VirtualNet will not be used, not specified parameter " + VirtualHostNameParam, false);
    else if (virtualNetPortArg==-1)
      staticInformUser("VirtualNet will not be used, not specified parameter " + VirtualNetPortParam, false);
    else
    {
      try
      {
        int port = Integer.valueOf(args[virtualNetPortArg+1]).intValue();
        int remArgs=4;
        String host = null;
        if (virtualNetHostArg!=-1)
        {
          host=args[virtualNetHostArg+1];
          remArgs=6;
        }

        setup(user, args[virtualHostNameArg+1], host, port, props);

        ret=new String[len-remArgs];
        for(int i=j=0;j<len;j++)
          if ((j==virtualHostNameArg) || (j==virtualNetHostArg) || (j==virtualNetPortArg))
            ++j;
          else
            ret[i++]=args[j];

        staticInformUser("Using virtual net ...", false);
      }
      catch(NumberFormatException ex)
      {
        staticInformUser("Error parsing integer: " + ex.getMessage(), true);
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** SETUP **************************************************//
  //*************************************************************************************//

  /**
    * This method must be called with the properties that will be later
    * passed to the ORB.init method. It is therefore important to call
    * this method before starting the ORB!
    * In case of errors, the user is informed directly. If the user is not specified
    * (null) the fatal errors are sent to the normal output and the system exited!
    * NetHost name can be null, and in that case it is used the local host
    * NetPort can be cero, and in that case it is used the defualt one
    **/
  public static void setup(InterceptorsUser user, String virtualHostName, String virtualNetHost, int virtualNetPort, Properties props)
  {
    Interceptor.user = user;
    Interceptor.virtualHostName = virtualHostName;
    try
    {
      Interceptor.virtualNetHost = virtualNetHost==null? InetAddress.getLocalHost().getHostName() : virtualNetHost;
    }
    catch(UnknownHostException ex)
    {
      Interceptor.virtualNetHost = DEFAULT_HOST;
    }
    Interceptor.virtualNetPort = virtualNetPort==0? DEFAULT_PORT: virtualNetPort;
    props.put("org.omg.PortableInterceptor.ORBInitializerClass.vnet2user.Interceptor" ,"");
  }

  //*************************************************************************************//
  //**************************** CONSTRUCTOR ********************************************//
  //*************************************************************************************//

  /**
    * The constructor must be public to enable its construction from the ORB, but this class
    * needs not to be directly created!
    **/
  boolean init()
  {
    vnetResult = new byte[1];
    context    = null;

    virtualNetInput  = null;
    virtualNetOutput = null;

    goodState=true;


    //the name is converted to the format expected by the virtual net
    byte vnetName[]=getVirtualNetFormattedName(virtualHostName);

    if (vnetName==null)
    {
      informUser("VirtualHostName is not valid (bigger than 255 characters)?", true);
    }
    else
    {

      //store the name in a serviceContext to be sent on every request
      context = new org.omg.IOP.ServiceContext(CONTEXT_NUMBER,vnetName);

      if (!initSession(virtualNetHost, virtualNetPort, vnetName) && goodState)
        informUser("Node " + virtualHostName + " is not currently existing on the virtual net "
                    + "on host " + virtualNetHost + " on port " + virtualNetPort, false);
    }
    return goodState;
  }

  //*************************************************************************************//
  //**************************** INIT SESSION *******************************************//
  //*************************************************************************************//

  /**
    * Inits the session with the virtual net. In case of error, the user received a
    * message and goodState is set to false.
    * Returns true if there are no errors and the vnetName is valid. This name can
    * be invalid, that the session will still be valid!
    **/
  boolean initSession(String host, int port, byte vnetName[])
  {
    boolean ret=false;
    try
    {
      Socket virtualNet = new Socket(host, port);
      virtualNetInput   = virtualNet.getInputStream();
      virtualNetOutput  = virtualNet.getOutputStream();
      ret = checkNode(vnetName);
    }
    catch(Exception ex)//IOException, UnknownHostException
    {
      informUser(ex.getMessage(), true);
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** CHECK NODE *********************************************//
  //*************************************************************************************//

  /**
    * Sends the node to the virtualnet socket, returning true on success.
    * If there is an error, goodState is set to false and the error sent to the user
    **/
  boolean checkNode(byte vnetName[])
  {
    boolean ret=goodState;
    if (ret)
    {
      try
      {
        virtualNetOutput.write(vnetName);
        if ((virtualNetInput.read(vnetResult)==0) || (virtualNetInput.available()>0))
        {
          informUser("Communication error with the virtual net", true);
          ret=false;
        }
        else
        {
          ret=vnetResult[0]==0;
        }
      }
      catch(IOException ex)
      {
        informUser("Communication error with the virtual net: " + ex.getMessage(), true);
        ret=false;
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** GET VIRTUALNET FORMATTED NAME **************************//
  //*************************************************************************************//

  /**
    * Converts a virtualHostName into the format requested by the virtualnet.
    * Returns null if the name is not valid (longuer than 255 characters)
    **/
  byte[] getVirtualNetFormattedName(String virtualHostName)
  {
    byte ret[]=null;
    try
    {
      byte name[]=virtualHostName.getBytes("UTF-8");
      int iLength=name.length;
      if (iLength>Byte.MAX_VALUE)
        ret=null;
      else
      {
        ret=new byte[1+iLength];
        ret[0]=(byte) iLength;
        while(iLength-->0)
          ret[iLength+1]=name[iLength];
      }
    }
    catch(java.io.UnsupportedEncodingException ex)
    {
    }
    return ret;
  }


  //*************************************************************************************//
  //**************************** VERIFY PATH ********************************************//
  //*************************************************************************************//

  void verifyPath(ServiceContext source)
  {
    if (!checkNode (source.context_data))
      throw new org.omg.CORBA.COMM_FAILURE();
  }

  void verifyPath(ClientRequestInfo ri)
  {
    try
    {
      verifyPath(ri.get_reply_service_context(CONTEXT_NUMBER));
    }
    catch (org.omg.CORBA.BAD_PARAM ex)
    {
      //invalid context
    }
  }

  void verifyPath(ServerRequestInfo ri)
  {
    try
    {
      verifyPath(ri.get_request_service_context(CONTEXT_NUMBER));
    }
    catch (org.omg.CORBA.BAD_PARAM ex)
    {
      //invalid context
    }
  }

  //*************************************************************************************//
  //**************************** INTERCEPTOR INITIALIZER OPERATIONS *********************//
  //*************************************************************************************//

  public void pre_init(ORBInitInfo info){}

  public void post_init(ORBInitInfo info)
  {
    if (init())
      try
      {
        info.add_client_request_interceptor(this);
        info.add_server_request_interceptor(this);
      }
      catch(org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName ex)
      {
        informUser(ex.getMessage(), true);
      }
  }

  //*************************************************************************************//
  //**************************** INTERCEPTOR OPERATIONS *********************************//
  //*************************************************************************************//

  public String name(){return "Interceptor";}
  public void destroy(){}

  //*************************************************************************************//
  //**************************** CLIENT INTERCEPTOR OPERATIONS **************************//
  //*************************************************************************************//

  public void send_request(ClientRequestInfo ri)
  {
    ri.add_request_service_context(context, true);
  }

  public void send_poll(ClientRequestInfo ri)
  {
    ri.add_request_service_context(context, true);
  }

  public void receive_reply(ClientRequestInfo ri)
  {
    verifyPath(ri);
  }

  public void receive_exception(ClientRequestInfo ri)
  {
    verifyPath(ri);
  }

  public void receive_other(ClientRequestInfo ri)
  {
    verifyPath(ri);
  }

  //*************************************************************************************//
  //**************************** SERVER INTERCEPTOR OPERATIONS **************************//
  //*************************************************************************************//

  public void receive_request_service_contexts(ServerRequestInfo ri){}

  public void send_reply(ServerRequestInfo ri)
  {
    ri.add_reply_service_context(context, false);
  }

  public void send_exception(ServerRequestInfo ri)
  {
    boolean add;
    try
    {
      add=!ri.sending_exception().type().id().equals("IDL:omg.org/CORBA/COMM_FAILURE:1.0");
    }
    catch(org.omg.CORBA.TypeCodePackage.BadKind be)
    {
      add=true;
    }
    if (add)
      ri.add_reply_service_context(context, true);
  }

  public void send_other(ServerRequestInfo ri)
  {
    ri.add_reply_service_context(context, true);
  }

  public void receive_request(ServerRequestInfo ri)
  {
    verifyPath(ri);
  }

  //*************************************************************************************//
  //**************************** INFORM USER ********************************************//
  //*************************************************************************************//

  void informUser(String message, boolean fatalError)
  {
    staticInformUser(message, fatalError);
    if (fatalError)
      goodState=false;
  }

  static void staticInformUser(String message, boolean fatalError)
  {
    if (user==null)
    {
      if (fatalError)
      {
        System.out.println("VirtualNet fatal error: " + message);
        System.exit(0);
      }
      else
        System.out.println(message);
    }
    else
    {
      user.vnet2Message("VirtualHostName is not valid (bigger than 255 characters)?", fatalError);
    }
  }

  //*************************************************************************************//
  //**************************** DATA ***************************************************//
  //*************************************************************************************//

  static InterceptorsUser user;
  static String virtualHostName, virtualNetHost;
  static int virtualNetPort;

  ServiceContext context;
  boolean goodState;
  InputStream virtualNetInput;
  OutputStream virtualNetOutput;
  byte vnetResult[];
  final static int CONTEXT_NUMBER=57456;  //any
  final static int DEFAULT_PORT=57456;
  final static String DEFAULT_HOST="localhost";

  final static String VirtualHostNameParam = "-virtualHostName";
  final static String VirtualNetHostParam  = "-virtualNetHost";
  final static String VirtualNetPortParam  = "-virtualNetPort";
}

