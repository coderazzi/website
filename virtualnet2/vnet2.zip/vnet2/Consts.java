/**
  * File: Consts.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Color;
  
/**
  * Definition of the constants in the system
  **/
class Consts
{
  //maximum timoeut needed to stop a virtual net
  public static final int MAX_SHUTDOWN_TIME = 1000; //milliseconds
  
  //default delay of messages in a node
  public static final int DEFAULT_NODES_DELAY=50;

  //default delay of messages in a link
  public static final int DEFAULT_LINKS_DELAY=100;

  //initial size of the panel (x)
  public static final int PANEL_SIZEX=300;

  //initial size of the panel (y)
  public static final int PANEL_SIZEY=300;
  
  //colors
  public static final Color BACKGROUND_COLOR=Color.lightGray;
  
  //properties file
  public static final String FILE_HIDE_GRAPH = "GraphHidden";
  public static final String FILE_SOCKET = "Socket";

  public static final String FILE_HEADER = "Virtual Path : netlayout configuration file";
  public static final String FILE_TRUE_PROPERTY_VALUE = "true";
  public static final String FILE_FALSE_PROPERTY_VALUE = "false";
  public static final String FILE_NODES_SIZE = "Nodes";
  public static final String FILE_NODE_ID_X = "Node.id.";
  public static final String FILE_NODE_DELAY_X = "Node.delay.";
  public static final String FILE_NODE_ACTIVE_X = "Node.active.";
  public static final String FILE_LINKS_SIZE = "Links";
  public static final String FILE_LINK_ID_X = "Link.id.";
  public static final String FILE_LINK_DELAY_X = "Link.delay.";
  public static final String FILE_LINK_NODEA_X = "Link.nodeA.";
  public static final String FILE_LINK_NODEB_X = "Link.nodeB.";
  public static final String FILE_LINK_ACTIVE_X = "Link.active.";
  public static final String FILE_LINK_BIDIRECTIONAL_X = "Link.bidirectional.";
  
  public static final String FILE_GRAPH_HEADER = "graphic configuration";
  public static final String FILE_GRAPH = "Graph.";
  public static final String FILE_GRAPH_SIZE_X = "sizeX";
  public static final String FILE_GRAPH_SIZE_Y = "sizeY";
  public static final String FILE_GRAPH_NODE_POSX = "node.x.";
  public static final String FILE_GRAPH_NODE_POSY = "node.y.";
  public static final String FILE_GRAPH_LINK_POSX = "link.x.";
  public static final String FILE_GRAPH_LINK_POSY = "link.y.";

  
}
