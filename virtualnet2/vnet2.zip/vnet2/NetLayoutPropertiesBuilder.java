/**
  * File: NetLayoutPropertiesBuilder.java
  * @author LuisM Pena
  * @version 0.3, february-2001
  **/
  
package vnet2;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
 
/**
  * Helper class to save and load a NetLayout as properties
  **/
class NetLayoutPropertiesBuilder
{
  
//*************************************************************************************//
//**************************** LOAD LAYOUT ********************************************//
//*************************************************************************************//
  
  public NetLayout loadLayout(Properties properties) throws NetLayoutException, BuilderException
  {
    NetLayout layout = new NetLayout();
    NetLayoutBuilder builder = new NetLayoutBuilder(layout);
    loadNodes(builder, properties);
    loadLinks(builder, properties);
    return layout;
  }
  
//*************************************************************************************//
//**************************** LOAD LINKS *********************************************//
//*************************************************************************************//
  
  void loadLinks(NetLayoutBuilder helper, Properties properties) throws NetLayoutException, BuilderException
  {
    int links = readUnsigned(properties, Consts.FILE_LINKS_SIZE, true, 0);
    
    for (int i=1; i <= links ; i++)
    {
      LinkId link = new LinkId(readString(properties, Consts.FILE_LINK_ID_X + i, true, null));
      NodeId nodeA = new NodeId(readString(properties, Consts.FILE_LINK_NODEA_X + i, true, null));
      NodeId nodeB = new NodeId(readString(properties, Consts.FILE_LINK_NODEB_X + i, true, null));
      helper.addLink(link, nodeA, nodeB, 
                    readUnsigned(properties, Consts.FILE_LINK_DELAY_X + i, false, Consts.DEFAULT_LINKS_DELAY),
                    readBoolean(properties,Consts.FILE_LINK_BIDIRECTIONAL_X + i,false, true));
      helper.activateLink(link, readBoolean(properties,Consts.FILE_LINK_ACTIVE_X + i,false, true));
    }
  }

//*************************************************************************************//
//**************************** LOAD NODES *********************************************//
//*************************************************************************************//
  
  void loadNodes(NetLayoutBuilder helper, Properties properties) throws NetLayoutException, BuilderException
  {
    int nodes = readUnsigned(properties, Consts.FILE_NODES_SIZE, true, 0);
    
    for (int i=1; i <= nodes ; i++)
    {
      NodeId node = new NodeId(readString(properties, Consts.FILE_NODE_ID_X + i, true, null));
      helper.addNode(node, readUnsigned(properties, Consts.FILE_NODE_DELAY_X + i, false, Consts.DEFAULT_NODES_DELAY));
      helper.activateNode(node, readBoolean(properties,Consts.FILE_NODE_ACTIVE_X + i,false, true));
    }
  }

//*************************************************************************************//
//**************************** STORE LAYOUT *******************************************//
//*************************************************************************************//
  
  /**
    * Stores the layout in the properties given
    **/
  public void storeLayout(NetLayout layout, Properties properties)
  {
    storeNodes(layout.getNodes(), properties);
    storeLinks(layout.getLinks(), properties);
  }
  
//*************************************************************************************//
//**************************** STORE NODES ********************************************//
//*************************************************************************************//
  
  /**
    * Stores the nodes in the properties given
    **/
  void storeNodes(Set nodes, Properties properties)
  {
    int len = nodes.size();
    
    properties.setProperty(Consts.FILE_NODES_SIZE, String.valueOf(len));
    
    Iterator iterator=nodes.iterator();
    while(iterator.hasNext())
    {
      assert len>0;
      NetNode node = (NetNode) iterator.next();
      properties.setProperty(Consts.FILE_NODE_ID_X + len, node.getId().toString());
      properties.setProperty(Consts.FILE_NODE_DELAY_X + len, String.valueOf(node.getDelay()));
      writeBoolean(properties, Consts.FILE_NODE_ACTIVE_X + len, node.isActive());
      --len;
    }
  }
  
//*************************************************************************************//
//**************************** STORE LINKS ********************************************//
//*************************************************************************************//
  
  /**
    * Stores the links in the properties given
    **/
  void storeLinks(Set links, Properties properties)
  {
    int len = links.size();
    
    properties.put(Consts.FILE_LINKS_SIZE, String.valueOf(len));
    
    Iterator iterator=links.iterator();
    while(iterator.hasNext())
    {
      assert len>0;
      NetLink link = (NetLink) iterator.next();
      properties.setProperty(Consts.FILE_LINK_ID_X + len, link.getId().toString());
      properties.setProperty(Consts.FILE_LINK_DELAY_X + len, String.valueOf(link.getDelay()));
      
      NetNode node = link.getNodeA();
      assert node!=null;
      properties.setProperty(Consts.FILE_LINK_NODEA_X + len, node.getId().toString());

      node = link.getNodeB();
      assert node!=null;
      properties.setProperty(Consts.FILE_LINK_NODEB_X + len, node.getId().toString());

      writeBoolean(properties, Consts.FILE_LINK_ACTIVE_X + len, link.isActive());
      writeBoolean(properties, Consts.FILE_LINK_BIDIRECTIONAL_X + len, link.isBidirectional());

      --len;
    }
  }

  //*************************************************************************************//
  //**************************** READ UNSIGNED ******************************************//
  //*************************************************************************************//
  
  static int readUnsigned(Properties properties, String name, boolean mandatory, int defaultValue) throws BuilderException
  {
    int ret=-1;
    String prop = properties.getProperty(name);
    if (prop==null)
    {
      ret = defaultValue;
      if (mandatory)
        propertyNotDefined(name);
    }
    else
    {
      try
      {
        ret = Integer.parseInt(prop);
        if (ret<0)
          propertyInvalid(name, prop);
      }
      catch(NumberFormatException ex)
      {
        propertyInvalid(name, prop);
      }    
    }
    return ret;
  }
  
  //*************************************************************************************//
  //**************************** READ STRING ********************************************//
  //*************************************************************************************//
  
  static String readString(Properties properties, String name, boolean mandatory, String defaultValue)  throws BuilderException
  {
    String ret = properties.getProperty(name);
    if (ret==null)
    {
      if (mandatory)
        propertyNotDefined(name);
      else
        ret=defaultValue;
    }
    return ret;
  }
  
  //*************************************************************************************//
  //**************************** READ BOOLEAN *******************************************//
  //*************************************************************************************//
  
  static boolean readBoolean(Properties properties, String name, boolean mandatory, boolean defaultValue)  throws BuilderException
  {
    boolean ret=defaultValue;
    String prop = properties.getProperty(name);
    if (prop==null)
    {
      if (mandatory)
        propertyNotDefined(name);
    }
    else
      if (prop.equalsIgnoreCase(Consts.FILE_FALSE_PROPERTY_VALUE))
        ret = false;
      else if (prop.equalsIgnoreCase(Consts.FILE_TRUE_PROPERTY_VALUE))
        ret = true;
      else
        propertyInvalid(name, prop);
    return ret;
  }
  
  //*************************************************************************************//
  //**************************** WRITE BOOLEAN ******************************************//
  //*************************************************************************************//
  
  static void writeBoolean(Properties properties, String name, boolean value)
  {
    properties.setProperty(name, value? Consts.FILE_TRUE_PROPERTY_VALUE: Consts.FILE_FALSE_PROPERTY_VALUE);
  }
  
  //*************************************************************************************//
  //**************************** PROPERTY NOT DEFINED ***********************************//
  //*************************************************************************************//
  
  static void propertyNotDefined(String property)  throws BuilderException
  {
    throw new BuilderException("Property " + property + " has not been defined");
  }
  
  //*************************************************************************************//
  //**************************** PROPERTY INVALID ***************************************//
  //*************************************************************************************//
  
  static void propertyInvalid(String property, String value) throws BuilderException
  {
    throw new BuilderException("Property " + property + " has an invalid value: " + value);
  }
  
}
