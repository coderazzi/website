/**
  * File: MouseTracker.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.event.MouseInputAdapter;

/**
  * Handles the Mouse actions
  **/
class MouseTracker extends MouseInputAdapter implements ActionListener
{
  public MouseTracker(MouseTrackerUser user)
  {
    this.user=user;

    menu = new JPopupMenu();
    name = new JMenuItem("");
    activate = new JMenuItem("activate");
    deactivate = new JMenuItem("deactivate");
    destroy = new JMenuItem("destroy");
    
    menu.add(name);
    menu.addSeparator();
    menu.add(activate);
    menu.add(deactivate);
    menu.addSeparator();
    menu.add(destroy);
    
    name.setEnabled(false);
    activate.addActionListener(this);
    deactivate.addActionListener(this);
    destroy.addActionListener(this);
  }

  public void mousePressed(MouseEvent e) 
  {
    if (!tryPopup(e))
    {
      lastX=e.getX();
      lastY=e.getY();
      item=user.getElement(lastX, lastY);
    }
  }
  
  public void mouseDragged(MouseEvent e) 
  {
    if (item!=null)
    {
      int x = e.getX();
      int y = e.getY();
      x = (x<0)? 0 : (x>maxX)? maxX : x;
      y = (y<0)? 0 : (y>maxY)? maxY : y;
      if (x!=lastX || y!=lastY)
      {
        if (user.movingElement(item, x, y))
        {
          lastX=x;
          lastY=y;
        }
        else
          item=null;
      }
    }
  }
  
  public void mouseReleased(MouseEvent e)
  {
    tryPopup(e);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource().equals(activate))
      user.actionOnElement(item, "+.");
    else if (e.getSource().equals(deactivate))
      user.actionOnElement(item, "-.");
    else if (e.getSource().equals(destroy))
      user.actionOnElement(item, "-");
  }
  
  boolean tryPopup(MouseEvent e)
  {
    boolean ret=e.isPopupTrigger();
    if (ret)
    {
      item=user.getElement(e.getX(), e.getY());
      if (item!=null)
      {
        name.setText(item.getName());
        lastEvent=e;
        menu.show(e.getComponent(),e.getX(),e.getY());
      }
  
    }
    return ret;
  }

  public void setMaxPositions(int maxX, int maxY)
  {
    this.maxX=maxX;
    this.maxY=maxY;
  }
  
  MouseEvent lastEvent;
  MouseTrackerUser user;
  MouseAware item=null;
  int lastX, lastY, maxX, maxY;
  JPopupMenu menu;
  JMenuItem name, activate, deactivate, destroy;
};
