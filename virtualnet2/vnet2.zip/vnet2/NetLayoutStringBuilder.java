/**
  * File: NetLayoutStringBuilder.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

/**
  * Helper class to build the NetLayout using a String to define
  * the operations.
  * 1- A node or a link is specified by a string that:
  *    a- contains no spaces
  *    b- cannot contain the characters '-', '+', '<', '>', '(', ')','/'
  * 2- A node is created by prepending the character '+' to the
  *    name of the node. For example: +Machine_1. Spaces at
  *    the beginning or at the end are removed.
  * 3- To remove a node, the same notation as to created is used,
  *    but using the character '-'. For example -Machine_1
  * 4- A node can de activated/deactivated temporary using
  *    '+.' or '-.;. For example '-.Machine_1'
  * 5- A link is created specifying '+', the first node, then a
  *    character '<', the link id, again a character '>'
  *    and then the second node. For example:
  *    '+Machine_1<link1>Machine_2. To do the link unidirectional,
  *    use '<' before the second node: +Machine_1<link1<Machine_2
  * 6- A link is removed specifying '-<' before the node name,
  *    like '-<link1'.
  * 7- A link can de activated/deactivated temporary using
  *    '+.' or '-.;. For example '-.<link1'
  * 8- delays can be specified to nodes or links by appendind
  *    to its name "(delay)", on creation. For example:
  *    "+Node(100)"
  *    "+Node<Link(100)>OtherNode"
  *10- A node delay can be changed using /node(delay)
  *11- A link delay can be changed using /<link(delay)
  *12- Every link delay can be changed using /<(delay)
  *12- Every node delay can be changed using /(delay)
  *13- In the previous cases, if the delay is not specified,
  *    default values are assumed
  *
  * Strings are case dependant.
  **/

import java.util.Iterator;

public class NetLayoutStringBuilder
{
  /**
    * Constructor requires the NetLayoutBuilder to use
    **/
  public NetLayoutStringBuilder(NetLayoutBuilder builder)
  {
    this.builder = builder;
    tokenizer = new NetLayoutStringBuilderTokenizer();
  }

  /**
    * Processes the input string
    * If there are errors, it is not guaranteed that the
    * NetLayout be not modified before error is found.
    * A string containing the error can be then obtained
    **/
  public synchronized void process(String build) throws NetLayoutException, BuilderException
  {
    Iterator it=tokenizer.process(build);
      while(it.hasNext())
      {
        Object o = it.next();
        if (o instanceof NetLayoutStringBuilderTokenizer.DelayNode)
        {
          NetLayoutStringBuilderTokenizer.DelayNode t=(NetLayoutStringBuilderTokenizer.DelayNode) o;

          if (t.node==null)
            builder.setNodesDelay(t.delay);
          else
            builder.setNodeDelay(new NodeId(t.node), t.delay);

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.DelayLink)
        {
          NetLayoutStringBuilderTokenizer.DelayLink t=(NetLayoutStringBuilderTokenizer.DelayLink) o;

          if (t.link==null)
            builder.setLinksDelay(t.delay);
          else
            builder.setLinkDelay(new LinkId(t.link), t.delay);

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.RemoveNode)
        {
          NetLayoutStringBuilderTokenizer.RemoveNode t=(NetLayoutStringBuilderTokenizer.RemoveNode) o;

          builder.removeNode(new NodeId(t.node));

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.RemoveLink)
        {
          NetLayoutStringBuilderTokenizer.RemoveLink t=(NetLayoutStringBuilderTokenizer.RemoveLink) o;

          builder.removeLink(new LinkId(t.link));

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.ActivateNode)
        {
          NetLayoutStringBuilderTokenizer.ActivateNode t=(NetLayoutStringBuilderTokenizer.ActivateNode) o;

          builder.activateNode(new NodeId(t.node), t.activate);

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.ActivateLink)
        {
          NetLayoutStringBuilderTokenizer.ActivateLink t=(NetLayoutStringBuilderTokenizer.ActivateLink) o;

          builder.activateLink(new LinkId(t.link), t.activate);

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.CreateNode)
        {
          NetLayoutStringBuilderTokenizer.CreateNode t=(NetLayoutStringBuilderTokenizer.CreateNode) o;

          builder.addNode(new NodeId(t.node), t.delay);

        }
        else if (o instanceof NetLayoutStringBuilderTokenizer.CreateLink)
        {
          NetLayoutStringBuilderTokenizer.CreateLink t=(NetLayoutStringBuilderTokenizer.CreateLink) o;

          builder.addLink(new LinkId(t.link), new NodeId(t.nodeA), new NodeId(t.nodeB), t.delay, t.bidirectional);

        }
        else
          throw new BuilderException("Internal error!");
      }
  }

  NetLayoutBuilder builder;
  NetLayoutStringBuilderTokenizer tokenizer;
}

