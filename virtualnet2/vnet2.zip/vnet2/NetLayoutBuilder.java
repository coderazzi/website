/**
  * File: NetLayoutBuilder.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.util.Iterator;
  
/**
  * Helper class to build the NetLayout.
  * As first approach, build requests are handled synchronously
  * but a next version could handle the asynchronously,  to allow
  * requests like "inactive node for 3 seconds, then ...."
  **/
class NetLayoutBuilder
{
  /**
    * Constructor requires the NetLayout to modify
    **/
  public NetLayoutBuilder(NetLayout target)
  {
    netLayout = target;
    changed = false;
  }
  
  public boolean isChanged()
  {
    return changed;
  }
  
  public void setUnchanged()
  {
    changed=false;
  }
  
  /**
    * Adds a node, returning true if it was added (i.e. was not
    * existing)
    **/
  public void addNode(NodeId nodeId, int delay) throws NetLayoutException
  {
    netLayout.addNode(nodeId, delay);
    changed = true;
  }
  

  /**
    * Removes a node, returning true if it was remove (i.e. was
    * existing and has no links)
    **/
  public void removeNode(NodeId nodeId)  throws NetLayoutException
  {
    netLayout.removeNode(nodeId);
    changed = true;
  }
  
  /**
    * Activate/deactivate a node
    **/
  public void activateNode(NodeId nodeId, boolean active) throws NetLayoutException
  {
    netLayout.getNode(nodeId).activate(active);
    changed = true;
  }
  
/**
  * Sets a node delay
  **/
  public void setNodeDelay(NodeId nodeId, int delay)  throws NetLayoutException
  {
    netLayout.getNode(nodeId).setDelay(delay);
    changed = true;
  }
  
  /**
    * Adds a link, returning true if it was added (i.e. was not
    * existing,  nodes were valid....)
    **/
  public void addLink(LinkId linkId, NodeId nodeIdA, NodeId nodeIdB, int delay, boolean bidirectional)  throws NetLayoutException
  {
    netLayout.addLink(linkId, netLayout.getNode(nodeIdA), netLayout.getNode(nodeIdB), delay, bidirectional);
    changed = true;
  }
  

  /**
    * Adds a link
    **/
  public void removeLink(LinkId linkId)  throws NetLayoutException
  {
    netLayout.removeLink(linkId);
    changed = true;
  }
  
  /**
    * Activate/deactivate a link
    **/
  public void activateLink(LinkId linkId, boolean active) throws NetLayoutException
  {
    netLayout.getLink(linkId).activate(active);
    changed = true;
  }
  
  /**
    * Sets a links delay
    **/
  public void setLinkDelay(LinkId linkId, int delay) throws NetLayoutException
  {
    netLayout.getLink(linkId).setDelay(delay);
    changed = true;
  }
  
  /**
    * Sets the delay for all the links
    **/
  public void setLinksDelay(int delay)
  {
    Iterator it=netLayout.getLinks().iterator();
    while(it.hasNext())
      ((NetLink) (it.next())).setDelay(delay);
    changed = true;
  }
  
  /**
    * Sets the delay for all the nodes
    **/
  public void setNodesDelay(int delay)
  {
    Iterator it=netLayout.getNodes().iterator();
    while(it.hasNext())
      ((NetNode) (it.next())).setDelay(delay);
    changed = true;
  }
  
  NetLayout netLayout;
  boolean changed;
}
