/**
  * File: BuilderException.java
  * @author LuisM Pena
  * @version 0.3, february-2001
  **/

package vnet2;

class BuilderException extends Exception
{
  public BuilderException(String reason)
  {
    super(reason);
  }
}
