/**
  * File: VnetPanel.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.HashSet;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.Iterator;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
  * Handles the painting of the different nodes, and contains references
  * to them. It is therefore the graphic peer of the NetLayout.
  **/
class VnetPanel extends JPanel implements MouseTrackerUser, Observer
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * Constructor: requires the initial nodes and links to display
    **/
  public VnetPanel(NetLayoutStringBuilder builder, Set nodes, Set links, GraphState state)
  {    
    graphNodes = new HashSet();
    graphLinks = new HashSet();
    this.builder = builder;
    this.nodes = nodes;
    this.links = links;
    this.state = state;
    clip=new Rectangle();
    setBackground(Consts.BACKGROUND_COLOR);
    size=state.getGraphSize();
    setPreferredSize(size);
    
    addComponentListener(new ComponentAdapter(){public void componentResized(ComponentEvent ev){changedSize();}});
    mouseTracker=new MouseTracker(this);
    addMouseListener(mouseTracker);
    addMouseMotionListener(mouseTracker);
    setToolTipText("");
  }
  
  public String getToolTipText(java.awt.event.MouseEvent e)
  {
    MouseAware item=getElement(e.getX(),e.getY());
    return item==null? null : item.getInfo();
  }
  
  /*******************************************************************************/
  /**************************** DESTROY ******************************************/
  /*******************************************************************************/
  
  /**
    * Destroys the current Panel.
    **/
  public synchronized void destroy()
  {
    //remove first observers
    Iterator it=graphNodes.iterator();
    while(it.hasNext())
    {
      GraphNode node = (GraphNode) (it.next());
      NetNode netNode = node.getNode();
      netNode.deleteObserver(this);
      netNode.deleteObserver(node);
      node.destroy();
    }
    graphNodes.clear();
    it=graphLinks.iterator();
    while(it.hasNext())
    {
      GraphLink link = (GraphLink) (it.next());
      NetLink netLink = link.getLink();
      netLink.deleteObserver(this);
      netLink.deleteObserver(link);
      link.destroy();
    }
    removeMouseListener(mouseTracker);
    removeMouseMotionListener(mouseTracker);
    graphLinks.clear();
    mouseTracker=null;
    size=null;
    nodes=null;
    links=null;
    graphNodes=null;
    graphLinks=null;
    clip=null;;
    builder=null;
  }
  
  /*******************************************************************************/
  /**************************** DESTROY ******************************************/
  /*******************************************************************************/
  
  /**
    * Returns the state of the panel
    **/
  public synchronized GraphState getState()
  {
    GraphState state = new GraphState();
    state.setGraphSize(getSize());
    Iterator it=graphNodes.iterator();
    while(it.hasNext())
      state.storeNodeCentre((GraphNode) (it.next()));
    it=graphLinks.iterator();
    while(it.hasNext())
      state.storeLinkCentre((GraphLink) (it.next()));
    return state;
  }
  
  
  /*******************************************************************************/
  /**************************** OBSERVER INTERFACE *******************************/
  /*******************************************************************************/
  
  /**
    * Through this interface they are received the new nodes and links, and the destruction events
    **/
  public void update(Observable obs, Object what)
  {
    if (what instanceof NetNode)
    {
      synchronized(this)
      {
        nodes.add((NetNode) what);
      }
      repaint();
    }
    else if (what instanceof NetLink)
    {
      synchronized(this)
      {
        links.add((NetLink) what);
      }
      repaint();
    }
    else if (what==VirtualDeviceEvent.getDestroyedEvent())
    {
      synchronized(this)
      {
        if (obs instanceof NetNode)
        {
          if (!nodes.remove(obs)) //the GraphNode has been already created
          {
            GraphNode gNode = getNode(((NetNode)obs).getId().toString());
            graphNodes.remove(gNode);
          }
        }
        else if (obs instanceof NetLink)
        {
          if (!links.remove(obs))
            removeLink(((NetLink)obs).getId().toString());
        }
      }
    }
  }
  
  /*******************************************************************************/
  /**************************** PAINT ********************************************/
  /*******************************************************************************/
  
  /**
    * Paint method
    **/
  protected void paintComponent(Graphics g)
  {
    super.paintComponent(g);
    
    synchronized(this)
    {
      //include now new nodes or links
      addNodes(g);
      addLinks(g);
      state=null;
      
      //paint only the required components
      g.getClipBounds(clip);

      Iterator it=graphLinks.iterator();
      while(it.hasNext())
      {
        GraphLink link = (GraphLink) it.next();
        if (link.clipsArea(clip))
          link.draw(g);
      }

      it=graphNodes.iterator();
      while(it.hasNext())
      {
        GraphNode node = (GraphNode) it.next();
        if (node.clipsArea(clip))
          node.draw(g);
      }
  
    }
  }
  
  /*******************************************************************************/
  /**************************** CHANGED SIZE *************************************/
  /*******************************************************************************/
  
  /**
    * changedSize will be called each time the component is resized
    **/
  synchronized void changedSize()
  {
    Dimension newSize=getSize();
    if (size==null)
    {
      if (newSize.width>0 && newSize.height>0)
        size=newSize;  //first time
    }
    else
    {
      double fx = newSize.width;
      double fy = newSize.height;
      if (fx>0 && fy>0)
      {
        fx/=size.width;
        fy/=size.height;
        size=newSize;
        
        Iterator it=graphNodes.iterator();
        while (it.hasNext())
          ((GraphNode)(it.next())).translate(fx,fy);

        it=graphLinks.iterator();
        while (it.hasNext())
          ((GraphLink)(it.next())).translate(fx,fy);
        }
    }
    if(size!=null)
      mouseTracker.setMaxPositions(size.width, size.height);
  }
  
  /*******************************************************************************/
  /**************************** MOUSE TRACKER USE INTERFACE **********************/
  /*******************************************************************************/
  
  /**
    * called when the mouse is pressed on some place.
    * Returns the component (if any) pressed
    **/
  public MouseAware getElement(int x, int y)
  {
    Iterator it=graphNodes.iterator();
    while (it.hasNext())
    {
      GraphNode node = (GraphNode)(it.next());
      if (node.containsPoint(x,y))
        return node;
    }
    it=graphLinks.iterator();
    while (it.hasNext())
    {
      GraphLink link = (GraphLink)(it.next());
      if (link.containsPoint(x,y))
        return link;
    }
    return null;
  }
  
  /**
    * called when the mouse is dragged to some place.
    * returns true if the move can be accepted
    **/
  public boolean movingElement(MouseAware item, int x, int y)
  {
    //note that the node can be eliminated!
    boolean ret=graphNodes.contains(item) || graphLinks.contains(item);
    if (ret)
      item.draggedPoint(x,y);
    return ret;
  }
  
  /**
    * Menu action on a element
    **/
  public void actionOnElement(MouseAware item, String action)
  {
    String build=action;
    if (item instanceof GraphLink)
      build=build+"<";
      
    try
    {
      builder.process(build+item.getName());
    }
    catch(Exception ex)
    {
      JOptionPane.showMessageDialog(this,ex.getMessage(),"Warning",JOptionPane.WARNING_MESSAGE);
    }
  }
  
  /*******************************************************************************/
  /**************************** ADD NODES ****************************************/
  /*******************************************************************************/
  
  /**
    * Creates graphNodes  when there are new nodes to add
    **/
  void addNodes(Graphics g)
  {
    //assume that is already sinchronized
    int nNodes = nodes.size();
    if (nNodes>0)
    {
      //nodes are displayed in a square matrix
      int rows = (int) (Math.sqrt(nNodes));
      int cols = rows;
      if (nNodes != rows*rows)
      {
        cols++;
        if (nNodes>cols*rows)
          rows++;
      }        
      double sx=size.getWidth()/(cols+1);
      double sy=size.getHeight()/(rows+1);

      //size can not be null. If that would be the case, the 
      //paint method would not be called
      int i=1;
      int j=1;
      Point centre = new Point();
      Iterator it=nodes.iterator();
      while(it.hasNext())
      {
        NetNode node = (NetNode) (it.next());
        centre.setLocation(i*sx, j*sy);
        if (state!=null)
          centre = state.getNodeCentre(node, centre);
        GraphNode graphNode = new GraphNode(this, node, centre);
        graphNodes.add(graphNode);
        node.addObserver(this);
        
        if (++i>cols) {i=1;++j;}
      }
      nodes.clear();
    }
  }

  /*******************************************************************************/
  /**************************** ADD LINKS ****************************************/
  /*******************************************************************************/
  
  /**
    * Creates graphNodes  when there are new nodes to add
    **/
  void addLinks(Graphics g)
  {
    //assume that is already sinchronized
    Point centre = new Point();
    int nLinks = links.size();
    if (nLinks>0)
    {
      Iterator it=links.iterator();
      while(it.hasNext())
      {
        NetLink link = (NetLink) (it.next());
        GraphNode nodeA = getNode(link.getNodeA().getId().toString());
        GraphNode nodeB = getNode(link.getNodeB().getId().toString());

        if (nodeA!=null && nodeB!=null)
        {
          Point a = nodeA.getCentre();
          Point b = nodeB.getCentre();
          centre.setLocation((a.getX()+b.getX())/2, (a.getY()+b.getY())/2);
          if (state!=null)
            centre = state.getLinkCentre(link, centre);
          GraphLink graphLink = new GraphLink(this, link, nodeA, nodeB, centre);
          graphLinks.add(graphLink);
          link.addObserver(this);
        }
      }
      links.clear();
    }
  }
  
  /*******************************************************************************/
  /**************************** GET NODE *****************************************/
  /*******************************************************************************/
  
  GraphNode getNode(String name)
  {
    Iterator it=graphNodes.iterator();
    while(it.hasNext())
    {
      GraphNode node = (GraphNode) (it.next());
      if (node.getName().equals(name))  //two NetNodes can not have the same name!!
        return node;
    }
    return null;
  }
  
  /*******************************************************************************/
  /**************************** REMOVE LINK **************************************/
  /*******************************************************************************/
  
  void removeLink(String name)
  {
    Iterator it=graphLinks.iterator();
    while(it.hasNext())
    {
      if (((GraphLink) (it.next())).getName().equals(name))  //two NetLinks can not have the same name!!
      {
        it.remove();
        break;
      }
    }
  }
  
  MouseTracker mouseTracker;
  Dimension size;
  Set nodes, links;
  HashSet graphNodes, graphLinks;
  Rectangle clip;
  NetLayoutStringBuilder builder;
  GraphState state;
}
