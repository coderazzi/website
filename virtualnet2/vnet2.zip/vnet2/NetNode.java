package vnet2;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Observable;


/**
  * Class to represent a node in the net. 
  * It is a node simulation of a machine (PC, Workstation), where any server
  * and clients can be running. In this simulation, a program can start (a
  * server is binded to the node, of a client uses the node), and the node can
  * fail down (the machine switch off or it just fails).
  * It implements the Observable function of the observer pattern.
  * Methods are not synchronized, any sinchronization must be achieved from outside!
  * @author LuisM Pena
  * @version 0.3, january-2001
  */
class NetNode extends Observable implements VirtualDevice
{

	/**
	  * @param id the identity of the node
	  **/	
	public NetNode(final NodeId id, final int delay)
	{
		this.id=id;
    this.delay = delay;
    links=new LinkedList();
    nextLink=0;
    valid=active=true;
    use=0;
	}
  
  public boolean equals(Object o)
  {
    return ((o instanceof NetNode) && ((NetNode)o).id.equals(id));
  }
  
  public int hashCode(){return id.hashCode();}
	public NodeId getId(){return id;}
  public int getDelay(){return delay;}
  public boolean isActive(){return active;}
  
  /**
    * Sets the delay
    **/  
  public void setDelay(int delay)
  {
    assert valid;
    this.delay=delay;    
  }
  
	/**
	  * Associates a new link.
	  **/	
	public synchronized void addLink(NetLink link)
	{
    assert valid;
    assert !links.contains(link);
    
		links.add(link);	
    nextLink=0;
	}
	
	/**
	  * Removes a link, that must be present. The safe way to remove a link
    * is by calling to the destroy method on the link itself, which will    
    * call in turn to this method
	  **/	
	public synchronized void removeLink(NetLink link)
	{
    assert valid;
    assert links.contains(link);
    
    links.remove(link);
    nextLink=0;
  }
	
  /**
    * Gets a link, or null if there are no links
    **/  
  public synchronized LinkId getALinkId()
  {
    assert valid;
    
    return links.size()==0? null : ((NetLink)(links.getFirst())).getId();
  }
  
  /**
    * Node is activated/deactivated
    **/  
  public synchronized void activate(boolean active)
  {
    assert valid;
    
    if (active!=this.active)
    {
      while(use>0)
        try{wait();}catch(InterruptedException ex){}
        
      this.active=active;
    
      setChanged();
      notifyObservers(active?VirtualDeviceEvent.getActivationEvent():VirtualDeviceEvent.getDeactivationEvent());
    }
    
   }

	/**
	  * Destructor of the node: no nodes can be associated to the node
	  * The observers of the node will receive a NodeDestroyedEvent notification
	  * The list of observers is cleared
	  * @exception VirtualNetException if the links fail to be cleared
	  * @see NetLink#destroy
	  * @see NodeDestroyedEvent
	  **/	
	public synchronized void destroy()
	{
    assert valid;
    assert links.size()==0;
    
		setChanged();
		notifyObservers(VirtualDeviceEvent.getDestroyedEvent());
		deleteObservers();
    
    valid=active=false;
 	}

  /**
    * Finds a virtual path to a given node
    * @param virtualPath data on the nodes already visited, that do not need to ve revisited
    * @returns the virtualPath found, or null if not way to the node
    */  
  public VirtualPath findPath(NetNode target, VirtualPath state)
  {
    //next code just tries to handle the (possible) concurrent modifications
    //that could happen on the links data
    VirtualPath ret=null;    
    if (setUse(true))
    {
      state.addDevice(this);

      setUse(false);
      
      if (this.equals(target))
        ret=state;        
      else 
      {
        //look for the link to use, starting from the last one used
        //When the last one is out of bounds or the list has been modified from
        //outside, the search is stopped, to start from the beginning.
        //It is possible that in this case several links are visited twice,
        //but it keeps the code (quite) simple.
        try
        {
          ret=findPath(target, state, links.listIterator(nextLink));
        }
        catch(ConcurrentModificationException ex) {ret=null;}
        catch(IndexOutOfBoundsException ex) {ret=null;}
        
        try
        {
          boolean onLoop=ret==null;
          while(onLoop && active)
            try { ret=findPath(target, state, links.listIterator(0)); onLoop=false;}
            catch(ConcurrentModificationException ex) {ret=null;}
        }
        catch(IndexOutOfBoundsException ex) {ret=null;}

        if (ret==null)
          state.removeDevice(this);
      }
    }
    return ret;
  }
  
  /**
    * Looks on the links pointed by the iterator, looking for a path.
    * It modifies nextLink automatically if a path is found
    * @exception ConcurrentModificationException if the list pointed out by the iterator
    * is modified during the search
    **/
  VirtualPath findPath(NetNode target, VirtualPath state, Iterator iterator)
    throws ConcurrentModificationException
  {
    while(active && iterator.hasNext())
    {
      NetLink link = (NetLink) (iterator.next());
      if (!state.containsDevice(link))
      {
        VirtualPath ret=link.findPath(target,state);
        if (ret!=null)
        {
          nextLink = links.indexOf(link)+1;//we could check if the index is out of bounds,
                                           //but that situation could change on the fly!
          return ret;
        }
      }
    }
    return null;
  }
  
  synchronized boolean setUse(boolean onUse)
  {
    if (active)
      if (onUse)
      {
        if (++use==1)//it is only sent the event when starts the use!
        {
          setChanged();
          notifyObservers(VirtualDeviceEvent.getStartUseEvent());
          notifyAll();  //activate method
        }
        try{Thread.currentThread().sleep(delay);}catch(InterruptedException ex){}
      }
      else if (--use==0)
      {
        setChanged();
        notifyObservers(VirtualDeviceEvent.getEndUseEvent());
        notifyAll(); //activate method
      }
      assert use>=0;
    return active;    
  }
  
	private NodeId id;
  private LinkedList links;
  private int nextLink;
  private boolean valid, active;
  private int use;
  private int delay;
}
