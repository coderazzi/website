/**
  * File: MouseAware.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

/**
  * Interface to be implemented by classes supporting mouse moving
  **/
interface MouseAware
{
  /**
    * Returns true if the coordinates refer to a point belonging to the class
    **/
  public boolean containsPoint(int x, int y);

  /**
    * Moves the object after a dragged mouse move
    **/
  public void draggedPoint(int x, int y);

  /**
    * Returns the name of the item
    **/
  public String getName();

  /**
    * Returns info on the item
    **/
  public String getInfo();
};
