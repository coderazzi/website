/**
  * File: GraphLinkLine.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Observable;
import java.util.Observer;

class GraphLinkLine implements Observer
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  public GraphLinkLine(Component parent, GraphNode node, GraphLink link, boolean prefVertical)
  {
    this.node = node;
    this.link = link;
    this.prefVertical = prefVertical;
    node.addObserver(this);
    link.addObserver(this);
    line1=new GraphSimpleLine(parent);
    line2=new GraphSimpleLine(parent);
    setLimits();
  }
  
  public void destroy()
  {
    if (link!=null)
    {
      link.deleteObserver(this);
      node.deleteObserver(this);
      line1.destroy();
      line2.destroy();
      link=null;
      node=null;
      line1=line2=null;
    }
  }
  
  public void draw(Graphics g)
  {
    if (line1!=null) 
    {
      line1.draw(g);
      line2.draw(g);
    }
  }
  
  public boolean clipsArea(Rectangle area)
  {
    return (line1!=null) && (line1.clipsArea(area) || line2.clipsArea(area));
  }
  
  public void update(Observable obs, Object what)
  {
    setLimits();
  }
  
  void setLimits()
  {
    Point a = node.getCentre();
    Point b = link.getCentre();
    if (prefVertical)
    {
      line1.set(a.x, a.y ,b.y - a.y, true);
      line2.set(b.x, b.y, a.x - b.x, false);
    }
    else
    {
      line1.set(a.x, a.y ,b.x - a.x, false);
      line2.set(b.x, b.y, a.y - b.y, true);
    }
  }
  
  GraphSimpleLine line1, line2;
  boolean prefVertical;
  GraphLink link;
  GraphNode node;
}
