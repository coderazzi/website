/**
  * File: VirtualNetSession.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  * Commnets:
  *       A VirtualNetSession operates on a received socket. The protocol is
  *       very simple. The session is started as:
  *        1- It receives the name of the node to host; this node is
  *            specified as an array of bytes, holding the first byte
  *            the number of bytes to read. The node name must be in
  *            UTF-8 format: byte�order specified by a mandatory initial byte-order mark.
  *        2- A byte is returned. Return value can be 0 to indicate success
  *            or FF to indicate error. In this case, a return value of
  *            FF means that the node given is not existing in the current
  *            netlayout. This is not a real error, further requests are
  *            still valid.
  *        After this session is started, each new request must just
  *            contain the target node, and the return value will indicate
  *            wether there is a virtual path bertween both nodes or not.
  *        The format is the same as for the session creation:
  *        3- The name of the target node, in the same format as given
  *            by the first message.
  *        4- The return value contains 0 if a path exists and FF if not.
  *
  *        This specification can change to show some extended information
  *        about the error. For example FE could mean that there is no
  *        virtual path because the target node does not exist, etc.
  *        Anycase, a value 0 will always means success and any other
  *        value is an error flag
  **/

package vnet2;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
  
/**
  * Class implementing each session with the VirtualNet
  **/
public class VirtualNetSession extends Thread
{

  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * A VirtualNetSession operates on a received socket. It needs as well
    * the layout to operate on and the maximum shutdownTime
    **/
  public VirtualNetSession(VirtualNetUser user, VirtualNetServer owner, 
                           NetLayout layout, Socket socket, int maxShutdownTime)
  {
    this.owner = owner;
    this.user = user;
    this.layout=layout;
    this.socket=socket;
    this.maxShutdownTime = maxShutdownTime;
    
    message=new byte[MAX_BYTE];
    node=null;
    running=true;
    start();
  }
  
  /*******************************************************************************/
  /**************************** RUN **********************************************/
  /*******************************************************************************/
  
  /**
    * Thread method
    **/
  public void run()
  {
    InputStream input=null;
    OutputStream output=null;
    byte result[]=new byte[1];
    try
    {
      socket.setSoTimeout(maxShutdownTime);
      input=socket.getInputStream();
      output=socket.getOutputStream();
      while(running)
      {
        try
        {
          result[0] = handleSession(input);
          if (running)
            output.write(result);
        }
        catch(java.io.InterruptedIOException ex)
        {
          //ok, do not do anything (caused by setSoTimeout)
        }
      }
    }
    catch(Exception ex) //SocketException, IOException
    {
      user.virtualNetSessionError(ex.getMessage(), node);
    }
    finally
    {
      if (input!=null) try{input.close();}catch(IOException ex){}
      if (output!=null) try{output.close();}catch(IOException ex){}
    }
    
    user.virtualNetSessionEnded(node);
    owner.sessionEnded(this);
    
    layout=null;
    owner=null;
    user=null;
    node=null;
    socket=null;
    message=null;
  }
  
  /*******************************************************************************/
  /**************************** STOP SESSION *************************************/
  /*******************************************************************************/
  
  /**
    * Stops the session activity
    **/
  public void stopSession()
  {
    running=false;
  }
  
  /*******************************************************************************/
  /**************************** HANDLE SESSION ***********************************/
  /*******************************************************************************/
  
  /**
    * Handles an incoming session
    **/
  byte handleSession(InputStream input) throws IOException
  {
    byte ret=ERROR;
    if (readInput(input,1))
    {
      int len=message[0];
      if (len>0 && readInput(input,len))
      {
        ret=handleInputNode(new NodeId(new String(message,0,len,"UTF-8")));
      }
    }
    return ret;
  }
  
  /*******************************************************************************/
  /**************************** HANDLE INPUT NODE ********************************/
  /*******************************************************************************/
  
  /**
    * Handles the node received on the message
    **/
  byte handleInputNode(NodeId inputNode)
  {
    byte ret=ERROR;
    if (node==null)
    {
      node=inputNode;
      user.virtualNetSessionStarted(node);
      if (layout.containsNode(node))
        ret=SUCCESS;
    }
    else
    {
      if (existsVirtualPath(inputNode, node))
        ret=SUCCESS;
    }
    return ret;
  }
  
  /*******************************************************************************/
  /**************************** EXISTS VIRTUAL PATH ******************************/
  /*******************************************************************************/
  
  /**
    * Checks when there is a virtual path between the specified nodes
    **/
  boolean existsVirtualPath(NodeId nodeA, NodeId nodeB) 
  {
    VirtualPath path=layout.getVirtualPath(nodeA, nodeB);
    
    user.virtualPathQueried(nodeA, nodeB, path!=null);
    
    return path!=null;
  }
  
  /*******************************************************************************/
  /**************************** READ INPUT ***************************************/
  /*******************************************************************************/
  
  /**
    * Reads the input, returning true if the operation is successful. The 
    * result is placed into 'message'
    **/
  boolean readInput(InputStream input, int len) throws IOException
  {
    assert len>0 && len<=MAX_BYTE;
    return (input.read(message,0,len)==len) && running;
  }
  
  /*******************************************************************************/
  /*******************************************************************************/
  /*******************************************************************************/
  
  boolean running;
  NetLayout layout;
  Socket socket;  
  VirtualNetServer owner;
  VirtualNetUser user;
  byte message[];
  NodeId node;
  final int maxShutdownTime;
  final static byte SUCCESS=0;
  final static byte ERROR=(byte)0xFF;
  final static int MAX_BYTE=Byte.MAX_VALUE;
}
