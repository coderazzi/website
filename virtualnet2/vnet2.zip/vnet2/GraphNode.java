/**
  * File: GraphNode.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Component;
import java.awt.Point;
import javax.swing.ImageIcon;
import java.util.Observable;
import java.util.Observer;

/**
  * Graphical peer of a NetNode (its graphical representation is a circle)
  * It manages the events lunched by a netNode, and is able to draw itself.
  * When its position changes, it sends notification events to signal that
  * change. The notification just includes the GraphNode itself
  */
class GraphNode extends GraphDevice implements Observer
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * A Node needs to know the component where must be drawn, and the
    * name of the backed up node. It will receive automatically
    * events from that node. It needs as well a start position and its
    * size. The start position is given by the centre of the node.
    **/
  public GraphNode(Component parent, NetNode node, Point centre)
  {
    super(parent, node.getId().toString(), centre, node.isActive()? nodeActive : nodeDeactivated, imagenWidth, imagenHeight);
    
    this.node = node;
    node.addObserver(this);
    valid=true;
    info=new StringBuffer();
  }
  
  public void destroy()
  {
    super.destroy();
    deleteObservers();
    node.deleteObserver(this);
    node=null;
  }
  
  public boolean equals(Object o)
  {
    return ((o instanceof GraphNode) && ((GraphNode)o).node.equals(node));
  }
  
  public int hashCode()
  {
    return node.hashCode();
  }
  
  public NetNode getNode(){return node;}
  
  public void translate(double x, double y)
  {
    moveTo(x*centre.getX(), y*centre.getY());
  }
  
  /**
    * Through this interface they are received the new nodes and links
    **/
  public synchronized void update(Observable obs, Object what)
  {
    if (what==VirtualDeviceEvent.getDestroyedEvent())
      destroy();
    else if (what==VirtualDeviceEvent.getStartUseEvent())
      setImage(nodeInUse);
    else if (what==VirtualDeviceEvent.getEndUseEvent())
      setImage(nodeActive);
    else if (what==VirtualDeviceEvent.getActivationEvent())
      setImage(nodeActive);
    else if (what==VirtualDeviceEvent.getDeactivationEvent())
      setImage(nodeDeactivated);
  }
  
  public String getInfo()
  {
    info.setLength(0);
    info.append(node.isActive()? "Active node " : "Deactivated node ").append(getName());
    info.append(" with delay = ").append(node.getDelay());
    return info.toString();
      
  }
  
  boolean valid;
  NetNode node;
  StringBuffer info;
  
  static ImageIcon nodeActive = GraphResources.getGraphResources().getImage(GraphResources.NODE_ACTIVE);
  static ImageIcon nodeDeactivated = GraphResources.getGraphResources().getImage(GraphResources.NODE_DEACTIVATED);
  static ImageIcon nodeInUse = GraphResources.getGraphResources().getImage(GraphResources.NODE_USED);
  static int imagenWidth = GraphResources.getGraphResources().getWidth(GraphResources.NODE_ACTIVE);
  static int imagenHeight= GraphResources.getGraphResources().getHeight(GraphResources.NODE_ACTIVE);
}
