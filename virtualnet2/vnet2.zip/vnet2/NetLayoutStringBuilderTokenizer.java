/**
  * File: NetLayoutStringBuilderToken.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class NetLayoutStringBuilderTokenizer
{
  
  public class DelayNode
  {
    public String node;
    public int delay;
    DelayNode(String n, int d){node=n; delay=d;}
  };
  
  public class DelayLink
  {
    public String link;
    public int delay;
    DelayLink(String l, int d){link=l; delay=d;}
  };
  
  public class RemoveNode
  {
    public String node;
    RemoveNode(String n){node=n;}
  }
  
  public class RemoveLink
  {
    public String link;
    RemoveLink(String l){link=l;}
  }
  
  public class ActivateNode
  {
    public boolean activate;
    public String node;
    ActivateNode(String n, boolean a){node=n;activate=a;}
  }
  
  public class ActivateLink
  {
    public boolean activate;
    public String link;
    ActivateLink(String l, boolean a){link=l;activate=a;}
  }
  
  public class CreateNode
  {
    public int delay;
    public String node;
    CreateNode(String n, int d){node=n;delay=d;}
  }
  
  public class CreateLink
  {
    public String link;
    public String nodeA, nodeB;
    public int delay;
    public boolean bidirectional;
    CreateLink(String l, String a, String b, int d, boolean bi){link=l;nodeA=a;nodeB=b;delay=d;bidirectional=bi;}
  }
  
  /**
    * Constructor requires the NetLayoutBuilder to use
    **/
  public Iterator process(String string)  throws BuilderException
  {
    ids.clear();
    tokens.clear();
    parseBasicTokens(new StringCharacterIterator(string));
    createLexTokens();
    LinkedList compiled=getFinalTokens();
    ids.clear();
    tokens.clear();
    return compiled.iterator();
  }
  
  LinkedList getFinalTokens() throws BuilderException
  {
    LinkedList compiled=new LinkedList();
    ListIterator itTokens=tokens.listIterator();
    ListIterator itIds=ids.listIterator();
    while(itTokens.hasNext())
    {
      String next=(String) itTokens.next();
      if (next==LEX_DODELAY)
        compiled.addLast(new DelayNode(null, getDelay(itTokens, itIds, Consts.DEFAULT_NODES_DELAY)));
      else if (next==LEX_DOLINKDELAY)
        compiled.addLast(new DelayLink(null, getDelay(itTokens, itIds, Consts.DEFAULT_LINKS_DELAY)));
      else if (!itIds.hasNext())
        errorByTokenNotExpected(itTokens.nextIndex());
      else
      {
        String id=(String) itIds.next();
        if (next==LEX_DODELAY_NODE_ID)
          compiled.addLast(new DelayNode(id, getDelay(itTokens, itIds, Consts.DEFAULT_NODES_DELAY)));
        else if (next==LEX_DODELAY_LINK_ID)
          compiled.addLast(new DelayLink(id, getDelay(itTokens, itIds, Consts.DEFAULT_LINKS_DELAY)));
        else if (next==LEX_REMOVE_LINK_ID)
          compiled.addLast(new RemoveLink(id));
        else if (next==LEX_REMOVE_NODE_ID)
          compiled.addLast(new RemoveNode(id));
        else if (next==LEX_ACTIVATE_LINK_ID)
          compiled.addLast(new ActivateLink(id, true));
        else if (next==LEX_ACTIVATE_NODE_ID)
          compiled.addLast(new ActivateNode(id, true));
        else if (next==LEX_DEACTIVATE_LINK_ID)
          compiled.addLast(new ActivateLink(id, false));
        else if (next==LEX_DEACTIVATE_NODE_ID)
          compiled.addLast(new ActivateNode(id, false));
        else if (next==LEX_CREATION_ID)
          compiled.addLast(new CreateNode(id, getDelay(itTokens, itIds, Consts.DEFAULT_NODES_DELAY)));
        else if (next==LEX_CREATION_LINK_ID)
        {
          String nodeA=id;
          id=(String) itIds.next();
          int delay=getDelay(itTokens, itIds, Consts.DEFAULT_LINKS_DELAY);
          if (itTokens.hasNext())
          {
            next=(String) itTokens.next();
            if (next==LEX_LINK_ID || next==LEX_BILINK_ID)
              compiled.addLast(new CreateLink(id, nodeA, (String) itIds.next(), delay, next==LEX_BILINK_ID));
            else
              errorByTokenNotExpected(itTokens.nextIndex()-1);
          }
          else
            errorByTokenNotExpected(itTokens.nextIndex());
        }
        else
          errorByTokenNotExpected(itTokens.nextIndex()-1);
      }
    }
    return compiled;
  }
  
  int getDelay(ListIterator tokens, ListIterator ids, int defaultDelay)  throws BuilderException
  {
    int ret=defaultDelay;
    if (tokens.hasNext())
    {
      if (tokens.next()==LEX_DELAY)
      {
        String delay=(String) (ids.next());
        try
        {
          ret=Integer.valueOf(delay).intValue();
        }
        catch(NumberFormatException ex)
        {
          ret=-1;
        }
        if (ret<0)
          throw new BuilderException(delay + " is not a valid delay number");
      }
      else
        tokens.previous();
    }
    return ret;
  }
  
  void createLexTokens() throws BuilderException
  {
    reduceTokens(TOK_PLUS, TOK_ACTIVATION, TOK_ACTIVATE_NODE);
    reduceTokens(TOK_ACTIVATE_NODE, TOK_LINK, TOK_ACTIVATE_LINK);
    reduceTokens(TOK_MINUS, TOK_ACTIVATION, TOK_DEACTIVATE_NODE);
    reduceTokens(TOK_DEACTIVATE_NODE, TOK_LINK, TOK_DEACTIVATE_LINK);
    reduceTokens(TOK_MINUS, TOK_LINK, TOK_REMOVE_LINK);
    reduceTokens(LEX_DODELAY, TOK_LINK, LEX_DOLINKDELAY);
    reduceTokens(TOK_LEFTPAR, TOK_ID, TOK_LEFTDELAY);
    
    reduceTokensMandatory(TOK_LEFTDELAY, TOK_RIGHTPAR, LEX_DELAY);
    reduceTokensMandatory(TOK_PLUS, TOK_ID, LEX_CREATION_ID);
    reduceTokensMandatory(TOK_MINUS, TOK_ID, LEX_REMOVE_NODE_ID);
    reduceTokensMandatory(TOK_LINK, TOK_ID, LEX_LINK_ID);
    reduceTokensMandatory(TOK_BILINK, TOK_ID, LEX_BILINK_ID);
    reduceTokensMandatory(TOK_ACTIVATE_NODE, TOK_ID, LEX_ACTIVATE_NODE_ID);
    reduceTokensMandatory(TOK_ACTIVATE_LINK, TOK_ID, LEX_ACTIVATE_LINK_ID);
    reduceTokensMandatory(TOK_DEACTIVATE_NODE, TOK_ID, LEX_DEACTIVATE_NODE_ID);
    reduceTokensMandatory(TOK_DEACTIVATE_LINK, TOK_ID, LEX_DEACTIVATE_LINK_ID);
    reduceTokensMandatory(TOK_REMOVE_LINK, TOK_ID, LEX_REMOVE_LINK_ID);

    reduceTokens(LEX_CREATION_ID, LEX_LINK_ID, LEX_CREATION_LINK_ID);
    reduceTokens(LEX_DODELAY, TOK_ID, LEX_DODELAY_NODE_ID);
    reduceTokens(LEX_DOLINKDELAY, TOK_ID, LEX_DODELAY_LINK_ID);
  }
  
  String buildBaseForm(int topIndex)
  {
    StringBuffer buf=new StringBuffer();
    ListIterator it=tokens.listIterator(0);
    while(it.hasNext() && (it.nextIndex()<topIndex))
      buf.append((String) (it.next()));
    it=ids.listIterator(0);
    int from=0;
    while(it.hasNext())
      if ((from=replaceId(buf, from, (String) it.next()))==-1)
        break;
    return buf.toString();
  }
  
  int replaceId(StringBuffer buf, int from, String id)
  {
    String where=buf.toString();
    int ret=where.indexOf("id",from);
    int delay=where.indexOf("delay",from);
    int how=5;
    if (ret==-1)
      ret=delay;
    else if ((delay!=-1) && (delay<ret))
      ret=delay;
    else
      how=2;
    if (ret!=-1)
    {
      buf.replace(ret,ret+how,id);
      ret+=id.length();
    }
    return ret;
  }
  
  void errorByTokenNotExpected(int topIndex) throws BuilderException
  {
    throw new BuilderException("Error after \"" + buildBaseForm(topIndex) + "\"");
  }
  
  void errorByTokenNotExpected(int topIndex, String expectedToken) throws BuilderException
  {
    throw new BuilderException("Error: it is expected \"" + expectedToken + "\" after \"" + buildBaseForm(topIndex) + "\"");
  }

  
  /**
    * Looks in the the tokens list for the tokenA followed by tokenB, replacing them with newToken
    * There can not be any tokenA not followed by token B
    **/
  void reduceTokensMandatory(String tokenA, String tokenB, String newToken)  throws BuilderException
  {
    ListIterator it=tokens.listIterator(0);
    while(it.hasNext())
      {
        String current = (String) (it.next());
        if (tokenA==current)
          if (!it.hasNext())
            errorByTokenNotExpected(it.nextIndex(), tokenB);
          else if ((String)(it.next())!=tokenB)
            errorByTokenNotExpected(it.nextIndex()-1, tokenB);
          else
          {
            it.remove();
            it.previous();
            it.remove();
            it.add(newToken);
          }
      }
  }
  
  /**
    * Looks in the the tokens list for the tokenA followed by tokenB, replacing them with newToken
    **/
  void reduceTokens(String tokenA, String tokenB, String newToken)
  {
    String previous = null;
    ListIterator it=tokens.listIterator(0);
    while(it.hasNext())
      {
        String current = (String) (it.next());
        if (tokenB==current && tokenA==previous)
        {
          previous=null;
          it.remove();
          it.previous();
          it.remove();
          it.add(newToken);
        }
        else
          previous=current;
      }
  }
  
  void parseBasicTokens(StringCharacterIterator chain)
  {
    for (char c= chain.first(); c!= StringCharacterIterator.DONE; c=chain.next())
    {
      if (validChar(c))
      {
        String token=getBasicToken(c);
        tokens.addLast(token);
        if (token==TOK_ID)
          ids.addLast(parseIdToken(chain));
      }
    }
  }
  
  boolean validChar(char c)
  {
    return !Character.isWhitespace(c);
  }
  
  String parseIdToken(StringCharacterIterator chain)
  {
    StringBuffer id=new StringBuffer();
    for(char c= chain.current(); c != StringCharacterIterator.DONE; c=chain.next())
    {
      if ((getBasicToken(c)!=TOK_ID) || !validChar(c))
      {
        chain.previous();
        break;
      }
      else
        id.append(c);
    }
    return id.toString();
  }
  
  String getBasicToken(char c)
  {
    switch(c)
    {
      case '+': return TOK_PLUS;
      case '-': return TOK_MINUS;
      case '.': return TOK_ACTIVATION;
      case '<': return TOK_LINK;
      case '>': return TOK_BILINK;
      case '/': return LEX_DODELAY;
      case '(': return TOK_LEFTPAR;
      case ')': return TOK_RIGHTPAR;
    }
    return TOK_ID;
  }
  
  LinkedList ids = new LinkedList();
  LinkedList tokens = new LinkedList();

  //basic tokens
  private final static String TOK_PLUS = new String("+");
  private final static String TOK_MINUS = new String("-");
  private final static String TOK_ACTIVATION = new String(".");
  private final static String TOK_LINK = new String("<");
  private final static String TOK_BILINK = new String(">");
  private final static String LEX_DODELAY = new String("/");
  private final static String TOK_LEFTPAR = new String("(");
  private final static String TOK_RIGHTPAR = new String(")");
  private final static String TOK_ID = new String("id");
  //compound ones
  private final static String TOK_ACTIVATE_NODE = new String("+.");
  private final static String TOK_ACTIVATE_LINK = new String("+.<");
  private final static String TOK_DEACTIVATE_NODE = new String("-.");
  private final static String TOK_DEACTIVATE_LINK = new String("-.<");
  private final static String TOK_REMOVE_LINK = new String("-<");
  private final static String TOK_LEFTDELAY = new String("(delay"); 

  private final static String LEX_DOLINKDELAY = new String("/<");
  private final static String LEX_DELAY = new String("(delay)");             
  private final static String LEX_CREATION_ID = new String("+id"); 
  
  private final static String LEX_REMOVE_NODE_ID = new String("-id"); 
  private final static String LEX_LINK_ID = new String("<id"); 
  private final static String LEX_BILINK_ID = new String(">id"); 
  private final static String LEX_ACTIVATE_NODE_ID = new String("+.id");
  private final static String LEX_ACTIVATE_LINK_ID = new String("+.<id");
  private final static String LEX_DEACTIVATE_NODE_ID = new String("-.id");
  private final static String LEX_DEACTIVATE_LINK_ID = new String("-.<id");
  private final static String LEX_REMOVE_LINK_ID = new String("-<id");
  private final static String LEX_CREATION_LINK_ID = new String("+id<id"); 
  private final static String LEX_DODELAY_NODE_ID = new String("/id");
  private final static String LEX_DODELAY_LINK_ID = new String("/<id");
}
