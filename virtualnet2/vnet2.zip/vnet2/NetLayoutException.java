/**
  * File: BuilderException.java
  * @author LuisM Pena
  * @version 0.3, february-2001
  **/

package vnet2;

class NetLayoutException extends Exception
{
  public NetLayoutException(String reason)
  {
    super(reason);
  }
}
