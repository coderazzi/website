/**
  * File: VirtualNet.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.io.FileInputStream;
import java.util.Properties;
  
/**
  * Class implementing the external interface to the virtual net logic
  **/
public class VirtualNet implements VirtualNetUser
{

  /*******************************************************************************/
  /************************* CONSTRUCTOR *****************************************/
  /*******************************************************************************/
  
  public VirtualNet(String file, boolean verbose, boolean overrideSocket, int socket)
  {
    this.verbose=verbose;
    FileInputStream stream=null;
    try
    {
      stream = new FileInputStream(file);
      Properties properties=new Properties();
      properties.load(stream);
      if (!overrideSocket)
        socket=NetLayoutPropertiesBuilder.readUnsigned(properties,Consts.FILE_SOCKET, true, 0);
      new VirtualNetServer(this, new NetLayoutPropertiesBuilder().loadLayout(properties), socket, 0);
    }
    catch(Exception ex)
    {
      System.out.println(ex.getMessage());
    }
    finally
    {
      if (stream!=null)
        try{stream.close();}catch(Exception ex){}
    }
  }
  
//*************************************************************************************//
//**************************** VIRTUAL NET USER INTERFACE *****************************//
//*************************************************************************************//
  
  public void virtualNetServerError(String msg)
  {
    System.out.println("VirtualNetServer error : " + msg);
  }

  public void virtualNetServerEnded()
  {
    System.out.println("VirtualNetServer is shutdown");
  }

  public void virtualNetSessionError(String error, NodeId node)
  {
    if (verbose || node==null)
      System.out.println("VirtualNetSession error : " + error);
  }

  public void virtualNetSessionStarted(NodeId node)
  {
    if (verbose) System.out.println("VirtualNetSession started on node: " + node);
  }
  
  public void virtualPathQueried(NodeId source, NodeId target, boolean success)
  {
    if (verbose) System.out.println("Founding virtual path between " + source + " and " + target + ((success)? " : Found": " : NOT found"));
  }
  
  public void virtualNetSessionEnded(NodeId node)
  {
    if (verbose && node!=null) System.out.println("VirtualNetSession ended on node: " + node);
  }
  
  /*******************************************************************************/
  /*******************************************************************************/
  /*******************************************************************************/
  
  boolean verbose;
  
  /*******************************************************************************/
  /************************* HELP ************************************************/
  /*******************************************************************************/
  
  static void help(String error)
  {
    if (error!=null)
      System.out.println(error);
    System.out.println("Use [-help] [-nograph] [-verbose] [-port=xxx] file");
    System.exit(1);
  }
  
  /*******************************************************************************/
  /************************** MAIN ***********************************************/
  /*******************************************************************************/
  
  public static void main(String args[])
  {
    boolean verbose=false;
    boolean noGraph=false;
    boolean specialSocket=false;
    String file=null;
    
    int socket=0;
    
    for (int i=0; i<args.length;i++)
    {
      if (args[i].equals("-help"))
        help(null);
      else if (args[i].equals("-nograph"))
      {
        if (noGraph)
          help("-nograph option already included");
        else
          noGraph=true;
      }
      else if (args[i].equals("-verbose"))
      {
        if (verbose)
          help("-verbose option already included");
        else
          verbose=true;
      }
      else if (args[i].startsWith("-port="))
      {
        if (specialSocket)
          help("-port option already included");
        else
        {
          try
          {
            socket=Integer.parseInt(args[i].substring(args[i].indexOf('=')+1));
            specialSocket=true;
          }
          catch(NumberFormatException nex)
          {
            help("port not valid");
          }
        }
      }
      else if ((i+1)!=args.length)
        help("Only one file is allowed");
      else
        file=args[i];
    }
    
    if (file==null && specialSocket)
      help("Port option has only sense when a file is specified");

    if (noGraph)
      new VirtualNet(file, verbose, specialSocket, socket);
    else
      new VnetFrame(file, verbose, specialSocket, socket);
  }  
}
