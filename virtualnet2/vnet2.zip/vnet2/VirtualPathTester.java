/**
  * File: VirtualPathTester.java
  * @author LuisM Pena
  * @version 0.3, february-2000
  **/

package vnet2;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
  * Active class to test virtual paths 
  **/
public class VirtualPathTester extends Thread
{
  public VirtualPathTester(Component parent, NetLayout net)
  {  
    this.parent = parent;
    this.net = net;
    start();
  }
  
//*************************************************************************************//
//**************************** RUN ****************************************************//
//*************************************************************************************//
  
  public void run()
  {
    String input=JOptionPane.showInputDialog(parent, "Please introduce nodes to connect (like A-B)");
    if (input!=null)
    {
      int minus=input.indexOf('-');
      if (minus==-1)
        message("Nodes must be separated by character '-'", true);
      else
      {
        NodeId nodeA=new NodeId(input.substring(0,minus));
        NodeId nodeB=new NodeId(input.substring(minus+1));
        VirtualPath path=net.getVirtualPath(nodeA, nodeB);
        if (path==null)
          message("No virtual path found between \""+nodeA+"\" and \""+nodeB+"\"", false);
        else
          message("Nodes \""+nodeA+"\" and \""+nodeB+"\" are connected", false);
      }
    }
  }
  
//*************************************************************************************//
//**************************** MESSAGE ************************************************//
//*************************************************************************************//
  
  void message(String message, boolean isError)
  {
    JOptionPane.showMessageDialog(parent,message,"testing virtual paths",isError?JOptionPane.ERROR_MESSAGE:JOptionPane.INFORMATION_MESSAGE);
  }
  
  Component parent;
  NetLayout net;
};
