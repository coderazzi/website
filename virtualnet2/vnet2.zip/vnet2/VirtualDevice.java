package vnet2;

/**
  * Interface to be implemented by the classes simulating devices
  * on the virtual net
  * @author LuisM Pena
  * @version 0.30, january-2001
  */
interface VirtualDevice
{
};
