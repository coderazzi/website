/**
  * File: GraphLinkLine.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Observable;
import java.util.Observer;

class GraphSimpleLine
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  public GraphSimpleLine(Component parent)
  {
    this.parent=parent;
    visible=false;
  }
  
  public void set(int newOriginX, int newOriginY, int size, boolean vertical)
  {
    if (parent!=null)
    {
      int x0,y0,w0,h0;
      boolean repaintOld=visible;
      x0=x;
      y0=y;
      w0=w;
      h0=h;

      this.vertical=vertical;
      visible=size!=0;
      if (visible)
      {
        if (vertical)
        {
          x=newOriginX;
          w=0;
          if (size<0)
          {
            y=newOriginY+size;
            h=-size;
          }
          else
          {
            y=newOriginY;
            h=size;
          }
        }
        else
        {
          h=0;
          y=newOriginY;
          if (size<0)
          {
            x=newOriginX+size;
            w=-size;
          }
          else
          {
            x=newOriginX;
            w=size;
          }
        }
        parent.repaint(x, y, w+1, h+1);
      }
      if (repaintOld)
      {
        parent.repaint(x0, y0, w0+1, h0+1);
      }
    }
  }
  
  public void draw(Graphics g)
  {
    if (visible)
    {
      g.drawLine(x, y, x+w, y+h);
    }
  }
  
  public boolean clipsArea(Rectangle r)
  {
    return (visible) && r.intersects(x,y,w+1,h+1);
  }
  
  public void destroy()
  {
    visible=false;
    parent.repaint(x, y, w+1, h+1);
    parent=null;
  }

  Component parent;
  int x, y, w, h;
  boolean vertical;
  boolean visible;
}
