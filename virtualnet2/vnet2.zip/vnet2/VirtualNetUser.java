/**
  * File: VirtualNetUser.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

/**
  * Interface to be implemented by VirtualNet users
  **/
public interface VirtualNetUser
{
  /**
    * Called when an error is raised in the VirtualNetServer.
    * This means a fatal error!
    **/
  public void virtualNetServerError(String message);

  /**
    * Called when the virtual net ends completely its activity
    **/
  public void virtualNetServerEnded();

  /**
    * Called when a new session is started, givin the node id
    **/
  public void virtualNetSessionStarted(NodeId node);

  /**
    * Called to inform on a virtual path query
    **/
  public void virtualPathQueried(NodeId source, NodeId target, boolean success);

  /**
    * Called when a session is ended
    **/
  public void virtualNetSessionEnded(NodeId node);

  /**
    * Called after an error on a virtual net session. If the session is not
    * started, node will be null
    **/
  public void virtualNetSessionError(String error, NodeId node);

}
