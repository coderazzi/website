package vnet2;

/**
  * Class to represent a link identity
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see NetLink
  */
public class LinkId
{
	/**
    * @param id the string representing the node
	  */
	public LinkId(String idString)
	{
    id=new String(idString);
	}

	/**
	  * @param element other Linkd to be compared to
	  * @return true if bot have the same identity
	  */
	public boolean equals(Object element)
	{
    return (element instanceof LinkId) && (id.equals(((LinkId)element).id));
	}

	/**
	  * @return a valid hash code
	  */
	public int hashCode()
	{
    return id.hashCode();
	}
	
	/**
	  * @return a printable form of the LinkId
	  */
	public String toString()
	{
    return id;
	}
  
  /**
    * @return the identity
    */
  public String getId()
  {
    return id;
  }

  private String id;
}
