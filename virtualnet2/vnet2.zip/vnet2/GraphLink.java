/**
  * File: GraphLink.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import javax.swing.ImageIcon;
import java.util.Observable;
import java.util.Observer;

/**
  * Graphical peer of a NetNode (its graphical representation is a circle)
  * It manages the events launched by a netLink, and is able to draw itself.
  * When its position changes, it sends notification events to signal that
  * change. The notification just includes the GraphNode itself
  */
class GraphLink extends GraphDevice implements Observer
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * A Node needs to know the component where must be drawn, and the
    * name of the backed up node. It will receive automatically
    * events from that node. It needs as well a start position and its
    * size. The start position is given by the centre of the node.
    **/
  public GraphLink(Component parent, NetLink link, GraphNode nodeA, GraphNode nodeB, Point centre)
  {
    super(parent, link.getId().toString(), centre, 
          link.isBidirectional()? slinkActive : slinkMonoActive, 
          link.isBidirectional()? simagenWidth : simagenMonoWidth, 
          link.isBidirectional()? simagenHeight : simagenMonoHeight);
    
    this.link = link;
    link.addObserver(this);
    lineA=new GraphLinkLine(parent, nodeA, this, true);
    lineB=new GraphLinkLine(parent, nodeB, this, false);
    point = new Point();
    valid=true;
    info=new StringBuffer();

    if (link.isBidirectional())
    {
      linkActive = slinkActive;
      linkDeactivated = slinkDeactivated;
      linkInUse = slinkInUse;
      staticInfo=new String(" link " + getName() + ", bidirectional between " + 
        nodeB.getName() + " and " + nodeA.getName() + " with delay = ");
    }
    else
    {
      linkActive = slinkMonoActive;
      linkDeactivated = slinkMonoDeactivated;
      linkInUse = slinkMonoInUse;
      staticInfo=new String(" link " + getName() + ", monodirectional from " + 
        nodeB.getName() + " to " + nodeA.getName() + " with delay = ");
    }
    if (!link.isActive())
      setImage(linkDeactivated);
  }
  
  static Point getMiddleCentre(Point holder, Point a, Point b)
  {
    holder.setLocation((a.getX()+b.getX())/2, (a.getY()+b.getY())/2);
    return holder;
  }
  
  public void destroy()
  {
    if (link!=null)
    {
      super.destroy();
      deleteObservers();
      link.deleteObserver(this);
      lineA.destroy();
      lineB.destroy();
      link=null;
      lineA=lineB=null;
      point=null;
    }
  }
  
  public boolean equals(Object o)
  {
    return ((o instanceof GraphLink) && ((GraphLink)o).link.equals(link));
  }
  
  public int hashCode()
  {
    return link.hashCode();
  }
  
  public NetLink getLink() { return link; }
  
  public void draw(Graphics g)
  {
    if (lineA!=null) 
    {
      lineA.draw(g);
      lineB.draw(g);
      super.draw(g);
    }
  }
  
  public boolean clipsArea(Rectangle area)
  {
    return (lineA!=null) && (super.clipsArea(area) || lineA.clipsArea(area) || lineB.clipsArea(area) );
  }
  
  /**
    * Through this interface they are received the new nodes and links
    **/
  public synchronized void update(Observable obs, Object what)
  {
    if (what==VirtualDeviceEvent.getDestroyedEvent())
      destroy();
    else if (what==VirtualDeviceEvent.getStartUseEvent())
      setImage(linkInUse);
    else if (what==VirtualDeviceEvent.getEndUseEvent())
      setImage(linkActive);
    else if (what==VirtualDeviceEvent.getActivationEvent())
      setImage(linkActive);
    else if (what==VirtualDeviceEvent.getDeactivationEvent())
      setImage(linkDeactivated);
  }
  
  public String getInfo()
  {
    info.setLength(0);
    info.append(link.isActive()? "Active " : "Deactivated ").append(staticInfo).append(link.getDelay());
    return info.toString();
  }
  
  boolean valid;
  NetLink link;
  GraphLinkLine lineA, lineB;
  Point point;
  ImageIcon linkActive, linkDeactivated, linkInUse;
  StringBuffer info;
  String staticInfo;
  
  static ImageIcon slinkActive = GraphResources.getGraphResources().getImage(GraphResources.LINK_ACTIVE);
  static ImageIcon slinkDeactivated = GraphResources.getGraphResources().getImage(GraphResources.LINK_DEACTIVATED);
  static ImageIcon slinkInUse = GraphResources.getGraphResources().getImage(GraphResources.LINK_USED);
  static ImageIcon slinkMonoActive = GraphResources.getGraphResources().getImage(GraphResources.LINK_MONO_ACTIVE);
  static ImageIcon slinkMonoDeactivated = GraphResources.getGraphResources().getImage(GraphResources.LINK_MONO_DEACTIVATED);
  static ImageIcon slinkMonoInUse = GraphResources.getGraphResources().getImage(GraphResources.LINK_MONO_USED);
  static int simagenWidth = GraphResources.getGraphResources().getWidth(GraphResources.LINK_ACTIVE);
  static int simagenHeight= GraphResources.getGraphResources().getHeight(GraphResources.LINK_ACTIVE);
  static int simagenMonoWidth = GraphResources.getGraphResources().getWidth(GraphResources.LINK_MONO_ACTIVE);
  static int simagenMonoHeight= GraphResources.getGraphResources().getHeight(GraphResources.LINK_MONO_ACTIVE);
}
