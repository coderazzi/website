/**
  * File: NetLayout.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;
  
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Observable;
import java.util.Set;

/**
  * Class to represent the virtual net layout
  * It is a representation of nodes (machines) and links (communication channels)
  * where any node or link can fail.
  * It implements the Observable function of the observer pattern, sending
  * creation events when a new node or link is created
  **/
class NetLayout extends Observable
{

/**
  * Default constructor
  **/
	public NetLayout()	
	{
	}
  
/**
  * Returns the virtual path between two nodes, if existing
  **/
  public VirtualPath getVirtualPath(NodeId idA, NodeId idB)
  {
    NetNode nodeA=(NetNode) nodes.get(idA);
    NetNode nodeB=(NetNode) nodes.get(idB);
    VirtualPath path;
    if (nodeA==null || nodeB==null)
      path=null;
    else
      path = nodeA.findPath(nodeB, new VirtualPath());
    return path;
  }
	
/**
  * Inserts a new node in the net, with the specified delay
  * The observers of the netlayout will receive a notification,
  * given by the created node
  * @param id the Node identity
  * @param delay the expected delay
  * @returns false if the node already exists
  **/
	public synchronized void addNode(NodeId id, int delay) throws NetLayoutException
	{
    if (nodes.containsKey(id))
      throw new NetLayoutException("AddNode : node already existing: " + id.getId());

    NetNode node=new NetNode(id,delay);
		nodes.put(id,node);
      
		setChanged();
		notifyObservers(node);
	}
	
/**
  * Removes a Node out of the net. Returns true if it was include
  * @param id the Node identity
  **/
	public synchronized void removeNode(NodeId id) throws NetLayoutException
	{
    NetNode node=(NetNode) (nodes.remove(id));
    if (node==null)
      throw new NetLayoutException("RemoveNode : node does not exist : " + id.getId());

    //remove first the links
    LinkId linkId=node.getALinkId();
    while(linkId!=null)
    {
      removeLink(linkId);
      linkId=node.getALinkId();
    }
    node.destroy();
	}
	
/**
  * Returns a node, which must be present
  **/
  public synchronized NetNode getNode(NodeId id) throws NetLayoutException
  {
    NetNode ret = (NetNode) (nodes.get(id));
    
    if (ret==null)
      throw new NetLayoutException("GetNode: node does not exist : " + id.getId());
    
    return ret;
  }
  
/**
  * Verifies wether a node is present
  **/
  public boolean containsNode(NodeId id)
  {
    return nodes.containsKey(id);
  }
  
/**
  * Inserts a new link in the net, with the specified delay
  * The observers of the netlayout will receive a VirtualNetEvent notification,
  * with the new link inside
  * @param id the Link  identity
  * @param idA any of the two nodes associated to this link
	* @param idB the another node
  * @param delay the expected delay
  * @param bidirectional set to true if the link is bidirectional, otherwise
  *        it has only the direction from nodeB to nodeA
  * @returns false if the link id already exists or the nodes are not valid
  **/
	public synchronized void addLink(LinkId id, NetNode nodeA, NetNode nodeB, int delay, boolean bidirectional) throws NetLayoutException
	{
    if (links.containsKey(id))
      throw new NetLayoutException("AddLink : link already existing: " + id.getId());
    if (!nodes.containsKey(nodeA.getId()))
      throw new NetLayoutException("AddLink : node does not exist: " + nodeA.getId());
    if (!nodes.containsKey(nodeB.getId()))
      throw new NetLayoutException("AddLink : node does not exist: " + nodeB.getId());

    NetLink link=new NetLink(id,nodeA,nodeB,delay,bidirectional);
		links.put(id,link);

    setChanged();
		notifyObservers(link);
	}
	
/**
  * Removes a Link out of the net.
  * @param id the Link identity
  * NetLink method fails
  * @see NetLink#destroy
  **/
	public synchronized void removeLink(LinkId id) throws NetLayoutException
	{
    NetLink link=(NetLink) (links.remove(id));
    
    if (link==null)
      throw new NetLayoutException("RemoveLink: link does not exist : " + id.getId());
      
    link.destroy();
  }
  
/**
  * Verifies wether a link is present
  **/
  public boolean containsLink(LinkId id)
  {
    return links.containsKey(id);
  }
  
/**
  * Returns a link, which must be present
  **/
  public synchronized NetLink getLink(LinkId id) throws NetLayoutException
  {
    NetLink ret = (NetLink) (links.get(id));
    
    if (ret==null)
      throw new NetLayoutException("GetLink: link does not exist : " + id.getId());
    
    return ret;
  }
  
/**
  * This is the destructor: destroy the nodes of the net, who destroy themselves
  * the links, notifying all this events to the observes.
  * @see NetNode#destroy
  **/
  public synchronized void destroy()
  {
    Iterator it=links.values().iterator();
    while(it.hasNext())
      ((NetLink)(it.next())).destroy();
    links.clear();

    it=nodes.values().iterator();
    while(it.hasNext())
      ((NetNode)(it.next())).destroy();
    nodes.clear();
  }

/**
  * Returns the nodes in the net
  **/
  public synchronized Set getNodes()
  {
    return new HashSet(nodes.values());
  }

/**
  * Returns the links in the net
  **/
  public synchronized Set getLinks()
  {
    return new HashSet(links.values());
  }

	private Hashtable nodes=new Hashtable(4);
	private Hashtable links=new Hashtable(4);
}
