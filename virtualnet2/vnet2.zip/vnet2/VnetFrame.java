/**
  * File: VnetFrame.java
  * @author LuisM Pena
  * @version 0.3, january-2000
  **/

package vnet2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import java.awt.Dimension;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

/**
  * VirtualNet display
  **/
public class VnetFrame extends JFrame implements VirtualNetUser
{
  /**
    * Constructor: requires the initial nodes to display, in the for
    * of a hashMap containig the node name and a reference to it (like Observable)
    **/
  public VnetFrame(String file, boolean verbose, boolean overrideSocket, int socket)
  {  
    this.verbose = verbose;
    
    setJMenuBar(createMenu());
    
    enableMenus(false);
   
    netLayout=null;
    netLayoutStringBuilder = null;
    virtualNetServer = null;
    panel=null;
    graphState=new GraphState();
    graphStateChanged=false;
    vpFile = null;
   
    setTitle();
    pack();
    show();

    addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){menuExit();}});
    
    fileDialog = new JFileChooser();
    fileDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
    fileDialog.setMultiSelectionEnabled(false);
    
    if (file!=null)
      loadFile(new File(file), overrideSocket, socket);
  }
  
//*************************************************************************************//
//**************************** VIRTUAL NET USER INTERFACE *****************************//
//*************************************************************************************//
  
  public void virtualNetServerError(String msg)
  {
    message(msg, true);
  }

  public void virtualNetServerEnded()
  {
    message("VirtualNetServer is shutdown", false);
  }

  public void virtualNetSessionError(String error, NodeId node)
  {
    if (verbose || node==null)
      message(error, true);
  }

  public void virtualNetSessionStarted(NodeId node)
  {
    if (verbose) System.out.println("VirtualNetSession started on node: " + node);
  }
  
  public void virtualPathQueried(NodeId source, NodeId target, boolean success)
  {
    if (verbose) System.out.println("Founding virtual path between " + source + " and " + target + ((success)? " : Found": " : NOT found"));
  }
  
  public void virtualNetSessionEnded(NodeId node)
  {
    if (verbose && node!=null) System.out.println("VirtualNetSession ended on node: " + node);
  }
  
//*************************************************************************************//
//**************************** CHECK CLOSE ********************************************//
//*************************************************************************************//
  
  /**
    * Checks that the current virtual net can be closed
    **/
  boolean checkClose(boolean allowCancel)
  {
    boolean ret = true;
    savePanelState();

    if (builder!=null && (graphStateChanged || builder.isChanged()))
    {
      int option=allowCancel? JOptionPane.YES_NO_CANCEL_OPTION : JOptionPane.YES_NO_OPTION;
      switch(JOptionPane.showConfirmDialog(this, "Save changes to the the virtual net?",
        "Close", option,JOptionPane.QUESTION_MESSAGE))
        {
          case JOptionPane.YES_OPTION:
            ret=menuSave();
            break;
          case JOptionPane.NO_OPTION:
            ret=true;
            break;
          default:
            ret=false;
            break;
        }
    }
    if (ret)
    {
      miShow.setState(false);
      if (virtualNetServer!=null)
        virtualNetServer.stopNet();
      virtualNetServer=null;
      netLayoutStringBuilder=null;
      if (netLayout!=null)
        netLayout.destroy();
      netLayout=null;
      enableMenus(false);
      graphState.reset();
      graphStateChanged=false;
      vpFile=null;
      setTitle();
    }
    return ret;
  }
  
//*************************************************************************************//
//**************************** SET TITLE **********************************************//
//*************************************************************************************//
  
  void setTitle()
  {
    if (vpFile==null)
      setTitle("Virtual Net");
    else
      setTitle("Virtual Net - " + vpFile.getName());
  }
  
//*************************************************************************************//
//**************************** ENABLE MENUS *******************************************//
//*************************************************************************************//
  
  void enableMenus(boolean enable)
  {
    menuLayout.setEnabled(enable);
    miClose.setEnabled(enable);
    miSave.setEnabled(enable && (vpFile !=null));
    miSaveAs.setEnabled(enable);
    miModify.setEnabled(enable);
    miTest.setEnabled(enable);
    miShow.setEnabled(enable);
    miShow.setState(false);
  }
  
//*************************************************************************************//
//**************************** MENU NEW ***********************************************//
//*************************************************************************************//
  
  void menuNew()
  {
    if (checkClose(true))
    {
      String input=JOptionPane.showInputDialog(this, "Please introduce listening socket port");
      if (input!=null)
      {
        try
        {
          socket=Integer.valueOf(input).intValue();
          newNetLayout(new NetLayout(), socket);
          miShow.setState(true);
        }
        catch(NumberFormatException nfe)
        {
          message(input+" is not a valid socket port",true);
        }
      }
    }
  }

//*************************************************************************************//
//**************************** NEW NET LAYOUT *****************************************//
//*************************************************************************************//
  
  void newNetLayout(NetLayout layout, int socket)
  {
    netLayout=layout;
    this.socket=socket;
    builder = new NetLayoutBuilder(netLayout);
    netLayoutStringBuilder = new NetLayoutStringBuilder(builder);
    virtualNetServer = new VirtualNetServer(this, netLayout, socket, Consts.MAX_SHUTDOWN_TIME);
    enableMenus(true);
  }
  

//*************************************************************************************//
//**************************** LOAD FILE **********************************************//
//*************************************************************************************//
  
  void loadFile(File file, boolean overrideSocket, int socket)
  {
    FileInputStream stream=null;
    try
    {
      vpFile = file;
      stream = new FileInputStream(vpFile);
      Properties properties=new Properties();
      properties.load(stream);
      if (!overrideSocket)
        socket=NetLayoutPropertiesBuilder.readUnsigned(properties,Consts.FILE_SOCKET, true, 0);
      newNetLayout(new NetLayoutPropertiesBuilder().loadLayout(properties), socket);
      graphState.putAll(properties);
      graphStateChanged=false;
      if (!NetLayoutPropertiesBuilder.readBoolean(properties,Consts.FILE_HIDE_GRAPH, false, false))
        miShow.setState(true);
    }
    catch(Exception ex)
    {
      vpFile=null;
      netLayout=null;
      builder=null;
      netLayoutStringBuilder=null;
      virtualNetServer=null;
      message(ex.getMessage(),true);
    }
    finally
    {
      if (stream!=null)
        try{stream.close();}catch(Exception ex){}
    }
    setTitle();
  }
  
//*************************************************************************************//
//**************************** MENU OPEN **********************************************//
//*************************************************************************************//
  
  void menuOpen()
  {
    if(checkClose(true))
      if (fileDialog.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) 
        loadFile(fileDialog.getSelectedFile(), false, 0);
  }
  
//*************************************************************************************//
//**************************** MENU SAVE **********************************************//
//*************************************************************************************//
  
  /**
    * Returns true if the file is saved
    **/
  boolean menuSave()
  {
    boolean ret;
    if (vpFile==null)
      ret=menuSaveAs();
    else
    {
      Properties properties = new Properties();
      properties.setProperty(Consts.FILE_SOCKET, String.valueOf(socket));
      if (panel==null)
        properties.setProperty(Consts.FILE_HIDE_GRAPH, Consts.FILE_TRUE_PROPERTY_VALUE);
      new NetLayoutPropertiesBuilder().storeLayout(netLayout,properties);
      FileOutputStream output=null;
      try
      {
        output=new FileOutputStream(vpFile);
        properties.store(output,Consts.FILE_HEADER);
        savePanelState();
        graphState.store(output,Consts.FILE_GRAPH_HEADER);
        builder.setUnchanged();
        graphStateChanged=false;
        ret=true;
      }
      catch(IOException ex)
      {
        message(ex.getMessage(), true);
        ret=false;
      }
      finally
      {
        try{output.close();}catch(IOException ex){}
      }
    }
    return ret;
  }
  
//*************************************************************************************//
//**************************** MENU SAVE AS *******************************************//
//*************************************************************************************//
  
  /**
    * Returns true if the file is saved
    **/
  boolean menuSaveAs()
  {
    boolean ret=true;
    if (vpFile !=null)
      fileDialog.setSelectedFile(vpFile);
    if (fileDialog.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) 
    {
      vpFile = fileDialog.getSelectedFile();
      if (menuSave())
      {
        miSave.setEnabled(true);
        setTitle();
      }
      else
        ret=menuSaveAs();
    }
    else
      ret=false;
    return ret;
  }
  
//*************************************************************************************//
//**************************** MENU EXIT **********************************************//
//*************************************************************************************//
  
  void menuExit()
  {
    if (checkClose(false))
      System.exit(0);
  }
  
//*************************************************************************************//
//**************************** MENU MODIFY ********************************************//
//*************************************************************************************//
  
  void menuModify()
  {
    String input = JOptionPane.showInputDialog(this,"Please introduce modifier string");
    if (input!=null)
      try
      {
        netLayoutStringBuilder.process(input);
      }
      catch(Exception ex)
      {
        message(ex.getMessage(),true);
      }
  }
  
//*************************************************************************************//
//**************************** MENU SHOW **********************************************//
//*************************************************************************************//
  
  void menuShow(boolean show)
  {
    if (show)
    {
      if (netLayout!=null)
      {
        panel=new VnetPanel(netLayoutStringBuilder, netLayout.getNodes(), netLayout.getLinks(), graphState);
        netLayout.addObserver(panel);
        getContentPane().add(panel);
        pack();
      }
    }
    else
    {
      if (panel!=null)
      {
        savePanelState();
        panel.destroy();
        netLayout.deleteObserver(panel);
        getContentPane().remove(panel);
        panel=null;
        pack();
      }
    }
  }
  
//*************************************************************************************//
//**************************** SAVE PANEL STATE ***************************************//
//*************************************************************************************//
  
  void savePanelState()
  {
    if (panel!=null)
    {
      GraphState newState = panel.getState();
      if (!newState.equals(graphState))
      {
        graphState=newState;
        graphStateChanged=true;
      }
    }
  }
  
//*************************************************************************************//
//**************************** MENU ABOUT *********************************************//
//*************************************************************************************//
  
  void menuAbout()
  {
    message("VirtualNet2, (c)LuisM Pena, August-1997, v1.01.February.2001",false);
  }
  
//*************************************************************************************//
//**************************** MENU TEST **********************************************//
//*************************************************************************************//
  
  void menuTest()
  {
    new VirtualPathTester(this, netLayout);
  }
  
//*************************************************************************************//
//**************************** MESSAGE ************************************************//
//*************************************************************************************//
  
  void message(String message, boolean isError)
  {
    if (message==null) throw new RuntimeException();
    JOptionPane.showMessageDialog(this,message,getTitle(),isError?JOptionPane.ERROR_MESSAGE:JOptionPane.INFORMATION_MESSAGE);
  }
  
//*************************************************************************************//
//**************************** CREATE MENU ********************************************//
//*************************************************************************************//
  
  /**
    * Creates the menu bar
    **/
  JMenuBar createMenu()
  {
    JMenuBar bar = new JMenuBar();

    JMenu vnet   = new JMenu("Virtual Net");
    menuLayout = new JMenu("Net Layout");
    JMenu help   = new JMenu("Help");
    
    vnet.setMnemonic(KeyEvent.VK_V);;
    menuLayout.setMnemonic(KeyEvent.VK_L);;
    help.setMnemonic(KeyEvent.VK_H);;

    bar.add(vnet);
    bar.add(menuLayout);
    bar.add(javax.swing.Box.createHorizontalGlue());
    bar.add(help);
    
    JMenuItem mi;

    mi = new JMenuItem ("New ...", KeyEvent.VK_N);
    mi.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuNew();}});
    vnet.add(mi);

    miClose = new JMenuItem ("Close", KeyEvent.VK_C);
    miClose.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){checkClose(true);}});
    vnet.add(miClose);
    
    vnet.addSeparator();

    mi = new JMenuItem ("Open ...",KeyEvent.VK_O);
    mi.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuOpen();}});
    vnet.add(mi);

    miSave = new JMenuItem ("Save", KeyEvent.VK_S);
    miSave.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuSave();}});
    vnet.add(miSave);
    
    miSaveAs = new JMenuItem ("Save As ...", KeyEvent.VK_A);
    miSaveAs.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuSaveAs();}});
    vnet.add(miSaveAs);
    
    vnet.addSeparator();

    mi = new JMenuItem ("Exit", KeyEvent.VK_X);
    mi.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuExit();}});
    vnet.add(mi);
    
    miModify = new JMenuItem ("Modify ...", KeyEvent.VK_M);
    miModify.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F8,0));
    miModify.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuModify();}});
    menuLayout.add(miModify);
    
    menuLayout.addSeparator();

    miShow = new JCheckBoxMenuItem ("Show", false);
    miShow.setMnemonic(KeyEvent.VK_S);
    menuLayout.add(miShow);
    miShow.addItemListener(new ItemListener()
      {public void itemStateChanged(ItemEvent e){menuShow(e.getStateChange()==ItemEvent.SELECTED);}});
    
    miTest = new JMenuItem ("Test ...", KeyEvent.VK_T);
    miTest.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F9,0));
    miTest.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuTest();}});
    help.add(miTest);

    help.addSeparator();

    mi = new JMenuItem ("About ...", KeyEvent.VK_A);
    mi.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){menuAbout();}});
    help.add(mi);

    return bar;    
  }

  NetLayout netLayout;
  NetLayoutBuilder builder;
  NetLayoutStringBuilder netLayoutStringBuilder;
  VirtualNetServer virtualNetServer;
  VnetPanel panel;
  GraphState graphState;
  boolean graphStateChanged, verbose;
  int socket;

  File vpFile;
  JFileChooser fileDialog;
    
  //menu variables
  JMenu menuLayout;
  JMenuItem miClose, miSave, miSaveAs, miModify, miTest;
  JCheckBoxMenuItem miShow;  
};
  

