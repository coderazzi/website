/**
  * File: GraphResources.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Color;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;
import javax.swing.ImageIcon;

import java.net.URL;

class GraphResources
{
  /*******************************************************************************/
  /**************************** SINGLETON ACCESS *********************************/
  /*******************************************************************************/

  static GraphResources getGraphResources()
  {
    if (singleton==null)
      singleton=new GraphResources();
    return singleton;
  }

  /*******************************************************************************/
  /**************************** ACCESS *******************************************/
  /*******************************************************************************/

  final static int NODE_ACTIVE=1;
  final static int NODE_DEACTIVATED=2;
  final static int NODE_USED=3;
  final static int LINK_ACTIVE=4;
  final static int LINK_DEACTIVATED=5;
  final static int LINK_USED=6;
  final static int LINK_MONO_ACTIVE=7;
  final static int LINK_MONO_DEACTIVATED=8;
  final static int LINK_MONO_USED=9;

  ImageIcon getImage(int which)
  {
    switch(which)
    {
      case NODE_ACTIVE: return node;
      case NODE_DEACTIVATED: return nodeNoActive;
      case NODE_USED: return nodeInUse;
      case LINK_ACTIVE: return link;
      case LINK_DEACTIVATED: return linkNoActive;
      case LINK_USED: return linkInUse;
      case LINK_MONO_ACTIVE: return linkMono;
      case LINK_MONO_DEACTIVATED: return linkMonoNoActive;
      case LINK_MONO_USED: return linkMonoInUse;
    }
    return null;
  }

  int getWidth(int which)
  {
    switch(which)
    {
      case NODE_ACTIVE:
      case NODE_DEACTIVATED:
      case NODE_USED:
        return nodeWidth;
      case LINK_ACTIVE:
      case LINK_DEACTIVATED:
      case LINK_USED:
        return linkWidth;
      case LINK_MONO_ACTIVE:
      case LINK_MONO_DEACTIVATED:
      case LINK_MONO_USED:
        return linkMonoWidth;
    }
    return -1;
  }

  int getHeight(int which)
  {
    switch(which)
    {
      case NODE_ACTIVE:
      case NODE_DEACTIVATED:
      case NODE_USED:
        return nodeHeight;
      case LINK_ACTIVE:
      case LINK_DEACTIVATED:
      case LINK_USED:
        return linkHeight;
      case LINK_MONO_ACTIVE:
      case LINK_MONO_DEACTIVATED:
      case LINK_MONO_USED:
        return linkMonoHeight;
    }
    return -1;
  }

  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/

  private GraphResources()
  {
    node = load("vnet2/nodeActive.gif", true, true, Color.black.getRGB(), DEFAULT_NODE_SIZE);
    nodeNoActive = load("vnet2/nodeDeactivated.gif", true, true, Color.gray.getRGB(), DEFAULT_NODE_SIZE);
    nodeInUse = load("vnet2/nodeInUse.gif", true, true, Color.red.getRGB(), DEFAULT_NODE_SIZE);

    link = load("vnet2/linkActive.gif", false, true, Color.black.getRGB(), DEFAULT_LINK_SIZE);
    linkNoActive = load("vnet2/linkDeactivated.gif", false, true, Color.gray.getRGB(), DEFAULT_LINK_SIZE);
    linkInUse = load("vnet2/linkInUse.gif", false, true, Color.red.getRGB(), DEFAULT_LINK_SIZE);

    linkMono = load("vnet2/linkMonoActive.gif", false, false, Color.black.getRGB(), DEFAULT_LINK_SIZE);
    linkMonoNoActive = load("vnet2/linkMonoDeactivated.gif", false, false, Color.gray.getRGB(), DEFAULT_LINK_SIZE);
    linkMonoInUse = load("vnet2/linkMonoInUse.gif", false, false, Color.red.getRGB(), DEFAULT_LINK_SIZE);

    nodeWidth=Math.max(node.getIconWidth(), Math.max(nodeNoActive.getIconWidth(), nodeInUse.getIconWidth()));
    nodeHeight=Math.max(node.getIconHeight(), Math.max(nodeNoActive.getIconHeight(), nodeInUse.getIconHeight()));

    linkWidth=Math.max(link.getIconWidth(), Math.max(linkNoActive.getIconWidth(), linkInUse.getIconWidth()));
    linkHeight=Math.max(link.getIconHeight(), Math.max(linkNoActive.getIconHeight(), linkInUse.getIconHeight()));

    linkMonoWidth=Math.max(linkMono.getIconWidth(), Math.max(linkMonoNoActive.getIconWidth(), linkMonoInUse.getIconWidth()));
    linkMonoHeight=Math.max(linkMono.getIconHeight(), Math.max(linkMonoNoActive.getIconHeight(), linkMonoInUse.getIconHeight()));
  }

  /*******************************************************************************/
  /**************************** LOAD *********************************************/
  /*******************************************************************************/

  ImageIcon load(String fileName, boolean defaultCircle, boolean defaultComplete, int defaultColor, int defaultSize)
  {
    ImageIcon icon=null;
    URL location = ClassLoader.getSystemResource(fileName);
    if (location!=null)
      icon=new ImageIcon(location);
    if (icon==null || icon.getImageLoadStatus()==MediaTracker.ERRORED)
      icon = new ImageIcon(createDefaultImage(defaultCircle, defaultComplete, defaultColor, defaultSize));
    return icon;
  }

  /*******************************************************************************/
  /**************************** CREATE DEFAULT IMAGE *****************************/
  /*******************************************************************************/

  Image createDefaultImage(boolean circle, boolean complete, int color, int size)
  {
    int pixels[] = new int[size*size];
    int half=size/2;
    int paint=Color.black.getRGB();
    for (int h=0;h < half; h++)
      for (int w=0; w < half; w++)
      {
        int c=0;
        if (circle)
        {
          if ((h*h+w*w+half*half)<=(2*half*(h+w)))
            c=color;
        }
        else if ((h+w)>=half)
          c=color;
        int pixel=h*size+w;
        int addColumn=size-2*w-1;
        int addRow=size*(size-2*h-1);
        pixels[pixel]=pixels[pixel+addRow+addColumn]=c;
        if (!complete)
          c=0;
        pixels[pixel+addColumn]=pixels[pixel+addRow]=c;
      }
    return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(size,size,pixels,0,size));
  }

  /*******************************************************************************/
  /**************************** DATA *********************************************/
  /*******************************************************************************/

  ImageIcon node, nodeNoActive, nodeInUse;
  ImageIcon link, linkNoActive, linkInUse, linkMono, linkMonoNoActive, linkMonoInUse;
  int nodeWidth, nodeHeight, linkWidth, linkHeight, linkMonoWidth, linkMonoHeight;

  final static int DEFAULT_NODE_SIZE=32;
  final static int DEFAULT_LINK_SIZE=16;

  static GraphResources singleton=null;
}
