/**
  * File: MouseTrackerUser.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

/**
  * Interface to be implemented by MouseTracker users
  **/
interface MouseTrackerUser 
{
  /**
    * returns the element on the position specified, or null if none
    **/
  public MouseAware getElement(int posX, int posY);

  /**
    * reports that the element given is being moved.
    * returns true if the action is valid
    **/
  public boolean movingElement(MouseAware element, int posX, int posY);
  
  /**
    * reports an action over an element, on the NetLayoutStringBuilder notation
    **/
  public void actionOnElement(MouseAware element, String action);
};
