package vnet2;

/**
  * Event sent by a virtual device
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
public class VirtualDeviceEvent
{
  public static final VirtualDeviceEvent getDestroyedEvent()     { return destroyedEvent; }
  public static final VirtualDeviceEvent getStartUseEvent()      { return usedEvent;      }
  public static final VirtualDeviceEvent getEndUseEvent()        { return unusedEvent;    }
  public static final VirtualDeviceEvent getActivationEvent()    { return activatedEvent;    }
  public static final VirtualDeviceEvent getDeactivationEvent()  { return deactivatedEvent;  }
  
  public boolean isDestroyed()       { return state==DESTROYED;    }
  public boolean isStartedUse()      { return state==USED;         }
  public boolean isEndedUse()        { return state==UNUSED;       }
  public boolean isActivatedUse()    { return state==ACTIVATED;    }
  public boolean isDeactivatedUse()  { return state==DEACTIVATED;  }
  
  private int state;
  
  private static final int DESTROYED=0;
  private static final int USED=1;
  private static final int UNUSED=2;
  private static final int ACTIVATED=2;
  private static final int DEACTIVATED=2;
  
  private static final VirtualDeviceEvent destroyedEvent   = new VirtualDeviceEvent(DESTROYED);
  private static final VirtualDeviceEvent usedEvent        = new VirtualDeviceEvent(USED);
  private static final VirtualDeviceEvent unusedEvent      = new VirtualDeviceEvent(UNUSED);
  private static final VirtualDeviceEvent activatedEvent   = new VirtualDeviceEvent(ACTIVATED);
  private static final VirtualDeviceEvent deactivatedEvent = new VirtualDeviceEvent(DEACTIVATED);

  private VirtualDeviceEvent(int state)
  {
    this.state=state;
    assert state>=DESTROYED && state<=DEACTIVATED;
  }
  
}
