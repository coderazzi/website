package vnet2;

/**
  * Class to represent a node identity
  * @author LuisM Pena
  * @version 0.2, august-1997
  * @see NetNode
  */
public class NodeId
{
	/**
	  * @param id the string representing the node
	  */
	public NodeId(String idString)
	{
		id=new String(idString);
	}

	/**
	  * @param element other NodeId to be compared to
	  * @return true if both have the same identity
	  */
	public boolean equals(Object element)
	{
    return (element instanceof NodeId) && (id.equals(((NodeId)element).id));
	}
	
	/**
	  * @return a valid hash code
	  */
	public int hashCode()
	{
		return id.hashCode();
	}

	/**
	  * @return a printable form of the NodeId
	  */
	public String toString()
	{
		return id;
	}
	
	/**
	  * @return the identity
	  */
	public String getId()
	{
		return id;
	}

	private String id;
}
