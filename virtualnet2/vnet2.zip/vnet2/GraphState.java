/**
  * File: GraphState.java
  * @author LuisM Pena
  * @version 0.3, february-2001
  **/

package vnet2;

import java.awt.Dimension;
import java.awt.Point;
import java.io.InputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

/**
  * Keeps the graph state to persist it across Panel show/hide actions
  * or between application sessions
  **/
class GraphState extends Properties
{
  public GraphState()
  {
    init();
  }
  
  public GraphState(InputStream inStream) throws IOException
  {
    load(inStream);
  }
  
  public GraphState(Properties properties)
  {
    putAll(properties);
  }
  
  public void reset()
  {
    clear();
    init();
  }
  
  public boolean equals(Object o)
  {
    return (o instanceof GraphState) && (equals((GraphState)o));
  }
  
  public boolean equals(GraphState s)
  {
    boolean ret=size()==s.size();
    if (ret)
    {
      Iterator entries = entrySet().iterator();
      while(ret && entries.hasNext())
      {
        Map.Entry entry = (Map.Entry) entries.next();
        String key = (String) entry.getKey();
        String value= (String) entry.getValue();
        String otherValue=s.getProperty(key);
        if (value==null)
        {
          if (otherValue!=null)
            ret=false;
        }
        else
          if (!value.equals(otherValue))
            ret=false;
      }
    }
    return ret;
  }
  
  public Dimension getGraphSize()
  {
    return size;
  }
  
  public void setGraphSize(Dimension newSize)
  {
    size=new Dimension(newSize);
    store(Consts.FILE_GRAPH_SIZE_X, size.getWidth());
    store(Consts.FILE_GRAPH_SIZE_Y, size.getHeight());
  }
  
  public Point getNodeCentre(NetNode node, Point defaultCentre)
  {
    String name = node.getId().toString();
    double x = load(Consts.FILE_GRAPH_NODE_POSX+name, defaultCentre.getX());
    double y = load(Consts.FILE_GRAPH_NODE_POSY+name, defaultCentre.getY());
    if (x<=size.getWidth() && y<=size.getHeight())
      defaultCentre.setLocation(x,y);
    return defaultCentre;
  }
  
  public void storeNodeCentre(GraphNode node)
  {
    String name = node.getNode().getId().toString();
    Point p = node.getCentre();
    store(Consts.FILE_GRAPH_NODE_POSX+name,p.getX());
    store(Consts.FILE_GRAPH_NODE_POSY+name,p.getY());
  }
  
  public Point getLinkCentre(NetLink link, Point defaultCentre)
  {
    String name = link.getId().toString();
    double x = load(Consts.FILE_GRAPH_LINK_POSX+name, defaultCentre.getX());
    double y = load(Consts.FILE_GRAPH_LINK_POSY+name, defaultCentre.getY());
    if (x<=size.getWidth() && y<=size.getHeight())
      defaultCentre.setLocation(x,y);
    return defaultCentre;
  }
  
  public void storeLinkCentre(GraphLink link)
  {
    String name = link.getLink().getId().toString();
    Point p = link.getCentre();
    store(Consts.FILE_GRAPH_LINK_POSX+name,p.getX());
    store(Consts.FILE_GRAPH_LINK_POSY+name,p.getY());
  }
  
  public void load(InputStream inStream) throws IOException
  {
    Properties read=new Properties();
    read.load(inStream);
    putAll(read);
  }
  
  public void putAll(Map map)
  {
    clear();
    //only the valid keys are kept: starting with Graph.
    Iterator entries = map.entrySet().iterator();
    while(entries.hasNext())
    {
      Map.Entry entry = (Map.Entry) entries.next();
      String key = (String) entry.getKey();
      String value= (String) entry.getValue();
      if (key.startsWith(Consts.FILE_GRAPH))
        setProperty(key, value);
    }

    //look for the panel size
    double maxX =  load(Consts.FILE_GRAPH_SIZE_X, -1);
    double maxY =  load(Consts.FILE_GRAPH_SIZE_Y, -1);
    if (maxX<=0 || maxY <=0)
    {
      clear();
      init();
    }
    else
      setGraphSize(new Dimension((int)maxX, (int)maxY));
  }
  
  void init()
  {
    setGraphSize(new Dimension(Consts.PANEL_SIZEX, Consts.PANEL_SIZEY));
  }
  
  void store(String keyProperty, double value)
  {
    setProperty(Consts.FILE_GRAPH + keyProperty,String.valueOf(value));
  }
  
  //negative values are not allowed, except for the defaultValue
  double load(String keyProperty, double defaultValue)
  {
    double ret=-1;
    String prop = getProperty(Consts.FILE_GRAPH + keyProperty);
    if (prop==null)
      ret = defaultValue;
    else
    {
      try
      {
        ret = Double.parseDouble(prop);
        if (ret<0)
          ret=defaultValue;
      }
      catch(NumberFormatException ex)
      {
        ret=defaultValue;
      }    
    }
    return ret;
  }
  
  Dimension size;
}
