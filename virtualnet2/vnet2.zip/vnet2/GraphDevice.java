/**
  * File: GraphDevice.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Observable;
import javax.swing.ImageIcon;

/**
  * Graphical peer of a NetNode (its graphical representation is a circle)
  * It manages the events lunched by a netNode, and is able to draw itself.
  * When its position changes, it sends notification events to signal that
  * change. The notification just includes the GraphNode itself
  */
abstract class GraphDevice extends Observable implements MouseAware
{
  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * A Element needs to know the component where must be drawn, and the
    * name of the backed up device element. It will send automatically
    * events when its position changes
    **/
  public GraphDevice(Component parent, String name, Point centre, ImageIcon image, int width, int height)
  {
    this.parent = parent;
    this.name = name;
    this.centre = new Point(centre);
    this.image = image;
    w=width;
    h=height;
    x=y=-1;
    valid=true;
    
    moveTo(centre.getX(), centre.getY());
  }
  
  /*******************************************************************************/
  /**************************** SET IMAGE ****************************************/
  /*******************************************************************************/
  
  void setImage(ImageIcon image)
  {
    if (valid)
    {
      this.image=image;
      parent.repaint((int)x,(int)y,w,h);
    }
  }
  
  /*******************************************************************************/
  /**************************** DESTRUCTOR ***************************************/
  /*******************************************************************************/
  
  public void destroy()
  {
    if (parent!=null)
    {
      parent.repaint((int)x,(int)y,w,h);
      parent=null;
      name=null;
      centre=null;
      image=null;
      valid=false;
    }
  }
  
  /*******************************************************************************/
  /**************************** MOUSE AWARE INTERFACE ****************************/
  /*******************************************************************************/
  
  public String getName()
  {
    return name;
  }
  
  public boolean containsPoint(int px, int py)
  {
    return (valid) && ((px>=x) && (px<(x+w)) && (py>=y) && (py<=(y+h)));
  }
  
  public void draggedPoint(int x, int y)
  {
    moveTo(x,y);
  }
  
  /*******************************************************************************/
  /**************************** INTERFACE ... ************************************/
  /*******************************************************************************/
  
  public Point getCentre(){return centre;}
  
  public void draw(Graphics g)
  {
    if (valid) 
      image.paintIcon(parent,g,(int)x,(int)y);
  }
  
  public boolean clipsArea(Rectangle area)
  {
    return valid && (area.intersects(x,y,w,h));
  }
  
  public void moveTo(double toX, double toY)
  {
    if (valid)
    {
      if (x==-1)
      {
        x=toX-w/2;
        y=toY-h/2;
      }
      else
      {
        int x0=(int)x;
        int y0=(int)y;
        x=toX-w/2;
        y=toY-h/2;
        parent.repaint(x0, y0, w, h);
      }
      centre.setLocation(toX,toY);
      parent.repaint((int)x,(int)y,w,h);
      setChanged();
      notifyObservers(centre);
    }
  }
  
  public void translate(double x, double y)
  {
    moveTo(x*centre.getX(), y*centre.getY());
  }
  
  /*******************************************************************************/
  /**************************** DATA *********************************************/
  /*******************************************************************************/
  
  Component parent;
  String name;
  Point centre;
  ImageIcon image;
  boolean valid;
  double x,y;
  int w,h;
}
