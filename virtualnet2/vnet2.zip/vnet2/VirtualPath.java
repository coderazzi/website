package vnet2;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.ListIterator;

/**
  * Class to represent the way that a message in the net has walked
  * It is represented by all the nodes and links that the message has been in
  * @author LuisM Pena
  * @version 0.1, august-1997
  */
class VirtualPath
{
  /**
    * Clears the path
    */
  public void clear()
  {
    devices.clear();
    visited.clear();
  }
  
	/**
	  * Adds a device to the path.
    * The device can not be present
	  */
	public void addDevice(VirtualDevice device)
	{
    assert !visited.contains(device);
    devices.addLast(device);
    visited.add(device);
	}
	
  /**
    * Verifies wether a device is existing in the path or has been inserted at any moment
    * @returns true if present
    */
  public boolean containsDevice(VirtualDevice device)
  {
    return visited.contains(device);
  }
  
  /**
    * Removes a device from the path, that must be the last one inserted
    */
  public void removeDevice(VirtualDevice device)
  {
    Object removed=devices.removeLast();

    assert device.equals(removed);
  }
  
	private LinkedList devices = new LinkedList();
  private HashSet visited = new HashSet();
};
