package vnet2;

import java.util.Observable;

/**
  * Class to represent a link in the net. 
  * In this simulation, a link is any communication channel beetween two nodes
  * in the net, that can be break down at any moment. If a node is fail down,
  * all its links are also considered to fail.
  * It implements the Observable function of the observer pattern.
  * @author LuisM Pena
  * @version 0.3, january-2001
  */
class NetLink extends Observable implements VirtualDevice
{
	/**
	  * @param id the identity of the link
	  * @param nodeA any of the two nodes associated to this link
	  * @param nodeB the another node
	  * @param delay the delay involving any operation on this link
    * @param bidirectional set to true if the link is bidirectional, otherwise
    *        it has only the direction from nodeB to nodeA
	  * @see NetNode#addLink
	  */	
	public NetLink(final LinkId id, NetNode nodeA, NetNode nodeB, int delay, boolean bidirectional)
	{
		this.id=id;
		this.nodeA=nodeA;
		this.nodeB=nodeB;
		this.delay=delay;
    this.bidirectional=bidirectional;
    
    nodeB.addLink(this);
    if (bidirectional)
      nodeA.addLink(this);
    
    valid = active = true;  
    use = 0;
	}
	
  public boolean equals(Object o)
  {
    return (( o instanceof NetLink) && ((NetLink)o).id.equals(id));
  }
  
  public int hashCode(){return id.hashCode();}
  public int getDelay(){return delay;}
  public boolean isActive(){return active;}
  public boolean isBidirectional(){return bidirectional;}
  public LinkId getId(){return id;}
    
  /**
    * Sets the delay
    **/  
  public void setDelay(int delay)
  {
    assert valid;
    this.delay=delay;    
  }
  
	/**
	  * Returns the first of the nodes associated to the link
	  * @return The first of the nodes associated
	  */	
	public NetNode getNodeA()
	{
		return nodeA;
	}
	
	/**
	  * Returns the second node associated to the link
	  * @return The second node associated to the link
	  */	
	public NetNode getNodeB()
	{
		return nodeB;
	}
	
  /**
    * Link is activated/deactivated
    **/  
  public synchronized void activate(boolean active)
  {
    assert valid;
    
    if (active!=this.active)
    {
      while(use>0)
        try{wait();}catch(InterruptedException ex){}
        
      this.active=active;
    
      setChanged();
      notifyObservers(active?VirtualDeviceEvent.getActivationEvent():VirtualDeviceEvent.getDeactivationEvent());
    }
    
   }

	/**
	  * Destructor of the link: notifies it to the nodes associated to the link
	  * The observers of the node will receive a LinkDestroyedEvent notification
	  * The list of observers is cleared
	  * @exception VNException if any of the nodes associated fails during the
	  * removeLink operation
	  * @see NetNode#removeLink
	  * @see LinkDestroyedEvent
	  */	
	public synchronized void destroy()
	{
		nodeB.removeLink(this);
    if (bidirectional)
  		nodeA.removeLink(this);

    setChanged();
    notifyObservers(VirtualDeviceEvent.getDestroyedEvent());
		deleteObservers();
    
    valid=active=false;
	}

  /**
    * Finds a virtual path to a given node
    * @param virtualPath data on the nodes already visited, that do not need to ve revisited
    * @returns the virtualPath found, or null if not way to the node
    */  
  public VirtualPath findPath(NetNode target, VirtualPath state)
  {
    VirtualPath ret=null;
    if (setUse(true))
    {
      state.addDevice(this);
      setUse(false);
      
      if (!state.containsDevice(nodeA))
        ret=nodeA.findPath(target, state);
        
      if (bidirectional && (ret==null) && !state.containsDevice(nodeB))
        ret=nodeB.findPath(target, state);
        
      if (ret==null)
        state.removeDevice(this);
    }
    return ret;
  }
  
  synchronized boolean setUse(boolean onUse)
  {
    if (active)
      if (onUse)
      {
        if (++use==1)//it is only sent the event when starts the use!
        {
          setChanged();
          notifyObservers(VirtualDeviceEvent.getStartUseEvent());
          notifyAll();  //activate method
        }
        try{Thread.currentThread().sleep(delay);}catch(InterruptedException ex){}
      }
      else if (--use==0)
      {
        setChanged();
        notifyObservers(VirtualDeviceEvent.getEndUseEvent());
        notifyAll(); //activate method
      }
      assert use>=0;
    return active;    
  }
  
  
  private NetNode nodeA, nodeB;
	private LinkId id;
	private int delay;
  private boolean bidirectional, valid, active;
  private int use;
}
