/**
  * File: VirtualNetServer.java
  * @author LuisM Pena
  * @version 0.3, january-2001
  **/

package vnet2;

import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Iterator;
  
/**
  * Class implementing the external interface to the virtual net logic
  **/
public class VirtualNetServer extends Thread
{

  /*******************************************************************************/
  /**************************** CONSTRUCTOR **************************************/
  /*******************************************************************************/
  
  /**
    * A VirtualNet needs a socket where it is published and a layout
    * to work over, as well as the user (owner) of the VirtualNetServer, to
    * get any error on the server
    * It is possible to specify the maxShutdownTime, that is the time that the
    * virtual net will continue operative once the stopNet method is called
    **/
  public VirtualNetServer(VirtualNetUser user, NetLayout layout, int socket, int maxShutdownTime)
  {
    this.user = user;
    this.layout=layout;
    this.socket=socket;
    this.maxShutdownTime = maxShutdownTime;
    sessions=new ArrayList();
    running=true;
    start();
  }
  
  /*******************************************************************************/
  /**************************** RUN **********************************************/
  /*******************************************************************************/
  
  /**
    * Thread method
    **/
  public void run()
  {
    ServerSocket serverSocket=null;
    try
    {
      serverSocket=new ServerSocket(socket);
      serverSocket.setSoTimeout(maxShutdownTime);
      while(running)
      {
        try
        {
          Socket session = serverSocket.accept();
          createSession(session);
        }
        catch(java.io.InterruptedIOException ex)
        {
          //ok, do not do anything (caused by setSoTimeout)
        }
      }
    }
    catch(Exception ex) //IOException, SocketException
    {
      user.virtualNetServerError(ex.getMessage());
      stopNet();
    }
    if (serverSocket!=null)
      try{serverSocket.close();}catch(IOException ex){}
    layout = null;
    sessionEnded(null);
  }
  
  /*******************************************************************************/
  /**************************** STOP NET *****************************************/
  /*******************************************************************************/
  
  /**
    * Stops the virtual net activity
    **/
  public synchronized void stopNet()
  {
    running=false;
    if (sessions!=null)
    {
      Iterator iterator=sessions.iterator();
      while(iterator.hasNext())
      {
        ((VirtualNetSession) (iterator.next())).stopSession();
      }
    }    
  }
  
  /*******************************************************************************/
  /**************************** CREATE SESSION ***********************************/
  /*******************************************************************************/
  
  /**
    * Creates a new session
    **/
  synchronized void createSession(Socket socket)
  {
    if (running)
      sessions.add(new VirtualNetSession(user, this, layout, socket, maxShutdownTime));
  }
  
  /*******************************************************************************/
  /**************************** SESSION ENDED ************************************/
  /*******************************************************************************/
  
  /**
    * Called by a session when it finishes
    **/
  synchronized void sessionEnded(VirtualNetSession session)
  {
    if (sessions!=null)
    {
      int index = session==null? -1 : sessions.indexOf(session);
      if (index!=-1)
        sessions.remove(index);
      if (sessions.isEmpty() && !running)
      {
        //over!
        sessions=null;
        user.virtualNetServerEnded();
        if (layout==null)//it is only null at the very end!
          user=null;
      }
    }
  }
  
  /*******************************************************************************/
  /*******************************************************************************/
  /*******************************************************************************/

  ArrayList sessions;
  NetLayout layout;
  boolean running;
  VirtualNetUser user;
  final int socket;  
  final int maxShutdownTime;
}
