package counter;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import java.io.*;
import java.util.Properties;

public class Server implements ServerGUIListener
{
  ServerGUI gui=null;
  int counter;

  public Server (String args[])
  {
    counter=0;
    Properties props = new Properties();
    args=vnet2user.Interceptor.setup(null, args, props);//only change for virtual net
    if (args.length==0)
    {
      gui=new ServerGUI(this, "unknown", counter);
      error("At least one argument must be given: the name of the server");
    }
    String server = args[args.length-1];
    System.out.println("Server: " + server);
    gui=new ServerGUI(this, server,counter);
    startCORBACommunications(args, props, server);
  }

  public void close()
  {
    System.exit(0);
  }

  public void reset()
  {
    setCounter(0);
  }

  void setCounter(int value)
  {
    counter=value;
    gui.setCounter(counter);
  }

  void error(String s)
  {
    gui.setError(s);
    close();
  }

  void startCORBACommunications(String args[], Properties props, String name)
  {
    ORB orb = ORB.init(args, props);
    try
    {
      POA poa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      poa.the_POAManager().activate();
      writeObject(orb, poa.servant_to_reference(new CounterServerImpl()), name);
      orb.run();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      error(ex.toString());
    }
  }

  void writeObject(ORB orb, org.omg.CORBA.Object object, String fileName) throws IOException
  {
    FileOutputStream stream=null;
    try
    {
      stream = new FileOutputStream(fileName);
      DataOutputStream dos = new DataOutputStream(stream);
      dos.writeUTF(orb.object_to_string(object));
    }
    finally
    {
      if (stream!=null)
        stream.close();
    }
  }

  class CounterServerImpl extends CounterServerPOA
  {
    public int get()
    {
      setCounter(++counter);
      return counter;
    }
  }

  public static void main(String args[])
  {
    new Server(args);
  }

}
