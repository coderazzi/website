package counter;

import org.omg.CORBA.*;
import java.io.*;
import java.util.Properties;

public class Client implements ClientGUIListener
{
  ClientGUI gui;
  CounterServer counter;

  public Client (String args[])
  {
    Properties props = new Properties();
    gui=new ClientGUI(this);
    args=vnet2user.Interceptor.setup(null, args, props);//only change for virtual net
    if (args.length==0)
    {
      error("At least one argument must be given: the name of the server", true);
    }
    String server = args[args.length-1];
    System.out.println("Server: " + server);
    counter = startCORBACommunications(args, props, server);
  }

  public void close()
  {
    System.exit(0);
  }

  public void getCounter()
  {
    try
    {
      gui.setCounter(counter.get());
    }
    catch(Exception ex)
    {
      error(ex.toString(), false);
    }
  }

  void error(String s, boolean quit)
  {
    gui.setError(s);
    if (quit)
      close();
  }

  public org.omg.CORBA.Object readObject(ORB orb, String fileName) throws IOException
  {
    org.omg.CORBA.Object ret = null;
    FileInputStream stream=null;
    try
    {
      stream = new FileInputStream(fileName);
      java.io.DataInputStream dis = new java.io.DataInputStream (stream);
      ret=orb.string_to_object(dis.readUTF());
    }
    finally
    {
      if (stream!=null)
        stream.close();
    }
    return ret;
  }

  CounterServer startCORBACommunications(String args[], Properties props, String name)
  {
    CounterServer counter=null;
    ORB orb = ORB.init(args, props);
    try
    {
      counter = CounterServerHelper.narrow(readObject(orb, name));
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      error(ex.toString(), true);
    }
    return counter;
  }

  public static void main(String args[])
  {
    new Client(args);
  }
}