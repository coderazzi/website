package counter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

interface ServerGUIListener
{
  void close();
  void reset();
};

class ServerGUI extends JFrame implements ActionListener
{
  JLabel counter;
  final ServerGUIListener listener;

  public ServerGUI (final ServerGUIListener listener, String serverName, int counterValue)
  {
    super("Counter / Server");
    this.listener = listener;

    addWindowListener (new WindowAdapter()
                          {public void windowClosing(WindowEvent e) {listener.close();}}
                        );

    java.awt.Container contentPane=getContentPane();

    GridBagLayout gridbag = new GridBagLayout();
    contentPane.setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.NONE;

    JLabel label = new JLabel("Server name:  ",SwingConstants.RIGHT);
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    gridbag.setConstraints(label, c);
    contentPane.add(label);

    label = new JLabel(serverName, SwingConstants.LEFT);
    label.setFont(new Font("Serif",Font.BOLD,18));
    c.gridx = 1;
    c.gridy = 0;
    c.gridwidth = 2;
    c.insets = new Insets(10,10,10,10);
    gridbag.setConstraints(label, c);
    contentPane.add(label);

    label = new JLabel("Counter value:  ",SwingConstants.RIGHT);
    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 1;
    c.insets = new Insets(0,0,0,0);
    gridbag.setConstraints(label, c);
    contentPane.add(label);

    counter = new JLabel(Integer.toString(counterValue),SwingConstants.LEFT);
    counter.setFont(new Font("Serif",Font.BOLD,18));
    c.gridx = 1;
    c.gridy = 1;
    c.gridwidth = 2;
    c.insets = new Insets(10,10,10,10);
    gridbag.setConstraints(counter, c);
    contentPane.add(counter);

    JPanel addPanel = new JPanel(new FlowLayout());
    JButton button = new JButton("Reset counter");
    button.setMnemonic('r');
    button.addActionListener( this );
    addPanel.add(button);

    c.weightx = 0.0;
    c.weighty = 1.0;
    c.gridx = 0;
    c.gridy = 2;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.NORTH;
    c.insets = new Insets(0,0,0,0);
    gridbag.setConstraints(addPanel, c);
    contentPane.add(addPanel);

    pack();
    setVisible (true);
  }

  public void setCounter(int value)
  {
    counter.setText(Integer.toString(value));
  }

  public void setError(String error)
  {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);
  }

  public void actionPerformed(java.awt.event.ActionEvent e)
  {
    listener.reset();
  }


}