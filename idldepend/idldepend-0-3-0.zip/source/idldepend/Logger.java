/**
 * File: Logger.java
 * Last update: 0.30, 1st July 2003
 * Please visit http://grasia.fdi.ucm.es/~luismi/idldepend for
 *   updates, download, license and copyright information
 **/

package idldepend;


import org.apache.tools.ant.Project;


/**
 * Interface to cover the logging (without depending on the
 *   ant's 'task', which has that functionality built in
 */
public interface Logger
{
   public void log(String msg);
}
