/**
  * File: InternalMacroFile.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend.preprocessor;

import idldepend.javacc.generated.ParseException;
import idldepend.javacc.generated.PreprocessorConstants;
import idldepend.javacc.generated.Token;

import java.util.ArrayList;
import java.util.List;

/**
 * Definition of the internal macro '__FILE__'.
 * It needs no parameters
 */
class InternalMacroFile extends Macro {

  /**
   * The constructor requires the PreprocessorController, to be able to retrieve the
   * file being processed
   */
  public InternalMacroFile(PreprocessorController controller) {
    complex=false;
    numberOfParameters=0;
    name="__FILE__";
    this.controller=controller;
  }

  public List expand(List parameters) throws ParseException{
    Token fileInfo = new Token();
    fileInfo.kind = PreprocessorConstants.STRING;
    fileInfo.image = "\"" + controller.getParsingFile() + "\"";
    List ret=new ArrayList();
    ret.add(fileInfo);
    return ret;
  }

  private PreprocessorController controller;
}

