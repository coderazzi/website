/**
 * File: VersionsSupporter.java
 * Author: LuisM Pena
 * Last update: 0.62, 1st October 2004
 * Please visit http://grasia.fdi.ucm.es/~luismi/idldepend for
 *   updates, download, license and copyright information
 **/

package idldepend.idl;



/**
 * Class used to handle deviations from the standard/defualt behaviour
 */
public class VersionsSupporter
{

   /**
    * OpenORB 1.3.1 handles incorrectly local interfaces, not generating
    * all the required files. More specifically, it does not produce the 
    * _NAMELocalBase neither NAMELocalTie
    */
   public void setIncompleteLocalInterfaceHandling()
   {
      correctLocalInterfaceHandling=false;
   }

   /**
    * @see setIncompleteLocalInterfaceHandling
    */
   public boolean handlesCorrectlyLocalInterfaces()
   {
      return correctLocalInterfaceHandling;
   }


   private boolean correctLocalInterfaceHandling=true;
}
