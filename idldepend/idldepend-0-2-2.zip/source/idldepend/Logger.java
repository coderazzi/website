/**
  * File: Logger.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend;

import org.apache.tools.ant.Project;

/**
 * Interface to cover the logging (without depending on the
 *   ant's 'task', which has that functionality built in
 */
public interface Logger
{
  public void log(String msg);
}