/**
 * File: IDLCheckerTask.java
 * Author: LuisM Pena
 * Last update: 0.32, 3rd September 2003
 * Please visit http://grasia.fdi.ucm.es/~luismi/idldepend for
 *   updates, download, license and copyright information
 **/

package idldepend;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.Path;


/**
 * Task to execute the compiler transforming IDL specifications
 * into java files.
 * It accepts the following arguments:
 *
 * - force : boolean : optional, default to false
 *   If set, it doesn't perform any check, launching the executables
 *      directly
 *
 * - failOnError : boolean : optional, default to false
 *   If set, it stops the ANT task as soon as a parsing error is found,
 *      without starting the compilation.
 *
 * - checkall : boolean : optional, default to false
 *   It checks all the types that must be generate, including those
 *      defined in #included files
 *
 * - preprocess : [dismiss, store, storeFull, useFull], default to dismiss
 *   If 'store', it saves the preprocessed file in the dependencies directory
 *   If 'storeFull', it is like store, but it also expands the included files
 *   If 'use', it uses the stored preprocessed file as input to the IDL compiler
 *   If 'useFull', it uses the storedFull preprocessed file as input to the IDL compiler
 *
 * - side: [client/server/all/serverTIE/allTIE], default to allTIE
 *   It checks that the files requested on the specific side are valid
 *
 * - compiler : [jdk/orbacus/jacorb/openorb], default to jdk
 *
 * - define : nested, allows name=, value= (name is mandatory)
 *   Defines new macros to be defined before executing the preprocessor
 *
 * - undefine : nested, allows name=(name is mandatory)
 *   Undefines macros before executing the preprocessor
 *
 * - file : File : optional, but this or fileset must be present
 *   Specify the IDL file (including extension) to ve verified. It is
 *      possible to specify a sequence of files using fileset
 *
 * - fileset : FileSet : optional, but this or file must be present
 *   Specify the IDL files to ve verified.
 *
 * - include : Path : optional
 *   Specifies the path(s) to be used when looking for included files
 *      on the IDL files
 *
 * - targetDir : File : optional, default to the project base dir
 *   Target directory used on the file generation
 *
 * - verbose : String : quiet | basic | debug : optional, quiet by default
 *   Specifies the verbosity level
 *
 *  -package, with the following attributes:
 *    -module. string
 *    -prefix. string
 *    -auto. boolean
 *
 *  -translate, with the following attributes:
 *    -module. string
 *    -package. string
 *
 *  -dependsDir: File
 *   The dependencies are stored in the directory specified by this
 *   argument. If is not specified, it is used targetDir, and, if this
 *   is neither specified, the base directory
 *
 *  -args: String (nested)
 *      It allows the user to specify additional arguments. Note that if this
 *      argument makes the compiler modify the name or number of created
 *      files, force should be set to "true", as dependencies would not be
 *      correctly verified
 *
 */
public class IDLCheckerTask extends Task implements Logger
{

   public IDLCheckerTask()
   {}

   /***
    * *
    *  METHODS TO SET THE TASK'S ARGUMENTS
    * *
    ***/

   public void setForce(boolean set)
   {
      force = set;
   }

   public void setFailOnError(boolean set)
   {
      failOnError = set;
   }

   public void setCheckall(boolean set)
   {
      checkAll = set;
   }

   public void setVerbose(TaskAttributesHandler.VerboseLevel level)
   {
      verboseLevel = level;
   }

   public void setSide(TaskAttributesHandler.SideAttribute attribute)
   {
      side = attribute;
   }

   public void setCompiler(TaskAttributesHandler.CompilerAttribute attribute)
   {
      compiler = attribute;
   }

   public void setPreprocess(TaskAttributesHandler.PreprocessAttribute attribute)
   {
      preprocess = attribute;
   }

   public void setDependsdir(File dir)
   {
      dependsDir = dir;
   }

   public Task createDefine()
   {
      TaskAttributesHandler.Define newDefine
            = new TaskAttributesHandler.Define();
      defines.add(newDefine);
      return newDefine;
   }

   public Task createUndefine()
   {
      TaskAttributesHandler.Undefine newUndefine
            = new TaskAttributesHandler.Undefine();
      undefines.add(newUndefine);
      return newUndefine;
   }

   public Path createInclude()
   {
      if (include == null) {
         include = new Path(getProject());
      }
      return include;
   }

   public FileSet createFileset()
   {
      if (idlFiles == null) {
         idlFiles = new FileSet();
      }
      return idlFiles;
   }

   public Task createPackage()
   {
      Task ret = new Translator.PackageTask();
      packages.add(ret);
      return ret;
   }

   public Task createTranslate()
   {
      Task ret = new Translator.TranslateTask();
      translates.add(ret);
      return ret;
   }

   public void setFile(File file)
   {
      idlFile = file;
   }

   public void setTargetdir(File dir)
   {
      targetDir = dir;
   }

   public Commandline.Argument createArg()
   {
      return commandLine.createArgument();
   }

   /**
    * Execute the task, once the arguments have been set
    */
   public void execute()
   {
		if (verboseLevel.isVerbose() || verboseLevel.isBasic()){
			log(VERSION);
		}
		
		if (preprocess.useFull()) {
			checkAll = true;
		}
		
      convertParameters();

      Translator translator = attributesHandler.createTranslator(packages, translates);
      translator.modifyCommandline(commandLine);

      UniqueDependencyId uniqueId = new UniqueDependencyId(commandLine, preprocess.getValue());

      // include now the arguments that should not affect the uniqueId
      attributesHandler.handleVerboseLevel(verboseLevel, commandLine);

      if (idlFile != null) {
         process(idlFile, (Commandline) commandLine.clone(), uniqueId, translator);
      }
      if (idlFiles != null) {
         DirectoryScanner scanner = idlFiles.getDirectoryScanner(getProject());
         File baseDir = scanner.getBasedir();
         String which[] = scanner.getIncludedFiles();
         for (int i = 0; i < which.length; i++) {
            process(new File(baseDir, which[i]), (Commandline) commandLine.clone(), uniqueId,
                  translator);
         }
      }
   }

   /**
    * Processes one independent file, once that the arguments have been checked
    * and preprocessed
    */
   private void process(File idlFile, Commandline commandLine,
         UniqueDependencyId uniqueId, Translator translator)
   {
      boolean usePreprocessedFile = preprocess.usePreprocessorFile();
      if (!force || usePreprocessedFile) {
	      if (!dependsDir.isDirectory()) {
   	      throw new BuildException("Directory " + dependsDir.toString() + " does not exist");
      	}
         try {
            IDLChecker checker = new IDLChecker(idlFile, uniqueId, dependsDir, targetDir,
                  checkerIncludes, checkerPreprocessor, attributesHandler.toGenerateClient(),
                  attributesHandler.toGenerateServer(), attributesHandler.toGenerateTIEs(),
                  checkAll, translator, attributesHandler.isVerbosityNormal(),
                  attributesHandler.isVerbosityDebug(), this, !force,
                  preprocess.generatePreprocessorFile(), preprocess.expandFull());

            if (checker.build(failOnError || usePreprocessedFile) || force){
   	         if (usePreprocessedFile) {
			         attributesHandler.execute(commandLine, checker.getPreprocessedFile(), this);
	            }
					else {
			         attributesHandler.execute(commandLine, idlFile, this);
					}
				}
         }
         catch (Exception ex) {
            throw new BuildException(ex.getMessage());
         }							  
      }
      else {
         attributesHandler.execute(commandLine, idlFile, this);
      }
   }

   /**
    * Converts the parameters given into a Commandline, with information that
    * is already dependant on the compiler. It also updates the global variables
    * checkerPreprocessor, checkerIncludes.
    * The only element not included is the debug information, which must be included later
    */
   private void convertParameters()
   {
      if (idlFile == null && idlFiles == null) {
         throw new BuildException("\"file\" or \"FileSet\" must be specified");
      }

      if (targetDir == null) {
         targetDir = getProject().getBaseDir();
      }
      if (dependsDir == null) {
         dependsDir = targetDir;
      }

      attributesHandler = new TaskAttributesHandler(compiler, commandLine);
      attributesHandler.handleCheckAllFlag(checkAll, commandLine);
      attributesHandler.handleSideAttribute(side, commandLine);
      attributesHandler.handleTargetDir(targetDir, commandLine);
      String checkerUndefines = attributesHandler.handleUndefines(undefines, commandLine);
      String checkerDefines = attributesHandler.handleDefines(defines, commandLine);
      checkerIncludes = attributesHandler.handleIncludes(include, commandLine);
      checkerPreprocessor = checkerDefines + checkerUndefines;
   }

   public void log(String msg)
   {
      super.log(msg);
   }

   public final static void main(String args[])
	{
		System.out.println(VERSION);
	}

   private boolean checkAll;
   private boolean force;
   private boolean failOnError;  
   private File targetDir, dependsDir;
   private File idlFile;
   private FileSet idlFiles;
   private Path include;
   private Commandline commandLine = new Commandline();
   private List defines = new ArrayList();
   private List undefines = new ArrayList();
   private List packages = new ArrayList();
   private List translates = new ArrayList();
   private TaskAttributesHandler.VerboseLevel verboseLevel = new TaskAttributesHandler.VerboseLevel();
   private TaskAttributesHandler.SideAttribute side = new TaskAttributesHandler.SideAttribute();
   private TaskAttributesHandler.CompilerAttribute compiler = new TaskAttributesHandler.CompilerAttribute();
   private TaskAttributesHandler.PreprocessAttribute preprocess = new TaskAttributesHandler.PreprocessAttribute();

   private TaskAttributesHandler attributesHandler;
   private String checkerPreprocessor, checkerIncludes;
	
	private final static String VERSION="idldepend v0.32 - http://grasia.fdi.ucm.es/~luismi/idldepend";
}
