/**
 * File: TaskAttributesHandler.java
 * Last update: 0.34, 25th November 2003
 * Please visit http://grasia.fdi.ucm.es/~luismi/idldepend for
 *   updates, download, license and copyright information
 **/

package idldepend;


import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Execute;
import org.apache.tools.ant.taskdefs.ExecuteJava;
import org.apache.tools.ant.taskdefs.LogStreamHandler;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.EnumeratedAttribute;
import org.apache.tools.ant.types.Path;


/**
 * Handles every task related to the attributes, except packages and
 * translates
 */
class TaskAttributesHandler
{

   private boolean jdk, orbacus, jacorb, jacorb2, openorb, orbix2k;
   private boolean generateClient, generateServer, generateTIE;
   private boolean verboseBASIC, verboseDEBUG;

   /**
    * The constructor requires the type of compiler decided.
    * @param compiler
    * @param Commandline the commandLine to use to execute the compiler,
    *     updates with information on the compiler
    */
   public TaskAttributesHandler(CompilerAttribute compiler, Commandline commandline)
   {
      String compilerValue = compiler.getValue();
      if (compilerValue.equals(JDK)) {
         jdk = true;
         commandline.setExecutable("com.sun.tools.corba.se.idl.toJavaPortable.Compile");
      }
      else if (compilerValue.equals(ORBACUS)) {
         orbacus = true;
         commandline.setExecutable("jidl");
      }
      else if (compilerValue.equals(OPENORB)) {
         openorb = true;
         // openorb ends with System.exit(xx), making impossible to use directly the VM!
         commandline.setExecutable("java");
         commandline.createArgument().setValue("org.openorb.compiler.IdlCompiler");
      }
      else if (compilerValue.equals(JACORB)) {
         jacorb = true;
         commandline.setExecutable("org.jacorb.idl.parser");
      }
      else if (compilerValue.equals(JACORB2)) {
         jacorb2 = true;
         commandline.setExecutable("idl");
      }
      else {
         orbix2k = true;
         commandline.setExecutable("idl");
      }
   }

   /**
    * Executes the compiler.
    */
   public void execute(Commandline commandline, File idlFile, Path classpath, Task owner)
   {
      Commandline doubled = (Commandline) commandline.clone();
      doubled.createArgument().setFile(idlFile);
      if (verboseDEBUG) {
         owner.log("Execute: " + doubled.toString());
      }
      else if (verboseBASIC) {
         owner.log("Processing " + idlFile.getName());
      }
      if (orbacus || openorb || orbix2k || jacorb2)  // not executed directly in the JVM
      {
         Execute.runCommand(owner, doubled.getCommandline());
      }
      else // jacorb, jdk
      {
         ExecuteJava executer = new ExecuteJava();
         executer.setJavaCommand(doubled);
         if (classpath!=null){
            executer.setClasspath(classpath);
         }
         executer.execute(owner.getProject());
      }
   }

   /**
    * Creates the appropiated translator
    */
   public Translator createTranslator(List packages, List translates)
   {
      Translator ret;
      if (jdk) {
         ret = new JDKTranslator(packages, translates);
      }
      else if (orbacus) {
         ret = new OrbacusTranslator(packages, translates);
      }
      else if (openorb) {
         ret = new OpenORBTranslator(packages, translates);
      }
      else if (jacorb || jacorb2) {
         ret = new JacorbTranslator(packages, translates);
      }
      else {
         ret = new Orbix2KTranslator(packages, translates);
      }
      return ret;
   }

   /**
    * After calling to handleSideAttribute, this methods returns a boolean
    * flag to specify wether the client side must be generated
    */
   public boolean toGenerateClient()
   {
      return generateClient;
   }

   /**
    * After calling to handleSideAttribute, this methods returns a boolean
    * flag to specify wether the server side must be generated
    */
   public boolean toGenerateServer()
   {
      return generateServer;
   }

   /**
    * After calling to handleSideAttribute, this methods returns a boolean
    * flag to specify wether the server TIEs must be generated
    */
   public boolean toGenerateTIEs()
   {
      return generateTIE;
   }

   /**
    * After calling to handleVerboseLevel, this methods returns a boolean
    * flag to specify wether the verbosity is BASIC
    */
   public boolean isVerbosityNormal()
   {
      return verboseBASIC || verboseDEBUG;
   }

   /**
    * After calling to handleVerboseLevel, this methods returns a boolean
    * flag to specify wether the verbosity is DEBUG
    */
   public boolean isVerbosityDebug()
   {
      return verboseDEBUG;
   }

   /**
    * Convert the specified undefines into a string to be passed to the
    * IDLChecker, and updates the command line to reflect those undefines on a
    * compiler-dependent way
    * @param undefines A List holding Undefine objects
    * @param commandLine The CommandLine to update
    * @return A string containing the undefines as they're expected on the
    *      preprocessor
    */
   public String handleUndefines(List undefines, Commandline commandline)
   {
      StringBuffer ret = new StringBuffer();
      if (!undefines.isEmpty()) {
         String undefineFlag = getUndefineFlag();
         StringBuffer forCompiler = new StringBuffer();
         Iterator it = undefines.iterator();
         while (it.hasNext()) {
            Undefine undefine = (Undefine) it.next();
            if (undefine.name != null) {
               ret.append("#undef ").append(undefine.name).append("\n");
               if (undefineFlag != null) {
                  forCompiler.append(undefineFlag).append(undefine.name);
                  commandline.createArgument().setLine(forCompiler.toString());
                  forCompiler.setLength(0);
               }
            }
         }
      }
      return ret.toString();
   }

   /**
    * Convert the specified defines into a string to be passed to the
    * IDLChecker, and updates the command line to reflect those defines on a
    * compiler-dependent way
    * @param defines A List holding define objects
    * @param commandLine The CommandLine to update
    * @return A string containing the defines as they're expected on the
    *      preprocessor
    * @exception BuildException if some define object is not valid (it does
    *      not contain a name attribute)
    */
   public String handleDefines(List defines, Commandline commandLine)
   {
      StringBuffer ret = new StringBuffer();
      if (!defines.isEmpty()) {
         String defineFlag = getDefineFlag();
         StringBuffer forCompiler = new StringBuffer();
         Iterator it = defines.iterator();
         while (it.hasNext()) {
            Define define = (Define) it.next();
            if (define.name == null) {
               throw new BuildException("defines must always include a name");
            }
            ret.append("#define ").append(define.name);
            forCompiler.append(defineFlag).append(define.name);
            if (define.value == null) {
               ret.append("\n");
            }
            else {
               ret.append(" ").append(define.value).append("\n");
               forCompiler.append("=").append(define.value);
            }
            commandLine.createArgument().setLine(forCompiler.toString());
            forCompiler.setLength(0);
         }
      }
      return ret.toString();
   }

   /**
    * Convert the specified includes into a string to be passed to the
    * IDLChecker, and updates the command line to reflect those includes on a
    * compiler-dependent way
    * @param include A Path object with the paths specified in the task
    * @param commandLine The CommandLine to update
    * @return A string containing the includes as they're expected on the
    *      preprocessor
    */
   public String handleIncludes(Path include, Commandline commandLine)
   {
      StringBuffer ret = new StringBuffer();
      if (include != null) {
         String includeFlag = getIncludeFlag();
      
         boolean twoArgCmd = includeFlag.charAt(includeFlag.length() - 1) == ' ';
         if (twoArgCmd) {
            includeFlag = includeFlag.trim();
         }
      
         String defs[] = include.list();
         for (int i = 0; i < defs.length; i++) {
            if (i > 0) {
               ret.append(File.pathSeparatorChar);
            }
            ret.append(defs[i]);
        
            if (twoArgCmd) {
               commandLine.createArgument().setValue(includeFlag);
               commandLine.createArgument().setValue(defs[i]);
            }
            else {
               commandLine.createArgument().setValue(includeFlag + defs[i]);
            }
         }
      }
      return ret.toString();
   }

   /**
    * Updates the command line to reflect the target dir on a
    * compiler-dependent way
    * @param targetDir
    * @param commandLine The CommandLine to update
    */
   public void handleTargetDir(File targetDir, Commandline commandline)
   {
      String targetFlag = getTargetDirFlag();
      if (targetFlag.charAt(targetFlag.length() - 1) == ' ') {
         // They are two arguments
         commandline.createArgument().setValue(targetFlag.trim());
         commandline.createArgument().setFile(targetDir);
      }
      else {
         // A single argument
         commandline.createArgument().setValue(targetFlag + targetDir.toString());
      }
   }

   /**
    * Updates the command line to reflect the flag checkAll on a
    * compiler-dependent way
    * @param checkAll as specified on the task
    * @param commandLine The CommandLine to update
    */
   public void handleCheckAllFlag(boolean checkAll, Commandline commandline)
   {
      if (checkAll) {
         commandline.createArgument().setLine(getCheckAllFlag());
      }
   }

   /**
    * Updates the command line to reflect the attribute verboseLevel on a
    * compiler-dependent way
    * @param level as specified on the task
    * @param commandLine The CommandLine to update
    */
   public void handleVerboseLevel(VerboseLevel level, Commandline commandline)
   {
      String translated = getVerboseFlag(level);
      if (translated != null) {
         commandline.createArgument().setLine(translated);
      }
      verboseBASIC = level.isBasic();
      verboseDEBUG = level.isVerbose();
   }

   /**
    * Convert the specified SideAttribute into 3 boolean flags, as expected
    * by the IDLChecker. Those flags must be accessed through other methods:
    * toGenerateClient(), toGenerateServer(), toGenerateTIEs()
    * It updates as well the command line to reflect the attribute on a
    * compiler-dependent way.
    * If some possibility is not valid for a specific compiler, it issues a
    * warning.
    * @param side A SideAttribute object,as specified in the task
    * @param commandLine The CommandLine to update
    */
   public void handleSideAttribute(SideAttribute side, Commandline commandLine)
   {
      String sideValue = side.getValue();
      generateClient = !sideValue.equals(SERVER) && !sideValue.equals(SERVERTIE);
      generateServer = !sideValue.equals(CLIENT);
      generateTIE = sideValue.equals(SERVERTIE) || sideValue.equals(ALLTIE);

      if (jdk) {
         commandLine.createArgument().setValue("-f" + sideValue);
      }
      else if (orbacus) {
         if (!generateServer) {
            commandLine.createArgument().setValue("--no-skeletons");
         }
         if (!generateClient) {
            throw new BuildException("Compiler " + ORBACUS + " does not accept " + SERVER
                  + " or " + SERVERTIE + " on the attribute <side>");
         }
         if (generateTIE) {
            commandLine.createArgument().setValue("--tie");
         }
      }
      else if (openorb) {
         if (!generateClient) {
            commandLine.createArgument().setValue("-nostub");
         }
         if (!generateServer) {
            commandLine.createArgument().setValue("-noskeleton");
         }
         if (!generateTIE) {
            commandLine.createArgument().setValue("-notie");
         }
      }
      else if (jacorb || jacorb2) {
         if (!generateServer) {
            commandLine.createArgument().setValue("-noskel");
         }
         if (!generateClient) {
            commandLine.createArgument().setValue("-nostub");
         }
         if (generateServer && !generateTIE) {
            throw new BuildException("Compiler " + JACORB + " does not accept " + SERVER
                  + " or " + ALL + " on the attribute <side>");
         }
      }
      else { // orbix2k
         if (generateServer) {
            commandLine.createArgument().setValue("-jpoa");
         }
         if (generateClient) {
            commandLine.createArgument().setValue("-jbase");
         }
         if (generateTIE) {
            throw new BuildException("Compiler " + ORBIX2K + " does not accept " + SERVERTIE
                  + " on the attribute <side>");
         }
      }
   }

   /**
    * Returns the string used by the compiler to specify an undefine
    */
   private String getUndefineFlag()
   {
      String ret = null;
      if (jdk || openorb) {
         throw new BuildException("Compiler " + (jdk ? JDK : OPENORB)
               + " does not accept <undefine> elements");
      }
      else {
         ret = "-U";
      }
      return ret;
   }

   /**
    * Returns the string used by the compiler to specify a define
    */
   private String getDefineFlag()
   {
      return jdk ? "-d " : openorb ? "-D " : "-D";
   }

   /**
    * Returns the string used by the compiler to specify a include
    */
   private String getIncludeFlag()
   {
      return jdk ? "-i " : openorb ? "-I " : "-I";
   }

   /**
    * Returns the string used by the compiler to specify the target dir
    */
   private String getTargetDirFlag()
   {
      return jdk ? "-td " : orbacus ? "--output-dir " : orbix2k ? "-O" : "-d ";
   }

   /**
    * Returns the string used by the compiler to specify how to create all the types
    */
   private String getCheckAllFlag()
   {
      String ret = null;
      if (orbix2k) {
         throw new BuildException("Compiler " + ORBIX2K + " does not accept <checkALL> elements");
      }
      else {
         ret = jdk ? "-emitAll" : orbacus ? "--all" : "-all";
      }
      return ret;
   }

   /**
    * Returns the string used by the compiler to specify the verbosity level
    * It can be null if no flag is required
    * @param level the Verbosity level to translate
    */
   private String getVerboseFlag(VerboseLevel level)
   {
      String ret = null;
      if (level.getValue().equals(DEBUG)) {
         ret = (jdk || orbix2k) ? "-v" : orbacus ? "-d" : (jacorb || jacorb2)? "-W 4" : null;
      }
      else if (level.getValue().equals(QUIET)) {
         ret = jdk ? "-noWarn" : orbix2k ? "-w" : null;
      }
      return ret;
   }

   /**
    * Enumerated attribute with the values "quiet", "verbose" and "debug".
    */
   public static class VerboseLevel extends EnumeratedAttribute
   {

      public VerboseLevel()
      {
         setValue(QUIET);
      }

      public String[] getValues()
      {
         return new String[] {QUIET, BASIC, DEBUG};
      }

      public boolean isVerbose()
      {
         return getValue().equals(DEBUG);
      }

      public boolean isBasic()
      {
         return getValue().equals(BASIC);
      }

   }


   /**
    * Enumerated attribute with the values "client","server"... (side parameter)
    */
   public static class SideAttribute extends EnumeratedAttribute
   {

      public SideAttribute()
      {
         setValue(ALLTIE);
      }

      public String[] getValues()
      {
         return new String[] {CLIENT, SERVER, ALL, SERVERTIE, ALLTIE};
      }

   }


   /**
    * Enumerated attribute with the values for the compiler attribute
    */
   public static class CompilerAttribute extends EnumeratedAttribute
   {

      public CompilerAttribute()
      {
         setValue(JDK);
      }

      public String[] getValues()
      {
         return new String[] {JDK, ORBACUS, JACORB, JACORB2, OPENORB, ORBIX2K};
      }

   }


   /**
    * Enumerated attribute with the values for the preprocess attribute
    */
   public static class PreprocessAttribute extends EnumeratedAttribute
   {

      public PreprocessAttribute()
      {
         setValue(DISMISS);
      }

      public String[] getValues()
      {
         return new String[] {DISMISS, STORE, STOREFULL, USE, USEFULL};
      }
      
      public boolean generatePreprocessorFile()
      {
         return !getValue().equals(DISMISS);
      }

      public boolean usePreprocessorFile()
      {
         return getValue().equals(USE) || getValue().equals(USEFULL);
      }

      public boolean expandFull()
      {
         return getValue().equals(STOREFULL) || getValue().equals(USEFULL);
      }

      public boolean useFull()
      {
         return getValue().equals(USEFULL);
      }

   }


   /**
    * Class used to specify the 'define' parameters
    */
   public static class Define extends Task
   {
      String name, value;
      public void setName(String name)
      {
         this.name = name;
      }

      public void setValue(String value)
      {
         this.value = value;
      }
   }


   /**
    * Class used to specify the 'undefine' parameters
    */
   public static class Undefine extends Task
   {
      String name;
      public void setName(String name)
      {
         this.name = name;
      }
   }

   /**
    * CLASS's DATA
    */
   static final String QUIET = "quiet";
   static final String BASIC = "basic";
   static final String DEBUG = "debug";
   static final String CLIENT = "client";
   static final String SERVER = "server";
   static final String ALL = "all";
   static final String SERVERTIE = "serverTIE";
   static final String ALLTIE = "allTIE";
   static final String JDK = "jdk";
   static final String ORBACUS = "orbacus";
   static final String JACORB = "jacorb";
   static final String JACORB2 = "jacorb2";
   static final String OPENORB = "openorb";
   static final String ORBIX2K = "orbix2k";
   static final String DISMISS = "dismiss";
   static final String STORE = "store";
   static final String STOREFULL = "storeFull";
   static final String USE = "use";
   static final String USEFULL = "useFull";
}

