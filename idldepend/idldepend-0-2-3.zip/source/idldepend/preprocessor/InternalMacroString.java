/**
  * File: InternalMacroString.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend.preprocessor;

import idldepend.javacc.generated.Token;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Definition of the internal macro '#'.
 * It needs one parameter, which is translated into a string. If the parameter
 *   contains the characters '"' or '\', those are scaped.
 * Additionally, the parameters are not expanded into their content: #A,
 * when A is defined as B is not translated into #B
 */
class InternalMacroString extends Macro {
  public InternalMacroString() {
    complex=true;
    numberOfParameters=1;
    name="#";
  }

  public String toString(){return "internal #";}

  public List expand(List parameters) {
    List ret = new ArrayList();
    ret.add(quoteToken);
    Iterator it=((List)parameters.get(0)).iterator();
    while(it.hasNext()) {
      Token next = (Token) it.next();
      if (next.kind==STRING) {
        String str = next.toString();
        next.image=("\\"+str.substring(0,str.length()-1)+"\\\"");
        ret.add(next);
      }
      else {
        if (next.image.equals(quoteToken.image) || next.image.equals(slashToken)) {
          ret.add(slashToken);
        }
        ret.add(next);
      }
    }
    ret.add(quoteToken);
    return ret;
  }

  public boolean disableParameterTranslation(){
    return true;
  }

  static protected Token quoteToken;
  static {
    quoteToken = new Token();quoteToken.kind=OTHER;quoteToken.image="\"";
  }
}

