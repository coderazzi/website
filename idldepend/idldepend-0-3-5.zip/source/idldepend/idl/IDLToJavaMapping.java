/**
 * File: IDLToJavaMapping.java
 * Author: LuisM Pena
 * Last update: 0.30, 1st July 2003
 * Please visit http://grasia.fdi.ucm.es/~luismi/idldepend for
 *   updates, download, license and copyright information
 **/

package idldepend.idl;


import java.io.File;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 * This class provides a mapping from IDL structures into file names
 * that must be created out of those structures.
 * This class is compliant with the "IDL to Java Language Mapping
 * Specification", Version 1.1, June 2001.
 */
public class IDLToJavaMapping
{

   /**
    * The constructor allows to specify how further mappings will be performed.
    * It admits three boolean flags, which affects to the interface's mapping:
    * -clientSide: if set, _stubs, helper and holders are needed
    * -serverSide: if set, _POA files is needed
    * -generateTIE: if serverSide is true, this flag specifies wether
    *    delegation-based interfaces are created (xxPOATie)
    */
   public IDLToJavaMapping(IDLMapperUser user, boolean clientSide, boolean serverSide, boolean generateTIE)
   {
      this.clientSide = clientSide;
      this.serverSide = serverSide;
      this.generateTIE = generateTIE;
      this.user = user;
   }

   /**
    * This method must be called when a new prefix rules
    */
   public void prefixPragma(String prefix)
   {
      currentPrefix = prefix;
   }

   /**
    * This method must be called when a new scope (module, interface, valuetype)
    * is entered.
    */
   public void enteredScope(String name, boolean module)
   {
      // assert moduleScope (it must be true)
      moduleScope = module;
      name = reservedWordsCare(name);
      if (module) {
         scope.add(name);
      }
      else {
         scope.add(name);
      }
   }

   /**
    * This method must be called when a scope (module, interface, valuetype)
    * is existed.
    */
   public void exitedScope()
   {
      moduleScope = true;
      scope.remove(scope.size() - 1);
   }

   /**
    * Maps the files that must be created when a const is found.
    */
   public void mapConst(String constName)
   {
      // mapping 1.6.1: consts inside interface does not produce new files
      // mapping 1.6.2: consts outside interfaces produce an interface with
      // the name of the const
      constName = reservedWordsCare(constName);
      if (moduleScope) {
         fileNeeded(createFileName(getScopePath(), constName, null));
      }
   }

   /**
    * Maps the files that must be created when an enum is found.
    */
   public void mapEnum(String enumName)
   {
      // mapping 1.7: three files are required, whose names are the name
      // of the enum, the same+"Helper" and the same+"Holder"
      enumName = reservedWordsCare(enumName);
      reportElementWithHolderAndHelper(enumName);
   }

   /**
    * Maps the files that must be created when a struct is found.
    */
   public void mapStruct(String structName)
   {
      // mapping 1.8: three files are required, whose names are the name
      // of the struct, the same+"Helper" and the same+"Holder"
      structName = reservedWordsCare(structName);
      reportElementWithHolderAndHelper(structName);
   }

   /**
    * Maps the files that must be created when a union is found.
    */
   public void mapUnion(String unionName)
   {
      // mapping 1.9: three files are required, whose names are the name
      // of the union, the same+"Helper" and the same+"Holder"
      unionName = reservedWordsCare(unionName);
      reportElementWithHolderAndHelper(unionName);
   }

   /**
    * Maps the files that must be created when an interface is found.
    * Because the mapping differs on weather the interface is abstract or
    * not, a second parameters is needed to specify it
    */
   public void mapInterface(String interfaceName, boolean abstractInterface)
   {
      // mapping 1.10: three files are required, whose names are the name
      // of the union, the same+"Helper" and the same+"Holder"
      // Additionally, it's generated NameOperations and _NameStub.
      // NamePOA and NamePOATie are optional.
      // In case of and abstract interface, nor the Operations neither
      // the POA or POATie are generated
      String scope = getScopePath();
      interfaceName = reservedWordsCare(interfaceName);
      fileNeeded(createFileName(scope, interfaceName, null), interfaceName);
      if (clientSide) {
         fileNeeded(createFileName(scope, interfaceName, HELPER_EXT), interfaceName);
         fileNeeded(createFileName(scope, interfaceName, HOLDER_EXT), interfaceName);
         fileNeeded(createFileName(scope, "_" + interfaceName, STUB_EXT), interfaceName);
      }
      if (!abstractInterface) {
         fileNeeded(createFileName(scope, interfaceName, OPERATIONS_EXT), interfaceName);
         if (serverSide) {
            fileNeeded(createFileName(scope, interfaceName, POA_EXT), interfaceName);
            if (generateTIE) {
               fileNeeded(createFileName(scope, interfaceName, TIE_EXT), interfaceName);
            }
         }
      }
   }

   /**
    * Maps the files that must be created when an exception is found.
    */
   public void mapException(String exceptionName)
   {
      // mapping 1.15: three files are required, whose names are the name
      // of the exception, the same+"Helper" and the same+"Holder"
      exceptionName = reservedWordsCare(exceptionName);
      reportElementWithHolderAndHelper(exceptionName);
   }

   /**
    * Maps the files that must be created when a valuetype is found.
    * The result depends on wether the valuetype defines a factory or
    * not, and therefore, an additional parameter is offered to specify it
    */
   public void mapValuetype(String valuetypeName, boolean withFactory)
   {
      // mapping 1.13: three files are required, whose names are the name
      // of the valuetype, the same+"Helper" and the same+"Holder"
      // If the valuetype includes a factory, another file is required
      // with extension ValueFactory
      String scope = getScopePath();
      valuetypeName = reservedWordsCare(valuetypeName);
      fileNeeded(createFileName(scope, valuetypeName, null), valuetypeName);
      fileNeeded(createFileName(scope, valuetypeName, HELPER_EXT), valuetypeName);
      fileNeeded(createFileName(scope, valuetypeName, HOLDER_EXT), valuetypeName);
      if (withFactory) {
         fileNeeded(createFileName(scope, valuetypeName, VALUEFACTORY_EXT), valuetypeName);
      }
   }

   /**
    * Maps the files that must be created when a valuebox is found.
    * The result depends on wether the valuebox is defined over a primitive
    * type or not, and therefore, an additional parameter is offered to specify it
    */
   public void mapValuebox(String valueboxName, boolean primitive)
   {
      // mapping 1.14: three files are required, whose names are the name
      // of the valuebox, the same+"Helper" and the same+"Holder"
      // If the valuebox is not build over a primitive, the first class,
      // (just the name) is not needed
      String scope = getScopePath();
      valueboxName = reservedWordsCare(valueboxName);
      fileNeeded(createFileName(scope, valueboxName, HELPER_EXT));
      fileNeeded(createFileName(scope, valueboxName, HOLDER_EXT));
      if (primitive) {
         fileNeeded(createFileName(scope, valueboxName, null));
      }
   }

   /**
    * Maps the files that must be created when a typedef is found.
    * The result depends on wether the typedef is defined over a sequence or array
    * or not, and therefore, an additional parameter is offered to specify it
    */
   public void mapTypedef(String typedefName, boolean sequenceOrArray)
   {
      // mapping 1.18: A helper file is always created. A holder is only
      // created for sequence or arrays
      String scope = getScopePath();
      typedefName = reservedWordsCare(typedefName);
      fileNeeded(createFileName(scope, typedefName, HELPER_EXT));
      if (sequenceOrArray) {
         fileNeeded(createFileName(scope, typedefName, HOLDER_EXT));
      }
   }

   /**
    * Creates a String[3], containing a holder, a helper, and the name
    * of the item itself
    */
   private void reportElementWithHolderAndHelper(String name)
   {
      String scope = getScopePath();
      fileNeeded(createFileName(scope, name, null));
      fileNeeded(createFileName(scope, name, HELPER_EXT));
      fileNeeded(createFileName(scope, name, HOLDER_EXT));
   }

   /**
    * Creates a file name taking in account the scope.
    * To the fileName is added the 'added' string, if it's not null
    */
   private String createFileName(String scope, String name, String added)
   {
      StringBuffer creator = new StringBuffer(scope).append(name);
      if (added != null) {
         creator.append(added);
      }
      return creator.append(FILE_EXT).toString();
   }

   /**
    * Returns an StringBuffer where the scope has been built in.
    */
   private String getScopePath()
   {
      StringBuffer ret = new StringBuffer();
      Iterator it = scope.iterator();
      while (it.hasNext()) {
         ret.append(it.next()).append(File.separatorChar);
      }
      if (!moduleScope) {
         ret.insert(ret.length() - 1, "Package");  // mapping 1.17
      }
      return ret.toString();
   }
  
   /**
    * Takes care that the name is not reserved. In that case, prepends '_'
    * It does the same if the name ends with Package, Helper, Holder
    **/
   private String reservedWordsCare(String name)
   {
      if (javaReservedList.contains(name)
            || (name.endsWith(PACKAGE_EXT) && !name.equals(PACKAGE_EXT))
            || (name.endsWith(HELPER_EXT) && !name.equals(HELPER_EXT))
            || (name.endsWith(HOLDER_EXT) && !name.equals(HOLDER_EXT))) {
         return "_" + name;
      }
      return name;
   }

   /**
    * Called to ise a user.fileNeeded request
    */
   private void fileNeeded(String name)
   {
      if (moduleScope) {
         user.fileNeeded(currentPrefix, name, null, false);
      }
      else {
         user.fileNeeded(currentPrefix, name, (String) scope.get(scope.size() - 1), true);
      }
   }

   private void fileNeeded(String name, String moduleOrInterface)
   {
      user.fileNeeded(currentPrefix, name, moduleOrInterface, false);
   }

   private String currentPrefix;
   private List scope = new ArrayList(); // String
   private boolean moduleScope = true;
   private boolean clientSide, serverSide, generateTIE;
   private IDLMapperUser user;

   private static final String PACKAGE_EXT = "Package";
   private static final String HOLDER_EXT = "Holder";
   private static final String HELPER_EXT = "Helper";
   private static final String OPERATIONS_EXT = "Operations";
   private static final String STUB_EXT = "Stub";
   private static final String POA_EXT = "POA";
   private static final String TIE_EXT = "POATie";
   private static final String VALUEFACTORY_EXT = "ValueFactory";
   private static final String FILE_EXT = ".java";
  
   private static Set javaReservedList;
   static {
      javaReservedList = new HashSet(); // those reserved in Java but also in IDL are not included
      javaReservedList.add("break");
      javaReservedList.add("byte");
      javaReservedList.add("catch");
      javaReservedList.add("class");
      javaReservedList.add("continue");
      javaReservedList.add("do");
      javaReservedList.add("else");
      javaReservedList.add("extends");
      javaReservedList.add("false");
      javaReservedList.add("final");
      javaReservedList.add("finally");
      javaReservedList.add("for");
      javaReservedList.add("goto");
      javaReservedList.add("if");
      javaReservedList.add("implements");
      javaReservedList.add("import");
      javaReservedList.add("instanceof");
      javaReservedList.add("int");
      javaReservedList.add("new");
      javaReservedList.add("null");
      javaReservedList.add("package");
      javaReservedList.add("protected");
      javaReservedList.add("return");
      javaReservedList.add("static");
      javaReservedList.add("super");
      javaReservedList.add("synchronized");
      javaReservedList.add("this");
      javaReservedList.add("throw");
      javaReservedList.add("throws");
      javaReservedList.add("transient");
      javaReservedList.add("true");
      javaReservedList.add("try");
      javaReservedList.add("volatile");
      javaReservedList.add("while");
      javaReservedList.add("strictfp");
   }
}

