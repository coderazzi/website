/**
  * File: JDKTranslator.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Commandline;

/**
 * Translator for the JDK.
 * Following is the behaviour of the parameters -pkgPrefix (translated into
 *   the task's parameter package) and -pkgTranslate (translated into translate)
 * 1- pkgPrefix is applied before any pkgTranslate. And pkgTranslate can
 *    modify the change done by pkgPrefix
 * 2- pkgPrefix requires always two parameters: <t>, called in the task
 *    'module' and <prefix>, called 'prefix'. 'module' cannot be complex,
 *    that is, it cannot include several modules, like in "modA.modB", but
 *    prefix can be.
 * 3- The result of applying pkgPrefix is to add the given prefix to any
 *    type whose top level module is 'module'. It also adds the prefix to
 *    any interface or valuetype defined at top level! This means that an
 *    interface called Iface, where -pkgPrefix Iface Add is applied, would
 *    produce files like Add/Iface.java, Add/IfaceHelper.java,
 *    Add/IfacePackage/..., etc
 * 4- pkgPrefix does not modify partial names. If a module is called 'moduleA'
 *    and the change must be done over 'mod', 'moduleA' is not modified. This
 *    behaviour applies the same for -pkgTranslate
 * 5- if two -pkgPrefix are specified, with the same 'module', it is the second
 *    one that stays. Two different -pkgPrefix are not applied on the same
 *    type.
 * 6- pkgTranslate also requires two parameters, here called 'module' and
 *    'package'. The result is that any type whose module structure STARTS with
 *    'module' is modified into 'package'. In this case, 'module' can be complex,
 *    the same as 'package'
 * 7- pkgTranslate does not affect to the names of interfaces or valuetypes,
 *    that is, an interface called Iface does not modify its name when
 *    -pkgTranslate Iface Mod is applied.
 * 8- If two pkgTranslate are defined with the same 'module', only the latest
 *    specification is used.
 * 9- When several pkgTranslates are specified, they are applied secuentially,
 *    in the specification order. But once that a pkgTranslate has modified
 *    a type, no more translations are applied.
 */
class JDKTranslator extends Translator
{
  List packages, translates, inputPackages, inputTranslates;

  public JDKTranslator(List inputPackages, List inputTranslates) throws BuildException
  {
    this.inputPackages=inputPackages;
    this.inputTranslates=inputTranslates;
    this.packages=new ArrayList();
    this.translates=new ArrayList();

    checkPackages(inputPackages, packages);
    checkTranslates(inputTranslates, translates);
  }

  /**
   * Modifies the file to include the defined translations
   */
  public String translate(String pragmaPrefix, String file, String iface, boolean typeInInterface)
  {
    return applyTranslates(applyPackages(file, iface, typeInInterface));
  }

  /**
   * Modifies the commandLine to reflect the packages and translates founds.
   */
  public void modifyCommandline(Commandline command) {
    StringBuffer buffer = new StringBuffer("-pkgPrefix "); //length=11;
    Iterator it = inputPackages.iterator();
    while(it.hasNext()) {
      PackageTask task = (PackageTask) it.next();
      buffer.append(task.module).append(' ').append(task.prefix);
      command.createArgument().setLine(buffer.toString());
      buffer.setLength(11);
    }
    if (!translates.isEmpty()) {
      buffer.setLength(0);
      buffer.append("-pkgTranslate "); //length=14
      it = inputTranslates.iterator();
      while(it.hasNext()) {
        TranslateTask task = (TranslateTask) it.next();
        buffer.append(task.moduleName).append(' ').append(task.packageName);
        command.createArgument().setLine(buffer.toString());
        buffer.setLength(14);
      }
    }
  }

  /**
   * Verifies that all the packages contain a prefix and a module, and
   * no auto. It also verifies the values for module and prefix, removing
   * any traling spaces if required
   * @param packages the input packages
   * @param toUse a list to include the packages to be used on later translations
   */
  private void checkPackages(List packages, List toUse) throws BuildException
  {
    Iterator it = packages.iterator();
    while(it.hasNext()) {
      PackageTask task = (PackageTask) it.next();
      if (task.module==null) {
        throw new BuildException("Using compiler JDK, every <package> must contain a module attribute");
      }
      if (task.prefix==null) {
        throw new BuildException("Using compiler JDK, every <package> must contain a prefix attribute");
      }
      if (task.auto) {
        throw new BuildException("Using compiler JDK, <package> does not accept the attribute auto");
      }
      String module = getValidModule(task.module);
      String prefix = normalize(task.prefix, "prefix");
      toUse.add(new PackageTask(module, prefix+File.separatorChar, false));
    }
  }

  /**
   * Verifies that all the translates contain a package and a module
   * It also verifies the values for module and package, removing
   * any traling spaces if required.
   * If there are two translates with the same moduleName, only the second one is kept.
   * It must be noted that, on the other side, if two translates are not the same but
   *    apply to the same module, the first specified is the one that is used!
   * @param translates the input translates
   * @param toUse a list to include the packages to be used on later translations
   */
  private void checkTranslates(List translates, List toUse) throws BuildException
  {
    HashMap map = new HashMap();
    Iterator it = translates.iterator();
    while(it.hasNext()) {
      TranslateTask task = (TranslateTask) it.next();
      if (task.moduleName==null || task.packageName==null) {
        throw new BuildException("Using compiler JDK, every <translate> must contain a module and package attribute");
      }
      String moduleName = normalize(task.moduleName, "module")+File.separatorChar;
      String packageName = normalize(task.packageName, "package")+File.separatorChar;
      TranslateTask previousTask = (TranslateTask) map.get(moduleName);
      if (previousTask==null)
      {
        previousTask = new TranslateTask(moduleName, packageName);
        toUse.add(previousTask);
        map.put(moduleName, previousTask);
      }
      else
      {
        previousTask.setPackage(packageName);
      }
    }
    map.clear();
  }

  /**
   * Apply the packages defined, until it is found one that modifies the result
   * In JDK, this means to find if the starting of the file matches any of the
   * packages. The matching has to be complete for a module (it does not match
   * part of the name of a module). The exceptions are types inside interfaces.
   * Here, it is enough to match up to 'Package'
   */
  private String applyPackages(String file, String iface, boolean typeInInterface) {
    //note that the search is done from the end: if two packages are defined
    //for the same module, the last one is the valid
    ListIterator it = packages.listIterator(packages.size());
    while(it.hasPrevious()) {
      PackageTask pack = (PackageTask) it.previous();
      boolean ok=false;
      if (file.startsWith(pack.module)) {
        int len = pack.module.length();
        ok = (file.length()>len) && (file.charAt(len)==File.separatorChar);
      }
      if (!ok && iface!=null && pack.module.equals(iface)) {
        //and the interface has to be top level. If it's a type inside
        //an interface, there can be just one level before
        int idx = file.indexOf(File.separatorChar);
        if (typeInInterface) {
          //not needed to check that file starts with iface + "Package/"
          ok = idx==file.lastIndexOf(File.separatorChar);
        }
        else {
          ok=idx==-1;
        }
      }
      if (ok) {
        return pack.prefix + file;
      }
    }
    return file;
  }

  /**
   * Apply the translates defined, until it is found one that modifies the result
   * In JDK, this means to find if the starting of the file matches any of the
   * packages. The matching has to be complete for a module (it does not match
   * part of the name of a module), and this is the reason why the packages were
   * internally stored with a triling slash
   */
  private String applyTranslates(String file) {
    Iterator it = translates.iterator();
    while(it.hasNext()) {
      TranslateTask translate = (TranslateTask) it.next();
      if (file.startsWith(translate.moduleName)) {
        return translate.packageName + file.substring(translate.moduleName.length());
      }
    }
    return file;
  }
}