/**
  * File: IDLChecker.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend;

import idldepend.idl.IDLMapperUser;
import idldepend.idl.IDLToJavaMapping;
import idldepend.javacc.FileIncluder;
import idldepend.javacc.generated.ParseException;
import idldepend.preprocessor.PreprocessorController;
import idldepend.preprocessor.PreprocessorUser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import idldepend.javacc.generated.IDLParser;

/**
 * This class is the responsible to perform the checking of the files to be
 * generated. This checking is done in two ways: or using a dependency file,
 * previously generated, where the dependencies can be obtained, or parsing
 * the specified IDL file (and generating the dependency file for any
 * further checking).
 */
class IDLChecker extends Thread implements PreprocessorUser, IDLMapperUser
{
  /**
   * @param idlFile the file to check
   * @param uniqueId an identity that can identify this generation uniquely,
   *     to track dependencies (two generations of the same file with different
   *     parameters will produce different dependencies)
   * @param dependsDir the directory where the dependency files are stored
   * @param targetDir the directory where the .java files must be located
   * @param includePath an string containing the include path
   * @param defines an string containing all the defines. They must be written in
   *    as the preprocessor expects them: #define symbol [value]
   *    In fact, this string can contain any information, as it is passed to the
   *    preprocessor
   * @param client set to true when the client-side files must be generated
   * @param server set to true when the server-side files must be generated
   * @param ties set to true when the server-side delegated-based files must be generated
   * @param checkAll set to true when the included files are also checked into the files
   *    that must been generated
   * @param translator the Translator to use to convert the file names
   * @param verbose set to true to get some information during the checking
   * @param debug set to true to get all the information during the checking
   * @param logger is the object to use to log any information
   */
  public IDLChecker(File idlFile, UniqueDependencyId uniqueId,
      File dependsDir,  File targetDir,
      String includePath, String addedToPrep,
      boolean client, boolean server, boolean ties, boolean checkAll,
      Translator translator, boolean verbose, boolean debug, Logger logger)
  {
    this.addedToPrep=addedToPrep;
    this.idlFile=idlFile;
    this.verbose=verbose;
    this.debug=debug;
    this.checkAll=checkAll;
    this.translator=translator;
    this.logger=logger;
    try {
      //it is verified the dependencies file, to avoid rescanning the IDL file
      //if possible
      checker = new DependenciesChecker(idlFile, uniqueId, dependsDir,
          targetDir, verbose, debug, logger);
      if (checker.generateDependencies())
      {
        try {
          checker.startDependenciesGeneration();

          //there are two parses to start, which work together.
          //First, the preprocessor, whose output is read by a PreprocessorUser
          // (this class). When the tokens are received, they are passed to the
          // IDL parser, whose output is read by a IDLMapperUser (also this class)
          preprocessor=new PreprocessorController(this);
          preprocessor.addPath(includePath);
          output = new PipedWriter();
          writer = new PrintWriter(output);
          idlParser = new IDLParser(new PipedReader(output),
            new IDLToJavaMapping(this, client, server, ties));

          //this Thread reads the token from the preprocessor output
          start();

          //and this second Thread starts the preprocessor
          new RunPreprocessor().start();
        }
        catch(IOException ioex) {
          checker.stopDependenciesGeneration(false);
          if (verbose) {
            logger.log(ioex.toString());
            build(true);
          }
        }
      }
      else {
        //if the dependencies file exists and it is updated (not older than
        //the idl file to check), the IDL file is not parsed, and is already
        //possible to know if it's needed to do the code generation again
        build(checker.build());
      }
    }
    catch(FileNotFoundException fe) {
      if (verbose) {
        logger.log(fe.toString());
        build(true);
      }
    }
  }

  /**
   * Blocks until the parse is completed, returning true if the dependencies
   * show that the source must be compiled
   */
  public synchronized boolean build() {
    while(!resultReady) {
      try {wait();}catch(InterruptedException iex){}
    }
    return buildResult;
  }

  /**
   * Internal method, used to specify weather the dependencies have been
   * completed.
   * @param toBuild is set to true if the dependencies show that the output
   *    files must be generated.
   */
  private synchronized void build(boolean toBuild) {
    if (preprocessor!=null) {
      preprocessor.stopParsing();
    }
    if (resultReady==false) {
      buildResult=toBuild;
    }
    resultReady=true;
    notifyAll();
  }

  /**
   * Thread public method.
   * It starts the IDLParser on a second thread.
   */
  public void run() {
    if (this==currentThread()) {
      try {
        idlParser.parse();
        checker.stopDependenciesGeneration(true);
        build(checker.build());
      }
      catch(ParseException ex) {
        //when a parse exception is found parsing the idl file,
        //a message is printed out, and the file is considered to
        //need a rebuild (which should fail as well, perhaps it
        //would be better just to exit on error)
        checker.stopDependenciesGeneration(false);
        if (verbose) {
          logger.log(ex.toString());
        }
        build(true);
      }
      finally {
        writer.close();
        try{output.close();}catch(IOException iex){}
      }
    }
  }

  /**
   * IDLMapperUser public method, issued by the IDL parser when a new tyoe
   * is found to be required.
   */
  public void fileNeeded(String pragmaPrefix, String file, String iface, boolean typeInInterface) {
    if (!resultReady) {
      String translatedFile=translator.translate(pragmaPrefix, file,iface,typeInInterface);
      checker.addTarget(translatedFile);
    }
  }

  /**
   * Error found by the preprocessor while reading the IDL file
   */
  public void asynchronousException(Exception exception) {
    if (!resultReady) {
      if (verbose) {
        logger.log(exception.toString());
      }
      build(true);
    }
  }

  /**
   * Method called by the preprocessor/parser when an include statement
   * is read.
   * This allows for excluding types not belonging to the original file
   */
  public void includingFile(String file) throws ParseException {
    ++inclusion;   
    if (!resultReady) {
      checker.addSource(new File(file));
    }
   //store information on the file: in special, how many times is included 
   //(and is still being included, to trace recursion)
   includedFilesStack.add(file); //to know the last included file
   int included=1;
   Integer inMap = (Integer) includedFilesInfo.get(file);
   if (inMap!=null) included+=inMap.intValue();
    if (included >=  MAX_RECURSION_DEPTH) {
     throw new ParseException("include recursion too deep");
   }
   includedFilesInfo.put(file, new Integer(included));
  }

  /**
   * Method called by the preprocessor/parser when an include statement
   * has been completed
   * This allows for excluding types not belonging to the original file
   */
  public void fileIncluded() throws ParseException{
    --inclusion;
   if (includedFilesStack.size()==0)
     throw new ParseException("Internal IDLDEPEND error");
    String file = (String) includedFilesStack.remove(0);
   Integer inMap = (Integer) includedFilesInfo.remove(file);
   if (inMap==null)
     throw new ParseException("Internal IDLDEPEND error");
    int included = inMap.intValue()-1;
   if (included>0)
     includedFilesInfo.put(file, new Integer(included));
  }

  /**
   * Preprocessor warning (like redefining a macro)
   */
  public void warning(String message)
  {
    if (!resultReady && verbose) {
      logger.log("Warning: " + message);
    }
  }

  /**
   * Specific preprocessor warning
   */
  public void unknownDirective(String content)
  {
    if (!resultReady && debug) {
      logger.log("Unknown directive: " + content);
    }
  }

  /**
   * Token read by the preprocessor, to be passed to the IDL parser
   */
  public void token(String t)
  {
    if ((!resultReady) && (checkAll || (inclusion==0))) {
      writer.print(t);
    }
  }

  /**
   * Inner class to start the preprocessor on a second thread
   */
  private class RunPreprocessor extends Thread {
    public void run() {
      try {
        preprocessor.parseInput(idlFile, addedToPrep);
      }
      catch(Exception pex) {
        if (verbose) {
          logger.log(pex.toString());
        }
        build(true);
      }
    }
  }

  private PreprocessorController preprocessor;
  private PrintWriter writer;
  private PipedWriter output;
  private IDLParser idlParser;
  private boolean verbose, debug, checkAll;
  private DependenciesChecker checker;
  private int inclusion=0;
  private File idlFile;
  private String addedToPrep;
  private Translator translator;
  private Logger logger;
  private List includedFilesStack = new ArrayList();
  private Map includedFilesInfo = new HashMap();

  private boolean buildResult, resultReady;
  private static int MAX_RECURSION_DEPTH = 400; //like in 'normal' gcc or Solaris CC...
}

