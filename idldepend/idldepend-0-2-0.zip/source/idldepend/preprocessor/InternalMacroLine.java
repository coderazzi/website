/**
  * File: InternalMacroLine.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend.preprocessor;

import idldepend.javacc.generated.ParseException;
import idldepend.javacc.generated.PreprocessorConstants;
import idldepend.javacc.generated.Token;

import java.util.ArrayList;
import java.util.List;

/**
 * Definition of the internal macro '__LINE__'.
 * It needs no parameters
 */
class InternalMacroLine extends Macro {

  /**
   * The constructor requires the PreprocessorController, to be able to retrieve the
   * file being processed
   */
  public InternalMacroLine(PreprocessorController controller) {
    complex=false;
    numberOfParameters=0;
    name="__LINE__";
    this.controller=controller;
  }

  public List expand(List parameters) throws ParseException{
    Token line = new Token();
    line.kind = PreprocessorConstants.OTHER; //no really...
    line.image = String.valueOf(controller.getLine());
    List ret=new ArrayList();
    ret.add(line);
    return ret;
  }

  private PreprocessorController controller;
}

