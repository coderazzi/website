/**
  * File: PreprocessorUser.java
  * Author: LuisM Pena
  * Version: 0.11
  * Copyright: Some open license will be used. Currently, it is just beta software,
  *            to be used 'as is', without author's responsabilities.
  *            Any bug or limited support can be addressed through luicpend@yahoo.com
  **/

package idldepend.preprocessor;

import idldepend.javacc.FileIncluder;
import idldepend.javacc.generated.ParseException;

import java.io.File;

/**
 * This interfaces defines the external operations which are called by
 * the preprocessor while parsing the input
 */
public interface PreprocessorUser
{
  /**
   * Called when a new file is being included
   */
  public void includingFile(String file) throws ParseException;

  /**
   * Called after a new file has been included
   */
  public void fileIncluded() throws ParseException;

  /**
   * Called when a #directive (unknown) tag has been found.
   */
  public void unknownDirective(String content) throws ParseException;

  /**
   * Asynchronous exception found while preprocessing the file
   */
  public void asynchronousException(Exception exception);

  /**
   * A special situation has been found.
   */
  public void warning(String message);

  /**
   * token read out of the parsing file, filtered through the macros
   */
  public void token(String t);

}
