package SplitFile;

/**
  * This class allows to create a block of memory where two different processes
  * (threads) can read and write in a synchronized way.To facilitate the
  * communication between the threads this block of memory is an instance of
  * a BufferMemory interface, allowing any particular implementation<br>
  * A thread can get a write buffer, that should release later. Another (or the same)
  * thread can get the same buffer to read it, and also it will have to release it.<br>
  * For implementation purposes, two buffers are created, to allow the
  * concurrent read and write.
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
class RWMemory
{
	/**
	  * The constructor needs two BufferMemory
	  * @param firstBuffer a BufferMemory (the order doesn't mind)
	  * @param secondBuffer a BufferMemory (the order doesn't mind)
	  */
	public RWMemory(BufferMemory firstBuffer, BufferMemory secondBuffer)
	{
		writting=reading=false;
		freeBuffers=2;
		cursor=0;
		buffers=new BufferMemory[2];
		buffers[0]=firstBuffer;
		buffers[1]=secondBuffer;
	}
	
	/**
	  * Gets a buffer to write in. This buffer should be released later.
	  * @return a buffer to introduce new data
	  * @exception InterruptedException Another thread has interrupted this one, making
	  * unsafe to continue working with the current instance of RWMmemory 
	  */
	public synchronized BufferMemory getWriteMemory() throws InterruptedException
	{
		while (writting)	//not two Write Buffers at same time
			wait();
		writting=true;
		while (freeBuffers==0)	//wait to have a free buffer
			wait();
		return buffers[cursor];
	}
	
	/**
	  * Release a buffer previously got to write in.If there was no buffers
	  * previously got, it does nothing.
	  */
	public synchronized void releaseWriteMemory()
	{
		if (writting)
		{
			--freeBuffers;
			cursor=(cursor+1)%2;
			writting=false;
			notifyAll();
		}
	}
	
	/**
	  * Gets a buffer to read off. This buffer is suposed to contains valid data (that is,
	  * it has been got as WriteMemory previously).  This buffer should be released later.
	  * @return a buffer with valid data
	  * @exception InterruptedException Another thread has interrupted this one, making
	  * unsafe to continue working with the current instance of RWMmemory 
	  */
	public synchronized BufferMemory getReadMemory() throws InterruptedException
	{
		while (reading)	//not two Read Buffers at same time
			wait();
		reading=true;
		while (freeBuffers==2)	//wait to have a buffer wrote
			wait();
		int readCursor=(freeBuffers==0)? cursor : (cursor+1)%2;
		return buffers[readCursor];
	}
	
	/**
	  * Release a buffer previously got to read off.If there was no buffers
	  * previously got, it does nothing.
	  */
	public synchronized void releaseReadMemory()
	{
		if (reading)
		{
			++freeBuffers;
			reading=false;
			notifyAll();
		}
	}
	
	private boolean writting;					//A buffer has been got to write
	private boolean reading;					//A buffer has been got to read
	private int freeBuffers;					//Number of free buffers (0,1,2)
	private int cursor;								//pointer to a buffer
	private BufferMemory buffers[];	//buffers
}