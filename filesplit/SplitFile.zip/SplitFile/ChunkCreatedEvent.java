package SplitFile;

/**
  * Event throwed when an new chunk file is created
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class ChunkCreatedEvent extends SplitFileEvent
{
	/**
	  * @param fileName name of the chunk being created
	  * @param nChunk the sequence number for this chunk
	  * @param chunkSize the size of this chunk
	  */
	public ChunkCreatedEvent(String fileName, long nChunk, 
				long chunkSize)
	{
		this.fileName=new String(fileName);
		this.nChunk=nChunk;
		this.chunkSize=chunkSize;
	}
	
	/**
	  * Gets the name of the file being splitted
	  * @return the name of the file being splitted
	  */
	public String getFileName()
	{
		return fileName;
	}
	
	/**
	  * Gets the number of this chunk in the sequence of chunks being created. The first is the 1
	  * @return the sequence number for this chunk
	  */
	public long getSequenceNumber()
	{
		return nChunk;
	}
	
	/**
	  * Gets the size of the chunk being created
	  * @return the size of the file
	  */
	public long getFileSize()
	{
		return chunkSize;
	}
	
	private String fileName;
	private long nChunk;
	private long chunkSize;
}