package SplitFile;

/**
  * Event throwed periodically when a number of bytes of the chunk are wrote
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class WriteEvent extends SplitFileEvent
{
	/**
	  * @param bytesWritten number of bytes already written (in the chunk)
	  * @param fileWritten true if the chunk has been completely written
	  */
	public WriteEvent(long bytesWritten, boolean fileWritten)
	{
		this.bytesWritten=bytesWritten;
		this.fileWritten=fileWritten;
	}
	
	/**
	  * Gets number of bytes already written
	  * @return the number of bytes already written
	  */
	public long getBytesWritten()
	{
		return bytesWritten;
	}
	
	/**
	  * Member to know if the file write has finished
	  * @return true if the file has been completely written
	  */
	public boolean isFileWritten()
	{
		return fileWritten;
	}
	
	private boolean fileWritten;
	private long bytesWritten;
}