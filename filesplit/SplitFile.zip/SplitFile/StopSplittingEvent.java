package SplitFile;

/**
  * Event throwed when the splitting finishes
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class StopSplittingEvent extends SplitFileEvent
{
}