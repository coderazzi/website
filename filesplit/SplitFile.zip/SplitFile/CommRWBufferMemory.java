package SplitFile;

/**
  * This class implements the BufferMemory to allow the communication between
  * the read and write threads (FileRead / FileWrite).<br>
  * It is a block of bytes, with a fixed size, that allows to communicate:
  *	-the real data length in the block
  * -if the write operations have finished (that is, if there is nothing else to read)
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
class CommRWBufferMemory implements BufferMemory
{
	/**
	  * The constructor needs to have the size of the block of memory
	  * @param size the size of the block
	  */
	public CommRWBufferMemory(int size)
	{
		buffer=new byte[size];
		maxSize=size;
		this.size=size;
		eop=false;
	}
	
	/**
	  * This method returns the buffer allocated
	  * @return the buffer
	  */
	public byte[] getBuffer()
	{
		return buffer;
	}
	
	/**
	  * This method returns the size of the buffer; this value won't change
	  * during the CommRWBufferMemory lifetime
	  * @return the size of the buffer
	  */
	public int getMaxSize()
	{
		return maxSize;
	}
	
	/**
	  * This method sets the size of the data stored in the buffer; 
	  * @param size the size of the data stored in the buffer. No checks are done
	  */
	public void setSize(int size)
	{
		this.size=size;
	}
	
	/**
	  * This method returns the size of the data stored in the buffer; 
	  * @return the size of the dat stored in the buffer
	  */
	public int getSize()
	{
		return size;
	}
	
	/**
	  * This method set the End Of Operation flag
	  */
	public void setEOP()
	{
		eop=true;
	}
	
	/**
	  * This method gives the End Of Operation flag
	  * @return the End Of Operation flag
	  */
	public boolean isEOP()
	{
		return eop;
	}
	
	private byte buffer[];	//buffer
	private final int maxSize;		//buffer size
	private int size;				//data length
	private boolean eop;		//End Of Operation
}