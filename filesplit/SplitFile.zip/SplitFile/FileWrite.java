package SplitFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.Observable;
import java.util.Observer;

/**
  * This class allows to write a file in a separate thread.
  * It is an observable class, that launch the following events:
  * -ErrorSplittingEvent: when an error is produced. If the error is produced in the
  *	 	beginning, before opening the file to split (or opening it), this event will
  * 	be thrown without a previous StartSplittingEvent<br>
  * -ChunkCreatedEvent: when a new chunk file is created. It includes the name of the
  * 	file created, its sequence number, and its length.<br>
  * -WriteEvent: every n bytes written, this event is thrown. It includes the number of
  * 	bytes already written (in the current chunk), and the write state 
  * 	(finished or not). The thrown of this event can be controlled<br>
  * -FinishOpEvent: when the operation fisnishes<br>
  *
  * To use this class, use just the startReading and stopReading methods, don't 
  *	create a new Thread explictly.
  *
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
class FileWrite extends Observable implements Runnable
{
	/**
	  * The constructor needs to have a RWMemory to get the data, a 
	  * NamingAlgorythm to name the files created, the total number of bytes 
	  * to write, and the max size of each chunk
	  * Even if firstChunk is greater than 1, FileWrite will use the data on
	  * RWMemory from start (no skip is done).
	  * @param memory the RWMemory to use as shared buffer with the FileRead
	  * @param nameAlg to name the files created
	  * @param write the total number of bytes to write
	  * @param maxChunkSize the max size of each chunk
	  */
	public FileWrite(RWMemory memory, NamingAlgorythm nameAlg, long write,
										long maxChunkSize)
	{
		this.memory=memory;
		this.nameAlg=nameAlg;
		this.currentChunk=1;
		this.chunkSize=maxChunkSize;
		this.write=write;
		thisChunkSize=0;
		file=null;
		thread=null;
	}
	
	/**
	  * This method starts (if not done before) a thread to write the file.
	  * It returns inmediatly; to know when the writting has finished, it is
	  * launched an event (FinishOpEvent)
	  * @param observer An observer for the operation
	  * @param sendWriteEvents false to avoid the sending of WriteEvents
	  */
	public void startWritting(Observer observer, boolean sendWriteEvents)
	{
		if (thread==null)
		{
			addObserver(observer);
			this.sendWriteEvents=sendWriteEvents;
			thread=new Thread(this);
			thread.start();
		}	
	}
	
	/**
	  * This method stops the writting on the chunks
	  */
	public synchronized void stopWritting()
	{
		if (thread!=null)
		{
			thread.stop();
			endAnyOp();
		}	
	}
	
	/**
	  * Destroys any resource still used
	  */
	synchronized void endAnyOp()
	{
		if (file!=null)
			try{file.close();}catch(Exception ex){}	//in normal end, the file is already closed
		deleteObservers();
		file=null;
		memory=null;
		nameAlg=null;
		thread=null;
	}
	
	/**
	  * This method shouldn't be directly called
	  */
	public void run()
	{
		ErrorSplittingEvent ev=null;
		try
		{
			while(ev==null && write>0)
			{
				CommRWBufferMemory buffer=(CommRWBufferMemory)memory.getReadMemory();
				ev=writeFile(buffer.getBuffer(),buffer.getSize(), buffer.isEOP());
				memory.releaseReadMemory();
			}
		}
		catch(InterruptedException ie)
		{
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.INTERNAL_ERROR3);
		}
		catch(java.io.IOException ioe)
		{
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.IOEXCEPTION_WRITTING);
		}
		setChanged();
		if (ev!=null)
			notifyObservers(ev);
		else
			notifyObservers(new FinishOpEvent());
		endAnyOp();
	}
	
	/**
	  * Write the specified number of bytes that are allocated in the buffer.
	  * @param buffer the data storage
	  * @param bytes	the data length
	  * @param EOF true if there are no more bytes to write
	  * @returns ErrorSplittingEvent if it si sproduced an internal error, or null if not
	  * @exception IOException if there is some IO problem with the chunk file
	  */	
	ErrorSplittingEvent writeFile(byte []buffer, int bytes, boolean EOF) throws IOException
	{
		ErrorSplittingEvent ev=null;
		if (bytes>write)
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.INTERNAL_ERROR1);
		else
		{
			int start=0;
			while (start < bytes)
			{
				file=getOutputFile();
				int toWrite=bytes-start;	
				if (toWrite>chunkWrite)
					toWrite=(int)chunkWrite;	//safe conversion
				file.write(buffer,start,toWrite);
				start+=toWrite;
				write-=toWrite;
				chunkWrite-=toWrite;
				if (sendWriteEvents)
				{
					setChanged();
					notifyObservers(new WriteEvent(thisChunkSize-chunkWrite,chunkWrite==0));
				}
				if (chunkWrite==0)
				{
					file.close();
					file=null;
				}
			}
		
			if (write>0 && EOF)
				ev=new ErrorSplittingEvent(ErrorSplittingEvent.INTERNAL_ERROR2);
		}
		return ev;
	}
	
	/**
	  * Method to get the output file. It returns the class variable 'file'; if it
	  * is null, it opens a new file using the NamingAlg.
	  * It also updates the variable chunkWrite, if it is needed
	  * @return a valid output file
	  * @throws IOException if the file can not be created
	  */
	FileOutputStream getOutputFile() throws IOException
	{
		if (file==null)
		{
			File createFile=nameAlg.getOutputFile(currentChunk);
			chunkWrite=chunkSize;
			if (chunkWrite>write)
				chunkWrite=write;
			thisChunkSize=chunkWrite;
			setChanged();
			notifyObservers(new ChunkCreatedEvent(createFile.getName(),currentChunk++,chunkWrite));
			file=new FileOutputStream(createFile);
		}
		return file;
	}
	
	private RWMemory memory;
	private NamingAlgorythm nameAlg;
	private long currentChunk;
	private long chunkSize;
	private long write;
	private long thisChunkSize;

	private FileOutputStream file;
	private long chunkWrite;
	private boolean sendWriteEvents;
	
	private Thread thread;
}