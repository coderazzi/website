package SplitFile;

/**
  * Event throwed when the splitting starts
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class StartSplittingEvent extends SplitFileEvent
{
	/**
	  * @param fileName name of the file being splitted
	  * @param fileSize the size of the file
	  * @param nChunks number of chunks that are going to be created
	  * @param chunkSize the size of each Chunk (the last one can be smaller)
	  */
	public StartSplittingEvent(String fileName, long fileSize, 
				long nChunks, long chunkSize)
	{
		this.fileName=new String(fileName);
		this.fileSize=fileSize;
		this.nChunks=nChunks;
		this.chunkSize=chunkSize;
	}
	
	/**
	  * Gets the name of the file being splitted
	  * @return the name of the file being splitted
	  */
	public String getFileName()
	{
		return fileName;
	}
	
	/**
	  * Gets the number of chunks that will be created
	  * @return the number of chunks that will be created
	  */
	public long getNumberOfChunks()
	{
		return nChunks;
	}
	
	/**
	  * Gets the size of the file being splitted
	  * @return the size of the file
	  */
	public long getFileSize()
	{
		return fileSize;
	}
	
	/**
	  * Gets the size of each chunk (the last one can be smaller)
	  * @return the size of each chunk
	  */
	public long getChunkSize()
	{
		return chunkSize;
	}
	
	private String fileName;
	private long nChunks;
	private long fileSize, chunkSize;
}