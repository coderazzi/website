package SplitFile;

/**
  * private class to define an internal event used by the FileRead and FileWrite classes
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1,0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
class FinishOpEvent extends SplitFileEvent
{
}