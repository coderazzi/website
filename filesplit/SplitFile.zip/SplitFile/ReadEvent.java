package SplitFile;

/**
  * Event throwed periodically when a number of bytes of the splitting file are read
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class ReadEvent extends SplitFileEvent
{
	/**
	  * @param bytesRead number of bytes already read
	  * @param fileRead true if the file has already been read
	  */
	public ReadEvent(long bytesRead, boolean fileRead)
	{
		this.bytesRead=bytesRead;
		this.fileRead=fileRead;
	}
	
	/**
	  * Gets number of bytes already read
	  * @return the number of bytes already read
	  */
	public long getBytesRead()
	{
		return bytesRead;
	}
	
	/**
	  * Member to know if the file read has finished
	  * @return true if the file has been completely read
	  */
	public boolean isFileRead()
	{
		return fileRead;
	}
	
	private boolean fileRead;
	private long bytesRead;
}