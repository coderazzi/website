package SplitFile.Prg;

import java.io.IOException;

import SplitFile.ListChunks;

/**
  * This abstract class implements glue as batch files
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
abstract public class BatchGlue 
{
	abstract public void createGlue(ListChunks chunks,String batchFile, String sourceFile) throws IOException;
}