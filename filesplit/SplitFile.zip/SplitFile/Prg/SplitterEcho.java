package SplitFile.Prg;

/**
  * SplitterDisplay that shows the splitter information on the System.out and
  * System.err outputs
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

public class SplitterEcho implements SplitterDisplay
{
	/**
	  * @param show false to show only errors
	  */
	public SplitterEcho(boolean show)
	{
		this.show=show;
	}
	
	/**
	  * Method to show some information
	  * @param msg The message to show
	  */
	public void showMessage(String msg)
	{
		if (show)
			System.out.print("\n"+msg);
	}
	
	/**
	  * Method to show an error message
	  * @param error the error to show
	  */
	public void showError(String error)
	{
		System.err.print("\n"+error);
	}
	
	
	/**
	  * Method to show the progress done on read
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setReadProgress(int progress)
	{
	}
	
	/**
	  * Method to show the progress done on writting (on a chunk)
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setWriteProgress(int progress)
	{
		if (show && progress>0)
			System.out.print(".");
	}

	/**
	  * This is not a showing information method, but the way the Splitting class will use
	  * to say that has finished its task
	  * @param error true if the splitting has finished by an error
	  */
	public void splittingFinished(boolean error)
	{
	}
	
	boolean show;
}