package SplitFile.Prg;

/**
  * This class gives information about the program
  * System.err outputs
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

public class SplitFileInfo
{
	/**
	  * @return information about the File SPlit
	  */
	static public String getInfo()
	{
		return "File Splitter v1.0 (c)LuisM Pena, October-1997.    http://users.skynet.be/lmp";
	}
}