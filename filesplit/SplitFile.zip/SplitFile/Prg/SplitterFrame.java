package SplitFile.Prg;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Color;
import java.awt.FileDialog;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

/**
  * Frame to get information in a windows on the file to split, number of chunks...
  * It is abstract. Its implementation classes should define:<br>
  * -initSplitting: called when the button Start is pressed and there is no 
  *		any current splitting<br>
  * -cancelSplitting: called when the button Cancel is pressed, or when the user 
  *					tries to close the application and there is an splitting running.<br>
  * The implementation class should use the method setDoingSplitting to let know
  * to this class if there is any current splitting running. Canb also use the
  * protected members readProgressm writeProgress and Status to show information<br>
  * <br>
  * It uses the class SplitterProperties to persist some settings: directories, chunk
  * size...<br>
  * Some notes on his behaviour:<br>
  * a-The button Exit is renamed to Cancel during a splitting.
  * b-The targetPath is a copy of the fileName. This active copy is broken if the
  *   targetPath is modified separately (and until the splitting finishes).
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

abstract class SplitterFrame extends Frame
{
	protected SplitterFrame()
	{
		properties=new SplitterProperties();
		GridBagLayout gbag=new GridBagLayout();
		GridBagConstraints c=new GridBagConstraints();
		setLayout(gbag);
		Button browse,browseTarget,go;
					
		c.insets=new Insets(5,5,5,5);
		c.weightx=0;
		c.weighty=1;
		Label l=new Label("File:");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1;
		c.gridx=1;
		c.gridwidth=2;
		fileName=new TextField(30);
		gbag.setConstraints(fileName,c);
		add(fileName);		

		c.fill=GridBagConstraints.NONE;
		c.gridx=3;
		c.weightx=0;
		c.gridwidth=1;
		c.anchor=GridBagConstraints.WEST;
		browse=new Button(". . .");
		gbag.setConstraints(browse,c);
		add(browse);		

		c.gridx=0;
		c.gridy=1;
		c.anchor=GridBagConstraints.CENTER;
		l=new Label("Target:");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1;
		c.gridx=1;
		c.gridwidth=2;
		targetPath=new TextField(30);
		gbag.setConstraints(targetPath,c);
		add(targetPath);		

		c.fill=GridBagConstraints.NONE;
		c.gridx=3;
		c.weightx=0;
		c.gridwidth=1;
		c.anchor=GridBagConstraints.WEST;
		browseTarget=new Button(". . .");
		gbag.setConstraints(browseTarget,c);
		add(browseTarget);		

		c.gridx=0;
		c.gridy=2;
		c.anchor=GridBagConstraints.CENTER;
		l=new Label("Chunk size:");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=.5;
		c.gridx=1;
		chunkSize=new TextField(properties.chunkSize);
		gbag.setConstraints(chunkSize,c);
		add(chunkSize);
		
		c.gridx=2;
		stdSize=new Checkbox("3\"1/2 size",properties.useStandardSize);
		gbag.setConstraints(stdSize,c);
		add(stdSize);		
		checkSize();


		c.gridx=3;
		c.weightx=0;
		go=new Button("Start");
		gbag.setConstraints(go,c);
		add(go);		

		c.gridy=3;
		c.gridx=1;
		c.weightx=.5;
		c.gridwidth=1;
		c.fill=GridBagConstraints.HORIZONTAL;
		CheckboxGroup cbg=new CheckboxGroup();
		createBat=new Checkbox("create .bat file",cbg,properties.createBat);
		gbag.setConstraints(createBat,c);
		add(createBat);		

		c.gridx=2;
		createSH=new Checkbox("create sh script",cbg,!properties.createBat);
		gbag.setConstraints(createSH,c);
		add(createSH);		

		c.fill=GridBagConstraints.NONE;
		c.weightx=0;
		c.gridx=0;
		c.gridy=4;
		c.gridwidth=1;
		l=new Label("Status:");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1;
		c.gridx=1;
		c.gridwidth=2;
		status=new TextField(40);
		status.setEditable(false);
		gbag.setConstraints(status,c);
		add(status);		

		c.gridx=3;
		c.weightx=0;
		c.gridwidth=1;
		exitCancel=new Button();
		gbag.setConstraints(exitCancel,c);
		add(exitCancel);		

		c.fill=GridBagConstraints.NONE;
		c.gridx=0;
		c.gridy=5;
		l=new Label("Read");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1;
		c.gridx=1;
		c.gridwidth=GridBagConstraints.REMAINDER;
		readProgress=new ProgressLine(new Color(192,192,192), new Color(255,0,0));
		gbag.setConstraints(readProgress,c);
		add(readProgress);		

		c.weightx=0;
		c.fill=GridBagConstraints.NONE;
		c.gridx=0;
		c.gridy=6;
		c.gridwidth=1;
		l=new Label("Write");
		gbag.setConstraints(l,c);
		add(l);		
		
		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1;
		c.gridx=1;
		c.gridwidth=GridBagConstraints.REMAINDER;
		writeProgress=new ProgressLine(new Color(192,192,192), new Color(0,0,255));
		gbag.setConstraints(writeProgress,c);
		add(writeProgress);		

		c.gridx=0;
		c.gridy=7;
		l=new Label(SplitFileInfo.getInfo(),Label.CENTER);
		gbag.setConstraints(l,c);
		add(l);		
		
		setDoingSplitting(false);
		targetPathChanged=false;
		fileNameChanging=false;
		fileNameDialog=null;
		targetPathDialog=null;
		cancelled=false;
		
		addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){cancel();cancel();}});
		fileName.addTextListener(new TextListener(){public void textValueChanged(TextEvent e){fileNameChanged();}});
		targetPath.addTextListener(new TextListener(){public void textValueChanged(TextEvent e){targetChanged();}});
		go.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){splitIt();}});
		browse.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){browseFile();}});
		browseTarget.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){browseTarget();}});
		exitCancel.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){cancel();}});
		stdSize.addItemListener(new ItemListener(){public void itemStateChanged(ItemEvent e){checkSize();}});
	}
	
	/**
	  * This method allows to the implementation class to say when there is or not
	  * a current splitting. Depending on it, the exitCancel button will have
	  * the label "Exit" or "Cancel", and its pressing will produce a cancelling
	  * on the splitting or the exit of the program
	  * @param state the current state on the splitting
	  */
	protected void setDoingSplitting(boolean state)
	{
		if (state==false && !cancelled)
			targetPathChanged=false;
		cancelled=false;
		doingSplitting=state;
		exitCancel.setLabel(doingSplitting? szStop : szExit);
		System.gc();	//run now the garbage collection
	}
	
	/**
	  * This method will be called if the user press the Start button (and there
	  * is no splitting running, that is, setDoinSpliiting has not been called with
	  * the argument false)
	  * @param fileName the name of the file to split
	  * @param targetPath the targe path
	  * @param maxChunkSize the maximum size for each chunk
	  * @param createBat true to create a bat file; otherwise, a script file has to be
	  *		created.
	  */
	abstract protected void initSplitting(String fileName, String targetPath,
								long maxChunkSize, boolean createBat);
	
	/**
	  * This method will be called if the user press the Cancel button (and there
	  * is no splitting running, that is, setDoinSpliiting has not been called with
	  * the argument false)
	  */
	abstract protected void cancelSplitting();
	
	/**
	  * This method is called when the file name changes
	  */
	protected void fileNameChanged()
	{
		if (!targetPathChanged)
		{
			fileNameChanging=true;
			targetPath.setText(fileName.getText());
		}
	}
	
	/**
	  * This method is called when the target name changes
	  */
	protected void targetChanged()
	{
		if (!fileNameChanging)
			targetPathChanged=true;
		fileNameChanging=false;
	}
	
	/**
	  * Checks the state of the CheckButton 3"1/2. If it is checked, the textfield
	  * Chunk Size is inactivated, and set its value to 1457664. If not checked,
	  * the Textfield is activated.
	  */
	protected void checkSize()
	{
		boolean state=stdSize.getState();
		chunkSize.setEditable(!state);
		if (state)
			chunkSize.setText("1457664");
	}
	
	/**
	  * Method called when the user press the browse button to get the File Name
	  */
	protected void browseFile()
	{
		if (fileNameDialog==null)
		{
			fileNameDialog=new FileDialog(this,"Select file to split",FileDialog.LOAD);
			if (properties.fileNameDirectory!=null)
				fileNameDialog.setDirectory(properties.fileNameDirectory);
		}
		String file=makeBrowse(fileNameDialog);
		if (file!=null)
			fileName.setText(file);
	}
	
	/**
	  * Method called when the user press the browse button to get the target
	  */
	protected void browseTarget()
	{
		if (targetPathDialog==null)
		{
			targetPathDialog=new FileDialog(this,"Select target path",FileDialog.LOAD);
			if (properties.targetPathDirectory!=null)
				targetPathDialog.setDirectory(properties.targetPathDirectory);
		}
		String file=makeBrowse(targetPathDialog);
		if (file!=null)
			targetPath.setText(file);
	}
	
	/**
	  * Open a the fileDialog given, and returns the selected file
	  * @param dialog the FileDialog to use
	  * @return the file selected, or null if no file has been selected
	  */
	private String makeBrowse(FileDialog dialog)
	{
		String ret=null;
		dialog.show();
		String file=dialog.getFile();
		if (file!=null)
			ret=dialog.getDirectory()+file;
		return ret;
	}
	
	/**
	  * Method called when the user press the Start button
	  */
	protected void splitIt()
	{
		if (!doingSplitting)
		{
			boolean goodChunk=true;
			try
			{
				long size=Long.parseLong(chunkSize.getText());
				if (size<=0)
					goodChunk=false;
				else
				{	//save the properties
					if (fileNameDialog!=null)
						properties.fileNameDirectory=fileNameDialog.getDirectory();
					if (targetPathDialog!=null)
						properties.targetPathDirectory=targetPathDialog.getDirectory();
					properties.chunkSize=chunkSize.getText();
					properties.createBat=createBat.getState();
					properties.useStandardSize=stdSize.getState();
					//init the splitting
					initSplitting(fileName.getText(),targetPath.getText(),size,createBat.getState());
				}
			}
			catch(NumberFormatException fne)
			{
				goodChunk=false;
			}
			if (!goodChunk)
				status.setText("Invalid chunk size");
		}
	}				
	
	/**
	  * Method called when the user press the Exit/Cancel button
	  */
	protected void cancel()
	{
		if (doingSplitting)
		{
			cancelled=true;
			cancelSplitting();
		}
		else
		{
			properties.save();
			System.exit(0);
		}
	}
	
	protected ProgressLine readProgress, writeProgress;
	protected TextField status;
	protected boolean cancelled;
	
	private TextField fileName,targetPath,chunkSize;
	private Checkbox createBat,createSH, stdSize;
	private Button exitCancel;
	private FileDialog fileNameDialog, targetPathDialog;
	private boolean doingSplitting,targetPathChanged,fileNameChanging;
	private SplitterProperties properties;
	
	private final String szExit="Exit";
	private final String szStop="Stop";
}	