package SplitFile.Prg;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.Enumeration;

import SplitFile.ListChunks;

/**
  * This class creates a sh script that allows to merge the
  * splitted files on a UNIX environment
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class ScriptGlue extends BatchGlue
{
	/**
	  * Creates a glue for the splitter given
	  * @param splitter the FileSplitter that will split the file
	  * @param batchFile the file to create
	  * @param sourceFile the name of the file to create on merging
	  */
	public void createGlue(ListChunks chunks,String batchFile, String sourceFile) throws IOException
	{
		if (chunks.getNumberOfChunks()>0)
		{
			Enumeration enum=chunks.getChunks();
			PrintWriter file=new PrintWriter(new FileOutputStream(batchFile));
			file.println("#!/bin/sh");
			file.println("echo Merging chunk files created with Split File");
			file.println("echo [c]LuisM Pena, October 1997");
			file.print(  "cat \""+(String)(enum.nextElement())+"\"");
			while (enum.hasMoreElements())
				file.print(" \"" + (String)(enum.nextElement())+"\"");
			file.println(" > \""+sourceFile+"\"");
			file.println("echo Merging done");
			file.close();
		}
	}
}