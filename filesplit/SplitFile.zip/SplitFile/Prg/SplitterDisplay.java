package SplitFile.Prg;

/**
  * This is the interface the Splitting class will use to show its status
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

interface SplitterDisplay
{
	/**
	  * Method to show some information
	  * @param msg The message to show
	  */
	public void showMessage(String msg);
	
	/**
	  * Method to show an error message
	  * @param error the error to show
	  */
	public void showError(String error);
	
	/**
	  * Method to show the progress done on read
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setReadProgress(int progress);
	
	/**
	  * Method to show the progress done on writting (on a chunk)
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setWriteProgress(int progress);

	/**
	  * This is not a showing information method, but the way the Splitting class will use
	  * to say that has finished its task
	  * @param error true if the splitting has finished by an error
	  */
	public void splittingFinished(boolean error);
}