package SplitFile.Prg;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.util.Properties;

/**
  * Class to manage the properties for the SplitFile. The properties
  * are stored in the file SplitFile.properties in the directory given by
  * the user.home property (in Windows, it is given by the environment
  * variable HOME)
  * 
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

class SplitterProperties
{
	public String fileNameDirectory;
	public String targetPathDirectory;
	public boolean createBat;
	public String chunkSize;
	public boolean useStandardSize;
	
	public SplitterProperties()
	{
		fileNameDirectory=null;
		targetPathDirectory=null;
		createBat=true;
		chunkSize=new String("1457664");
		useStandardSize=true;
		
		try
		{
			Properties properties=new Properties();
			FileInputStream fis=new FileInputStream(getPropertyFile());
			properties.load(fis);
			fis.close();
			
			fileNameDirectory=properties.getProperty(szFND);
			targetPathDirectory=properties.getProperty(szTPD);
			chunkSize=properties.getProperty(szTS,chunkSize);
			createBat=(properties.getProperty(szBAT)!=null);
			useStandardSize=(properties.getProperty(szSS)!=null);
		}
		catch(IOException ex)
		{
		}
	}
	
	public void save()
	{
		try
		{
			Properties properties=new Properties();
			if (fileNameDirectory!=null)
				properties.put(szFND,fileNameDirectory);
			if (targetPathDirectory!=null)
				properties.put(szTPD,targetPathDirectory);
			if (createBat)
				properties.put(szBAT,"@");
			if (useStandardSize)
				properties.put(szSS,"@");
			else
				properties.put(szTS,chunkSize);
				
			FileOutputStream fos=new FileOutputStream(getPropertyFile());
			properties.save(fos,"Split File properties");
			fos.close();
			
		}
		catch(IOException ex)
		{
			System.err.println("Error saving the settings: " +ex);
		}
	}
	
	private String getPropertyFile()
	{
		return System.getProperty("user.home")
						+System.getProperty("file.separator")
							+"SplitFile.properties";
	}
	
	private final String szFND="fnDir";
	private final String szTPD="tpDir";
	private final String szTS="ChunkSize";
	private final String szBAT="CreateBat";
	private final String szSS="UseStdSize";
}