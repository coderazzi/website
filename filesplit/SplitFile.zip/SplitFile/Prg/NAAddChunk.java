package SplitFile.Prg;

import java.io.File;

/**
  * NamingAlgorythm class that adds a dot and the chunk number to the path specified
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class NAAddChunk implements SplitFile.NamingAlgorythm
{
	/**
	  * Constructor: needs the path where the chunks will be written
	  */
	public NAAddChunk(String path)
	{
		this.path=new String(path+".");
	}
	
	/**
	  * Initialize the algorythm.  In this class, it does nothing
	  * @param inputFile the File object of the input file
	  * @param chunks the number total of chunks to create
	  */
	public SplitFile.ErrorSplittingEvent init(File inputFile, long chunks)
	{
		return null;
	}
	/**
	  * This procedure allows to get an output file
	  * @param sequence the sequence number of the output file
	  * @return a name for this chunk of the splitted file
	  */
	public File getOutputFile(long sequence)
	{
		return new File(path+String.valueOf(sequence));
	}
	
	private String path;
}