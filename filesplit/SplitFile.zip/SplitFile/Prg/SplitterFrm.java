package SplitFile.Prg;

/**
  * SplitterDisplay that shows the splitter information on a SplitterFrame
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

public class SplitterFrm extends SplitterFrame implements SplitterDisplay
{
	public SplitterFrm()
	{
		super();
		setTitle("File Splitter");
		pack();
		show();
	}
	
	/**
	  * This method will be called if the user press the Start button (and there
	  * is no splitting running, that is, setDoinSpliiting has not been called with
	  * the argument false)
	  * @param fileName the name of the file to split
	  * @param targetPath the targe path
	  * @param maxChunkSize the maximum size for each chunk
	  * @param createBat true to create a bat file; otherwise, a script file has to be
	  *		created.
	  */
	protected void initSplitting(String fileName, String targetPath,
								long maxChunkSize, boolean createBat)
	{
		if (splitterThread==null)
		{
			setDoingSplitting(true);
			splitterThread=new Splitter(this, fileName, targetPath, maxChunkSize, createBat);
		}
	}
	
	/**
	  * This method will be called if the user press the Cancel button (and there
	  * is no splitting running, that is, setDoinSpliiting has not been called with
	  * the argument false)
	  */
	protected void cancelSplitting()
	{
		if (splitterThread!=null)
			splitterThread.stopSplitting();
	}
	
	/**
	  * Method to show some information
	  * @param msg The message to show
	  */
	public void showMessage(String msg)
	{
		status.setText(msg);
	}
	
	/**
	  * Method to show an error message
	  * @param error the error to show
	  */
	public void showError(String error)
	{
		status.setText(error);
	}
	
	/**
	  * Method to show the progress done on read
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setReadProgress(int progress)
	{
		readProgress.set(progress);
	}
	
	/**
	  * Method to show the progress done on writting (on a chunk)
	  * @param progress the progress percentage (from 0 to 100)
	  */
	public void setWriteProgress(int progress)
	{
		writeProgress.set(progress);
	}

	/**
	  * This is not a showing information method, but the way the Splitting class will use
	  * to say that has finished its task
	  * @param error true if the splitting has finished by an error
	  */
	public void splittingFinished(boolean error)
	{
		splitterThread=null;
		setDoingSplitting(false);
		cancelled=error;
	}
	
	private Splitter splitterThread;
}	