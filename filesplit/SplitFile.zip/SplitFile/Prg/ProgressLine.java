package SplitFile.Prg;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
  * Canvas that shows a progressive line
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */

class ProgressLine extends Canvas
{
	/**
	  * The constructor creates a Canvas to show a progress line.
	  * @param backGround the background color 
	  * @param lineColor the color to use to draw the line
	  */
	public ProgressLine(Color backGround, Color lineColor)
	{
		this.backGround=new Color(backGround.getRGB());
		this.lineColor=new Color(lineColor.getRGB());
		percentage=0;
	}
	
	/**
	  * Sets the percentage completion (from 0 to 100)
	  * @param percentage the completion status, from 0 to 100. It doesn't anything if the
	  * the percentage is not valid
	  */
	public void set(int percentage)
	{
		if (percentage>=0 && percentage<=100)
		{
			this.percentage=percentage;
			Graphics g=getGraphics();
			if (g!=null)
			{
				paint(g);
				g.dispose();
			}
		}
	}
	
	public Dimension getPreferredSize()
	{
		return new Dimension(24,24);
	}
	
	/**
	  * Draws the line
	  */
	public void paint (Graphics g) 
	{
		Dimension d=getSize();
		int height=d.height/3;
		int width=d.width*percentage/100;
		g.setColor(lineColor);
		g.fillRect(0,height,width,height);
		g.setColor(backGround);
		g.fillRect(width,height,d.width-width,height);
	}

	private Color backGround, lineColor;
	private int percentage;
}