package SplitFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.Observable;
import java.util.Observer;

/**
  * Main class, to make the splitting of a File
  *
  * It gets a fileName, and a chunk Size, and will create as many chunk files as
  * needed, each of them with a maximum size equal to the specified chunk Size.<br>
  * To generate the chunk file names it uses a Naming Algorythm, that must be also
  * specified.<br>
  *
  * To allow any object the observation of the splitting procedure, it
  * extends the class Observable, and throws the following events (all of them are 
  * specialitations of the SplitFileEvent class):<br>
  * -StartSplittingEvent: when the splitting starts. This is always the first event,
  * 	(except if an error is produced before) and includes some information about the
  * 	splitting operation: the file name, its length, the number of chunks to create
  * 	and their size.<br>
  * -StopSplittingEvent: when the splitting finishes with no errors.<br>
  * -ErrorSplittingEvent: when an error is produced. If the error is produced in the
  *	 	beginning, before opening the file to split (or opening it), this event will
  * 	be thrown without a previous StartSplittingEvent<br>
  * -ChunkCreatedEvent: when a new chunk file is created. It includes the name of the
  * 	file created, its sequence number, and its length.<br>
  * -ReadEvent: every n bytes read, this event is thrown. It includes the number of
  * 	bytes already read, and the read state (finished or not).<br>
  * -WriteEvent: every n bytes written, this event is thrown. It includes the number of
  * 	bytes already written (in the current chunk), and the write state 
  * 	(finished or not).<br>
  * The throwing of events can be controlled.<br>
  *<br>
  * It is not checked the security allowances; it is suposed that the class will
  * have the rights to stop any created Thread, and to read and write the selected
  * files<br>
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 1.0
  * @see SpliFileEvent
  * @see StartSplittingEvent
  * @see StopSplittingEvent
  * @see ErrorSplittingEvent
  * @see ChunkCreatedEvent
  * @see ReadEvent
  * @see WriteEvent
  * @see NamingAlgorythm
  * SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY WARRANTY OF ANY KIND
  */
public class FileSplitter extends Observable implements Observer
{
	/**
	  * Member to split the file. All the notifications, even the errors are
	  * done via the Observer/Observable pattern
	  * @param fileName name of the file to split
	  * @param chunkSize the size of each chunk
	  * @param namingAlg the NamingAlgorythm to use to get file names for the chunk files
	  * @param receiveAllEvents	true to receive WriteEvent and ReadEvent events (the rest can
	  *		not be inhibed with this method)
	  */
	public void split(String fileName, long chunkSize, NamingAlgorythm namingAlg,
											boolean receiveAllEvents)
	{
		ErrorSplittingEvent ev=InitFileSplitter(fileName, chunkSize, namingAlg);
		if (ev!=null)
		{
			ev.setFileName(fileName);
			setChanged();
			notifyObservers(ev);
		}
		else
		{
			setChanged();
			notifyObservers(new StartSplittingEvent(fileName,fileSize,nChunks,chunkSize));
			fileRead=new FileRead(fis,fileSize,memory);
			fileWrite=new FileWrite(memory,namingAlg,fileSize,chunkSize);
			fileRead.startReading(this,receiveAllEvents);
			fileWrite.startWritting(this,receiveAllEvents);
			waitToFinish();
		}
	}
	
	/**
	  * Stops the current splitting. An event ErrorSplittingEvent will be launched
	  */
	public void stopSplitting()
	{
		if (memory!=null)
		{
	 		fileRead.stopReading();
	 		fileWrite.stopWritting();
			setChanged();
			notifyObservers(new ErrorSplittingEvent(ErrorSplittingEvent.SPLITTING_CANCELLED));
			error=true;
			finishWait();
		}
	}
	
	/**
	  * Init some variables used in the FileSplitter: the input file, its length, the
	  * RWBufferMemory, the nameAlg, and the number of chunks.
	  * @param fileName name of the file to split
	  * @param chunkSize the size of each chunk
	  * @param namingAlg the NamingAlgorythm to use to get file names for the chunk files
	  * @return ErrorSplittingEvent if an exception is produced, or null if not exceptions 
	  * at all are produced
	  */
	ErrorSplittingEvent InitFileSplitter(String fileName, long chunkSize, NamingAlgorythm namingAlg)
	{
		fis=null;
		ErrorSplittingEvent ev=null;	
		File file=new File(fileName);
		fileSize=0;
		memory=null;
		fileRead=null;
		fileWrite=null;
		error=false;
		
		if (!file.exists())
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.NOT_EXISTING_FILE);
		else if (!file.canRead())
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.NOT_READABLE_FILE);
		else if (file.isDirectory())
			ev=new ErrorSplittingEvent(ErrorSplittingEvent.FILE_IS_DIRECTORY);
		else
			try
			{
				fis=new FileInputStream(file);
			
				fileSize=file.length();
				if (fileSize==0)
				{
					try{fis.close();}catch(Exception ex){}
					fis=null;
					ev=new ErrorSplittingEvent(ErrorSplittingEvent.FILE_EMPTY);
				}
				else
				{
					nChunks=fileSize/chunkSize;
					if (fileSize%chunkSize!=0)
						nChunks++;
					int blockSize=fileSize > constBlockLength? constBlockLength : (int) fileSize;	//safe
					memory=new RWMemory(new CommRWBufferMemory(blockSize),new CommRWBufferMemory(blockSize));
					ev=namingAlg.init(file, nChunks);
				}
			}
			catch(FileNotFoundException fnfe)
			{
				ev=new ErrorSplittingEvent(ErrorSplittingEvent.FILE_NOT_FOUND);
			}
		return ev;
	}
	
	/**
	  * Observer method
	  */
	public void update(Observable obs, Object obj)
	{
		if (obj instanceof FinishOpEvent)
			finishWait();																//the splitting has finished
		else
		{
			setChanged();
			notifyObservers(obj);
			if (obj instanceof ErrorSplittingEvent)
			{
				error=true;																	//set the error flag
				finishWait();															//finish the splitting
			}
		}
	}
	
	/**
	  * Wait until the operation finishes
	  */
	synchronized void waitToFinish()
	{
		try
		{
			wait();																				//will be wake up by finishWait
		}
		catch(InterruptedException ex)
		{
			error=true;
			setChanged();
			notifyObservers(new ErrorSplittingEvent(ErrorSplittingEvent.INTERNAL_ERROR3));
		}
		
		if (error)																			//stop the threads (can be active)
	 	{
	 		fileRead.stopReading();
	 		fileWrite.stopWritting();
	 	}
	 	
	 	try
	 	{
	 		fis.close();
	 		if (!error)
	 		{
				setChanged();
	 			notifyObservers(new StopSplittingEvent());		//notify the end of splitting
	 		}
	 	}
	 	catch(IOException ioex)														//error closing the file
	 	{
				setChanged();
				notifyObservers(new ErrorSplittingEvent(ErrorSplittingEvent.IOEXCEPTION_READING));
	 	}
	 	
	 	fis=null;																						//late cleaning
	 	memory=null;
	 	fileRead=null;
	 	fileWrite=null;
	}
	
	/**
	  * finish the operation, making waitToFinish to run out
	  */
	synchronized void finishWait()
	{
		notify();
	}
	
	private final int constBlockLength=65536;

	private FileInputStream fis;				//file being splitted
	private long fileSize;							//size of the file to split
	private long nChunks;								//Number of chunks to create
	private RWMemory memory;						//buffer memory
	private FileRead fileRead;					//class to read the file to split
	private FileWrite fileWrite;				//class to write the chunks
	private boolean error;							//flag to stop the threads (for an error)
}