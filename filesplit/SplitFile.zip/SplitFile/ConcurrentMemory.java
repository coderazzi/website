package SplitFile;

/**
  * This class allows to create a block the memory where two different processes
  * (threads) can read and write in a synchronized way. It is supposed that
  * one of the processes is reading and the another is writting.<br>
  * It creates two buffers, that can be read and written alternatively, allowing
  * that a thread can read at same time that the another thread is writting.<br>
  * And why not to create 3 buffers, for example? The time to read somethin and
  * writting it later will be (thinking that writting is slower that reading):
  * One buffer: Time_Reading + Time_Writting
  * More than one buffer: Time_Writting + Time_Reading_Buffer_Bytes
  * Therefore, it is the same to have two or more than two buffers
  *
  * @author (c) LuisM Pena, October-1997.
  * @version 0.1
  */
class ConcurrentMemory
{
	/**
	  * The constructor needs to have the size of the block
	  * @param size the size of the block
	  */
	public ConcurrentMemory(int size)
	{
		buffers=new byte[2][size];
		freeBuffers=2;
		writeBuffer=readBuffer=0;
	}
	
	/**
	  * With this operation is possible to get a buffer to insert new data. This
	  * buffer should be released with a call to releaseWriteBuffer.
	  * Note: a race condition is not expected (because only a thread is going to
	  * call to getWriteBuffer) 
	  * @return a buffer of the size given in the initialitation
	  * @exception InterruptedException means that the use of the memory can not
	  * be guaranteed any more.
	  */
	public synchronized byte[] getWriteBuffer() throws InterruptedException
	{
		while(freeBuffers==0)
			wait();
		--freeBuffers;
		writeOnBuffer=(writeOnBuffer+1)%2;
		return buffers[writeOnBuffer=buffer];
	}
	
	/**
	  * With this operation it is released a WriteBuffer previously got. If two
	  * buffers has been got, it is released the first of them. If this method
	  * is called whit no corresponding getWriteBuffer, the result is unexpected.
	  */
	public synchronized void releaseWriteBuffer()
	{
		while(freeBuffers==0)
			wait();
		--freeBuffers;
		writeOnBuffer=(writeOnBuffer+1)%2;
		return buffers[writeOnBuffer];
	}
	
	private byte[][] buffers;
	private int freeBuffers;			//buffers not used
	private int writeBuffer;			//following buffer to use on a write operation
	private int readBuffer;			//following buffer to use on a read operation
}